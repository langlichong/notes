/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.thirdapi.service;

import cn.hutool.json.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.core.param.IotThirdApiQueryParam;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.thirdapi.param.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * 接口管理Service接口
 *
 * @author js
 * @date 2023/03/28 10:09
 **/
public interface IotThirdApiService extends IService<IotThirdApi> {

    /**
     * 获取接口管理分页
     *
     * @param iotThirdApiPageParam
     * @return Page
     * @author js
     * @date 2023/03/28 10:09
     */
    Page<IotThirdApi> page(IotThirdApiPageParam iotThirdApiPageParam);

    /**
     * 添加接口管理
     *
     * @param iotThirdApiAddParam
     * @return
     * @author js
     * @date 2023/03/28 10:09
     */
    void add(IotThirdApiAddParam iotThirdApiAddParam);

    /**
     * 复制接口
     *
     * @param iotThirdApiAddParam
     * @return
     * @author js
     * @date 2023/03/28 10:09
     */
    void copy(IotThirdApiAddParam iotThirdApiAddParam);

    /**
     * 编辑接口管理
     *
     * @param iotThirdApiEditParam
     * @return
     * @author js
     * @date 2023/03/28 10:09
     */
    void edit(IotThirdApiEditParam iotThirdApiEditParam);

    /**
     * 删除接口管理
     *
     * @param iotThirdApiIdParamList
     * @return
     * @author js
     * @date 2023/03/28 10:09
     */
    void delete(List<IotThirdApiIdParam> iotThirdApiIdParamList);

    /**
     * 获取接口管理详情
     *
     * @param iotThirdApiIdParam
     * @return IotThirdApi
     * @author js
     * @date 2023/03/28 10:09
     */
    IotThirdApi detail(IotThirdApiIdParam iotThirdApiIdParam);

    /**
     * 获取接口管理详情
     *
     * @param id
     * @return IotThirdApi
     * @author js
     * @date 2023/03/28 10:09
     **/
    IotThirdApi queryEntity(String id);

    /**
     * 根据apiSign获取接口数据
     *
     * @param apiSign
     * @return IotThirdApi
     * @author js
     * @date 2023/03/28 10:09
     **/
    IotThirdApi queryEntityByApiSign(String apiSign);

    /**
     * 根据apiSigns批量获取接口数据
     *
     * @param apiSigns
     * @return IotThirdApi
     * @author js
     * @date 2023/03/28 10:09
     **/
    List<IotThirdApi> queryEntityByApiSigns(List<String> apiSigns);

    /**
     * 获取三方接口数据
     *
     * @param iotThirdApiQueryParam
     * @return Map
     * @author js
     * @date 2023/03/28 10:09
     **/
    Map<String, Object> queryThirdApiData(IotThirdApiQueryParam iotThirdApiQueryParam);

    /**
     * 获取接口管理列表
     *
     * @param iotThirdApiListParam
     * @return List
     * @author js
     * @date 2023/03/28 10:09
     */
    List<IotThirdApi> list(IotThirdApiListParam iotThirdApiListParam);

    /**
     * 下载接口导入模板
     *
     * @param response
     * @throws IOException
     */
    void downloadImportTemplate(HttpServletResponse response) throws IOException;

    /**
     * 接口导入
     *
     * @param file
     * @return
     */
    JSONObject importBatchIotThirdApi(MultipartFile file);

    /**
     * 接口导出
     *
     * @param iotThirdApiListParam
     * @param response
     * @throws IOException
     */
    void exportBatchIotThirdApi(IotThirdApiListParam iotThirdApiListParam, HttpServletResponse response) throws IOException;

    /**
     * 停止接口管理定时任务
     *
     * @param iotThirdApi
     * @author js
     * @date 2023/04/06 15:50
     **/
    void stopJob(IotThirdApi iotThirdApi);

    /**
     * 运行接口管理定时任务
     *
     * @param iotThirdApi
     * @author js
     * @date 2023/04/06 15:50
     **/
    void runJob(IotThirdApi iotThirdApi);

    /**
     * 根据接口配置获取设备信息
     *
     * @param iotThirdApi
     * @return
     */
    Device getDeviceByTimingEntityId(IotThirdApi iotThirdApi);

    /**
     * 立即运行接口管理定时任务
     *
     * @param iotThirdApiSignParam
     * @author js
     * @date 2023/04/06 15:50
     **/
    void runJobNow(IotThirdApiSignParam iotThirdApiSignParam);
}
