package com.genew.iot.modular.thirdapi.enums;

import lombok.Getter;

import java.util.Objects;

/**
 * Content-Type枚举类
 *
 * @author js
 * @date 2023/03/28 10:09
 */
@Getter
public enum IotThirdApiMediaTypeEnum {
    /**
     * 内容类型：application/json
     */
    APPLICATION_JSON("APPLICATION_JSON", "application/json; charset=utf-8"),
    /**
     * 内容类型：application/x-www-form-urlencoded
     */
    APPLICATION_FORM("APPLICATION_FORM", "application/x-www-form-urlencoded; charset=utf-8"),
    /**
     * 内容类型：text/x-markdown
     */
    MARKDOWN("MARKDOWN", "text/x-markdown; charset=utf-8"),
    /**
     * 内容类型：image/png
     */
    IMAGE_PNG("IMAGE_PNG", "image/png"),
    /**
     * 内容类型：image/gif
     */
    IMAGE_GIF("IMAGE_GIF", "image/gif"),
    /**
     * 内容类型：image/bmp
     */
    IMAGE_BMP("IMAGE_BMP", "image/bmp"),
    /**
     * 内容类型：image/jpeg
     */
    IMAGE_JPEG("IMAGE_JPEG", "image/jpeg"),
    /**
     * 内容类型：image/svg+xml
     */
    IMAGE_SVG("IMAGE_SVG", "image/svg+xml"),
    /**
     * 内容类型：image/tiff
     */
    IMAGE_TIFF("IMAGE_TIFF", "image/tiff"),
    /**
     * 内容类型：image/webp
     */
    IMAGE_WEBP("IMAGE_WEBP", "image/webp"),
    /**
     * 内容类型：text/html
     */
    TEXT_HTML("TEXT_HTML", "text/html; charset=utf-8"),
    /**
     * 内容类型：text/plain
     */
    TEXT_PLAIN("TEXT_PLAIN", "text/plain; charset=utf-8"),
    /**
     * 内容类型：text/xml
     */
    TEXT_XML("TEXT_XML", "text/xml; charset=utf-8"),
    /**
     * 内容类型：application/atom+xml
     */
    APPLICATION_ATOM_XML("APPLICATION_ATOM_XML", "application/atom+xml; charset=utf-8"),
    /**
     * 内容类型：application/octet-stream
     */
    APPLICATION_OCTET_STREAM("APPLICATION_OCTET_STREAM", "application/octet-stream; charset=utf-8"),
    /**
     * 内容类型：application/soap+xml
     */
    APPLICATION_SOAP_XML("APPLICATION_SOAP_XML", "application/soap+xml; charset=utf-8"),
    /**
     * 内容类型：application/svg+xml
     */
    APPLICATION_SVG_XML("APPLICATION_SVG_XML", "application/svg+xml; charset=utf-8"),
    /**
     * 内容类型：application/xhtml+xml
     */
    APPLICATION_XHTML_XML("APPLICATION_XHTML_XML", "application/xhtml+xml; charset=utf-8"),
    /**
     * 内容类型：application/xml
     */
    APPLICATION_XML("APPLICATION_XML", "application/xml; charset=utf-8"),
    /**
     * 内容类型：multipart/form-data
     */
    MULTIPART_FORM_DATA("MULTIPART_FORM_DATA", "multipart/form-data; charset=utf-8");

    private final String contentType;

    private final String value;

    IotThirdApiMediaTypeEnum(String contentType, String value) {
        this.contentType = contentType;
        this.value = value;
    }

    /**
     * 通过code取枚举
     *
     * @param contentType
     * @return
     */
    public static IotThirdApiMediaTypeEnum getValueByContentType(String contentType) {
        if (Objects.isNull(contentType)) {
            return null;
        }
        String valueKey = contentType;
        for (IotThirdApiMediaTypeEnum enums : IotThirdApiMediaTypeEnum.values()) {
            if (enums.getContentType().equals(valueKey)) {
                return enums;
            }
        }
        return null;
    }
}
