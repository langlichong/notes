/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.dromara.core.trans.anno.Trans;
import org.dromara.core.trans.constant.TransType;
import org.dromara.core.trans.vo.TransPojo;

/**
 * 设备指令实体
 *
 * @author huhu
 * @date  2023/09/06 17:16
 **/
@Getter
@Setter
@TableName(value = "iot_device_action",autoResultMap = true)
public class DeviceAction implements TransPojo {

    /** ID */
    @TableId
    @ApiModelProperty(value = "ID", position = 1)
    private String id;

    /** 指令名称 */
    @ApiModelProperty(value = "指令名称", position = 2)
    private String name;

    /** 指令描述 */
    @ApiModelProperty(value = "指令描述", position = 3)
    private String description;

    /** 指令协议 */
    @ApiModelProperty(value = "指令协议", position = 4)
    private String protocol;

    /** 目的主机 */
    @ApiModelProperty(value = "目的主机", position = 5)
    private String host;

    /** 目的端口 */
    @ApiModelProperty(value = "目的端口", position = 6)
    private Integer port;

    /** 指令端点 */
    @ApiModelProperty(value = "指令端点", position = 7)
    private String endpoint;

    /** 负载内容 */
    @ApiModelProperty(value = "负载内容", position = 8)
    private String payload;

    /** 依赖的指令 */
    @ApiModelProperty(value = "依赖的指令", position = 9)
    private String depsAction;

    /** 认证参数 */
    @ApiModelProperty(value = "认证参数", position = 10)
    private String authParam;

    /** 目标设备 */
    @ApiModelProperty(value = "目标设备", position = 11)
    @Trans(type = TransType.SIMPLE, target = Device.class, fields = "name", alias = "device", ref = "deviceName")
    private String deviceId;

    @TableField(exist = false)
    @ApiModelProperty(value = "设备名称", position = 12)
    private String deviceName;
}
