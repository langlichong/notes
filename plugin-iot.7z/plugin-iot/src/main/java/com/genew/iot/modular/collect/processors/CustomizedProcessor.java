package com.genew.iot.modular.collect.processors;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.genew.iot.core.util.TcpUtil;
import com.genew.iot.modular.collect.core.*;
import com.genew.iot.modular.collect.customized.dy485.BmsDataBody;
import com.genew.iot.modular.metric.dto.protocol.TcpProtocolConf;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Objects;

/**
 * 仅针对电源返回结果做定制化处理
 *
 * @author js
 */
@Slf4j
@Component
public class CustomizedProcessor extends AbstractCollectResponseProcessor {

    @Resource
    private TcpUtil tcpUtil;

    @Override
    public String id() {
        return "customizedProcessor";
    }

    @Override
    public String name() {
        return "电源定制化处理";
    }


    @Override
    public boolean support(CollectResponse response) {
        // 所有情况都支持
        return true;
    }

    @Override
    public ProcessorResult doProcess(CollectResponse response, ProcessorResult previousResult) {
        final Object metricValue = previousResult.getResult();
        if (Objects.isNull(metricValue)) {
            return previousResult;
        }
        final String protocol = response.getOriginRequest().getProtocol();
        final CollectRequest originRequest = response.getOriginRequest();
        final TcpProtocolConf tcpProtocolConf = originRequest.getTcpProtocolConf();
        CollectTypes collectTypes = CollectTypes.valueOf(protocol);
        Map<String, String> map;
        log.info("---customizedProcessor---");
        if (support(response)) {
            switch (collectTypes) {
                case DATABASE_QUERY:
                case FILE_READING:
                case HTTP_API:
                case MODBUS_TCPIP:
                case MQTT_PUBLISH:
                case MQTT_SUBSCRIBE:
                case OPC_UA_POLL:
                case OPC_UA_SUBSCRIBE:
                    break;
                case TCP_POLL:
                    map = JSONUtil.toBean(JSONUtil.toJsonStr(metricValue), Map.class);
                    BmsDataBody bmsDataBody = tcpUtil.transform485Data(map, protocol, tcpProtocolConf);
                    JSONObject processedPollValue = TcpUtil.reportedJson(bmsDataBody);
                    if (Objects.nonNull(processedPollValue)) {
                        log.info("TCP_POLL定制化处理后结果:{}", processedPollValue);
                        previousResult.setResult(processedPollValue);
                    }
                    break;
                case TCP_SUBSCRIBE:
                    map = JSONUtil.toBean(JSONUtil.toJsonStr(metricValue), Map.class);
                    JSONArray processedSubValue = tcpUtil.transformBa4Data(map, protocol, tcpProtocolConf);
                    if (Objects.nonNull(processedSubValue)) {
                        log.info("TCP_SUBSCRIBE定制化处理后结果:{}", processedSubValue);
                        previousResult.setResult(processedSubValue);
                    }
                    break;
            }
        }
        return previousResult;
    }

    @Override
    public int getOrder() {
        return 1;
    }
}
