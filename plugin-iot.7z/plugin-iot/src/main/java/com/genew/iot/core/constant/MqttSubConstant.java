package com.genew.iot.core.constant;

/**
 * /**
 *
 * @program: base
 * <p>
 * 功能描述: Mqtt订阅常量类
 * @author: js
 * @create: 2023-07-05 10:07
 **/
public class MqttSubConstant {
    /**
     * MQTT连接前缀
     */
    public static final String MQTT_HOST_PREFIX = "tcp://";
    /**
     * 超时时间
     */
    public static final String SNOWY_MQTT_CONNECTION_TIMEOUT_KEY = "SNOWY_MQTT_CONNECTION_TIMEOUT";
    /**
     * 保活时间
     */
    public static final String SNOWY_MQTT_KEEPALIVE_INTERVAL_KEY = "SNOWY_MQTT_KEEPALIVE_INTERVAL";
    /**
     * 是否清除会话
     */
    public static final String SNOWY_MQTT_CLEAR_SESSION_KEY = "SNOWY_MQTT_CLEAR_SESSION";
    /**
     * 消息质量
     */
    public static final String SNOWY_MQTT_QOS_KEY = "SNOWY_MQTT_QOS";

}

