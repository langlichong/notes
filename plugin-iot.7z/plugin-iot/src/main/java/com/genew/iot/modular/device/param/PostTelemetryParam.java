package com.genew.iot.modular.device.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Setter
@Getter
public class PostTelemetryParam {

    @ApiModelProperty(value = "台账设备ID")
    @NotBlank(message = "设备ID不能为空")
    private String deviceId;

    @ApiModelProperty(value = "遥测内容")
    @NotBlank(message = "遥测内容不能为空")
    private String telemetryContent;
}
