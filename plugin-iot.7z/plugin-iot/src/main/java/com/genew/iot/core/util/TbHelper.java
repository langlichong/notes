package com.genew.iot.core.util;

import cn.hutool.json.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.genew.dev.api.DevConfigApi;
import com.genew.iot.modular.device.enums.TbAttributeScopes;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.thingsboard.rest.client.RestClient;
import org.thingsboard.server.common.data.EntityType;
import org.thingsboard.server.common.data.alarm.Alarm;
import org.thingsboard.server.common.data.alarm.AlarmSeverity;
import org.thingsboard.server.common.data.alarm.AlarmStatus;
import org.thingsboard.server.common.data.id.CustomerId;
import org.thingsboard.server.common.data.id.DeviceId;
import org.thingsboard.server.common.data.id.EntityId;
import org.thingsboard.server.common.data.id.TenantId;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

@Slf4j
@Component
public class TbHelper {

    private static final String TB_AUTH_URL_KEY = "TB_AUTH_URL";
    private static final String TB_USER_NAME_KEY = "TB_USER_NAME";
    private static final String TB_USER_PWD_KEY = "TB_USER_PWD";

    public static final Map<String, RestClient> tbClientMap = Maps.newConcurrentMap();

    @Resource
    private DevConfigApi configApi;

    @Resource
    private ObjectMapper objectMapper;


    public RestClient login() {

        // todo 获取 配置项 值 暂时不需要缓存 （系统的配置项已经处于缓存中）

        final String tbUrl = configApi.getValueByKey(TB_AUTH_URL_KEY);
        final String account = configApi.getValueByKey(TB_USER_NAME_KEY);
        final String accountPwd = configApi.getValueByKey(TB_USER_PWD_KEY);

        RestClient client = tbClientMap.get("tbClient");
        if (Objects.isNull(client)) {
            client = new RestClient(tbUrl);
            client.login(account, accountPwd);
            tbClientMap.put("tbClient", client);
        }
        return client;
    }

    public RestClient login(String url, String account, String accountPwd) {

        RestClient client = new RestClient(url);

        client.login(account, accountPwd);

        return client;
    }


    public void push2Thingsboard(JSONObject json, List<String> devIds) {
        final RestClient client = login();
        JsonNode dataPoint = null;
        try {
            dataPoint = objectMapper.readTree(json.toString());

            for (String devId : devIds) {
                client.saveEntityTelemetry(DeviceId.fromString(devId), "DEVICE", dataPoint);
                log.info("推送： 设备 = {}, 数据 {}", devId, dataPoint);
            }
        } catch (JsonProcessingException e) {
            log.error("推送失败: ", e);
        }
        client.logout();
    }

    public void push2Thingsboard(String json, List<String> devIds) {
        final RestClient client = login();
        JsonNode dataPoint = null;
        try {
            dataPoint = objectMapper.readTree(json.toString());

            for (String devId : devIds) {
                client.saveEntityTelemetry(DeviceId.fromString(devId),"DEVICE",dataPoint);
                log.info("推送： 设备 = {}, 数据 {}",devId,dataPoint);
            }
        } catch (JsonProcessingException e) {
            log.error("推送失败: ",e);
        }
        client.logout();
    }

    public void pushAlarm2ThingsBoard(String message, List<String> devIds) {
        final RestClient client = login();
        for (String devId : devIds) {
            TenantId tenantId = TenantId.fromUUID(UUID.fromString(devId));
            CustomerId customerId = new CustomerId(UUID.fromString(devId));
            EntityId entityId = new EntityId() {
                @Override
                public UUID getId() {
                    return UUID.fromString(devId);
                }

                @Override
                public EntityType getEntityType() {
                    return EntityType.DEVICE;
                }
            };
            Alarm alarm = Alarm.builder()
                    .tenantId(tenantId)
                    .customerId(customerId)
                    .type(message)
                    .originator(entityId).propagate(true)
                    .severity(AlarmSeverity.CRITICAL)
                    .status(AlarmStatus.ACTIVE_ACK).build();
            Alarm alarm1 = client.saveAlarm(alarm);
            log.info("推送： 设备 = {}, 数据 {},告警ID：{}", devId, message, alarm1.getId());
        }
        client.logout();
    }

    public boolean saveDeviceAttributes(List<String> devIds, String jsonString, TbAttributeScopes scope) {
        final RestClient client = login();
        if (scope == null) {
            scope = TbAttributeScopes.SHARED_SCOPE;
        }
        JsonNode dataPoint;
        boolean created = false;
        try {
            dataPoint = objectMapper.readTree(jsonString);
            for (String devId : devIds) {
                created = client.saveDeviceAttributes(DeviceId.fromString(devId), scope.name(), dataPoint);
                log.info("保存： 设备 = {}, 属性 {}", devId, dataPoint);
            }
        } catch (JsonProcessingException e) {
            log.error("保存: ", e);
        }
        return created;
    }
}
