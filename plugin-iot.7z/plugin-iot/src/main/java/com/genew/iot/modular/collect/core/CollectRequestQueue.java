package com.genew.iot.modular.collect.core;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.LinkedBlockingQueue;

@Slf4j
@Component
public class CollectRequestQueue {

    private static LinkedBlockingQueue<CollectRequest> requestQueue = new LinkedBlockingQueue<>(10000);

    public static void addRequest(CollectRequest task){

        try {
           requestQueue.put(task);
        } catch (InterruptedException e) {
           log.error("添加采集任务失败",e);
        }
    }


    public static CollectRequest getRequest(){

        CollectRequest task = null;
        try {
            task = requestQueue.take();
        } catch (InterruptedException e) {
            log.error("获取采集任务失败",e);
        }
        return task;
    }

    public static boolean removeOne(CollectRequest request){
        return requestQueue.remove(request);
    }

    public static void clear(){
        requestQueue.clear();
    }

    public static boolean isEmpty(){
        return requestQueue.isEmpty();
    }

}
