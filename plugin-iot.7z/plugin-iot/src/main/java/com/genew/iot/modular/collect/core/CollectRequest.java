package com.genew.iot.modular.collect.core;

import com.genew.iot.modular.metric.dto.protocol.*;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
public class CollectRequest implements Serializable {

    // -------------指标基本信息 -----------------
    private String id;  //指标ID 即 后续采集任务的标识
    private String name;  // 指标名称
    private String ownerType; //属主类型： DEVICE , PRODUCT
    private String ownerId;  //属主ID: 产品ID 或 设备ID
    private String ownerName; //属主名称
    private String typeLabel; //设备自定义标签名称

    //------------- 指标采集方式、地址、数据类型-------------
    private String protocol; //采集使用的协议
    private String dataType; //点位数据类型
    private String dataUnit; //数据单位

    // --------------- 采集策略及控制相关-----------------

    private Long intervalTime;  //采集间隔时间
    private Integer delayTime; //任务延迟时间
    private String autoStart; //是否是（保存或修改后）自动开始采集
    private String collectStatus; // 采集状态

    private String beforeScripts; //采集到数据处理脚本（推送前处理脚本）
    private String scriptRtType; // 脚本返回值

    private ProcessResultType beforeScriptsRtType ; // 脚本返回值类型: primitive, json , jsonArray

    private String extJson;

    private String protocolConf; // 协议配置 json字符串

    private String responseProcessors;

    //-------------- 推送到TB的设备标识列表---------------
    private List<String> pushTargetDevIds;

    //以下为各个不同协议封装的对象
    private ModbusTcpProtocolConf modbusTcpProtocolConf;

    private DatabaseProtocolConf databaseProtocolConf;

    private HttpProtocolConf httpProtocolConf;

    private FileProtocolConf fileProtocolConf;

    private OpcUaProtocolConf opcUaConf;

    private TcpProtocolConf tcpProtocolConf;

    private MqttProtocolConf mqttProtocolConf;
}
