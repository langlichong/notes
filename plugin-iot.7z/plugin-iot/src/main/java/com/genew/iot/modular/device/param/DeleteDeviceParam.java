package com.genew.iot.modular.device.param;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.List;

@Setter
@Getter
public class DeleteDeviceParam {

    @NotNull(message = "ids不能为空")
    private List<String> ids;

    @NotNull(message = "cascadeTb不能为空")
    private Boolean cascadeTb;
}
