package com.genew.iot.modular.collect.processors;

import com.genew.iot.modular.collect.core.CollectResponse;
import com.genew.iot.modular.collect.core.AbstractCollectResponseProcessor;
import com.genew.iot.modular.collect.core.ProcessorResult;
import org.springframework.stereotype.Component;

@Component
public class EmptyProcessor extends AbstractCollectResponseProcessor {
    @Override
    public String id() {
        return "EmptyProcessor";
    }

    @Override
    public String name() {
        return "DoNothing";
    }

    @Override
    protected boolean support(CollectResponse response) {
        return true;
    }

    @Override
    protected ProcessorResult doProcess(CollectResponse originCollectResponse, ProcessorResult previousResult) {

        return previousResult;
    }

    @Override
    public int getOrder() {
        return 0;
    }
}
