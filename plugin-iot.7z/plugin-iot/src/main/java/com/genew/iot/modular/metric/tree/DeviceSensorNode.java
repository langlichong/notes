package com.genew.iot.modular.metric.tree;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
public class DeviceSensorNode implements Serializable {

    private String id;
    private String parentId;
    private String name;
    private String type;
    private List<DeviceSensorNode> children;
}
