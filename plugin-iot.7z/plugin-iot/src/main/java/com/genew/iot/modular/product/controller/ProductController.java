/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.product.controller;

import cn.dev33.satoken.annotation.SaCheckPermission;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.common.pojo.CommonValidList;
import com.genew.iot.modular.product.entity.Product;
import com.genew.iot.modular.product.param.ProductAddParam;
import com.genew.iot.modular.product.param.ProductEditParam;
import com.genew.iot.modular.product.param.ProductIdParam;
import com.genew.iot.modular.product.param.ProductPageParam;
import com.genew.iot.modular.product.service.ProductService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 产品控制器
 *
 * @author huhu
 * @date  2023/06/29 15:41
 */
@Api(tags = "产品控制器")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
public class ProductController {

    @Resource
    private ProductService productService;

    /**
     * 获取产品分页
     *
     * @author huhu
     * @date  2023/06/29 15:41
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取产品分页")
    @SaCheckPermission("/iot/product/page")
    @GetMapping("/iot/product/page")
    public CommonResult<Page<Product>> page(ProductPageParam productPageParam) {
        return CommonResult.data(productService.page(productPageParam));
    }

    /**
     * 获取产品列表
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取系统中产品列表")
    @SaCheckPermission("/iot/product/list")
    @GetMapping("/iot/product/list")
    public CommonResult<List<Product>> list() {

        final LambdaQueryWrapper<Product> selectCondition = Wrappers.lambdaQuery(Product.class).select(Product::getId, Product::getName);
        final List<Product> products = productService.list(selectCondition);

        return CommonResult.data(products);
    }

    /**
     * 添加产品
     *
     * @author huhu
     * @date  2023/06/29 15:41
     */
    @ApiOperationSupport(order = 2)
    @ApiOperation("添加产品")
    @CommonLog("添加产品")
    @SaCheckPermission("/iot/product/add")
    @PostMapping("/iot/product/add")
    public CommonResult<String> add(@RequestBody @Valid ProductAddParam productAddParam) {
        productService.add(productAddParam);
        return CommonResult.ok();
    }

    /**
     * 编辑产品
     *
     * @author huhu
     * @date  2023/06/29 15:41
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("编辑产品")
    @CommonLog("编辑产品")
    @SaCheckPermission("/iot/product/edit")
    @PostMapping("/iot/product/edit")
    public CommonResult<String> edit(@RequestBody @Valid ProductEditParam productEditParam) {
        productService.edit(productEditParam);
        return CommonResult.ok();
    }

    /**
     * 删除产品
     *
     * @author huhu
     * @date  2023/06/29 15:41
     */
    @ApiOperationSupport(order = 4)
    @ApiOperation("删除产品")
    @CommonLog("删除产品")
    @SaCheckPermission("/iot/product/delete")
    @PostMapping("/iot/product/delete")
    public CommonResult<String> delete(@RequestBody @Valid @NotEmpty(message = "集合不能为空")
                                                   CommonValidList<ProductIdParam> productIdParamList) {
        productService.delete(productIdParamList);
        return CommonResult.ok();
    }

    /**
     * 获取产品详情
     *
     * @author huhu
     * @date  2023/06/29 15:41
     */
    @ApiOperationSupport(order = 5)
    @ApiOperation("获取产品详情")
    @SaCheckPermission("/iot/product/detail")
    @GetMapping("/iot/product/detail")
    public CommonResult<Product> detail(@Valid ProductIdParam productIdParam) {
        return CommonResult.data(productService.detail(productIdParam));
    }
}
