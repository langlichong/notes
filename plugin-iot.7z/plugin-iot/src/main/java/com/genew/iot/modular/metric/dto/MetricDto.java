package com.genew.iot.modular.metric.dto;

import lombok.Data;

@Data
public class MetricDto {

    private String id;

    private String name;

    private String sensorId;

    private String sensorName;

    private String devId;

    private String devName;

    private String tbId;
}
