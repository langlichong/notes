/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.controller;

import cn.dev33.satoken.annotation.SaCheckPermission;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.param.*;
import com.genew.iot.modular.device.service.DeviceService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 设备台账
 *
 * @author zw
 * @date  2023/03/27 14:44
 */
@Api(tags = "设备台账控制器")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
public class DeviceController {

    @Resource
    private DeviceService deviceService;

    /**
     * 获取设备台账分页
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取设备台账分页")
    @SaCheckPermission("/iot/device/page")
    @GetMapping("/iot/device/page")
    public CommonResult<Page<Device>> page(DevicePageParam devicePageParam) {
        return CommonResult.data(deviceService.page(devicePageParam));
    }

    /**
     * 获取所有设备台账
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取所有设备台账")
    @GetMapping("/iot/device/all")
    public CommonResult<List<Device>> allDevices() {
        final LambdaQueryWrapper<Device> wrapper = Wrappers.lambdaQuery(Device.class).select(Device::getId, Device::getCode, Device::getName);
        return CommonResult.data(deviceService.list(wrapper));
    }

    /**
     * 添加设备台账
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    @ApiOperationSupport(order = 2)
    @ApiOperation("添加设备台账")
    @CommonLog("添加设备台账")
    @SaCheckPermission("/iot/device/add")
    @PostMapping("/iot/device/add")
    public CommonResult<String> add(@RequestBody @Valid DeviceAddParam deviceAddParam) {
        deviceService.add(deviceAddParam);
        return CommonResult.ok();
    }

    /**
     * 编辑设备台账
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("编辑设备台账")
    @CommonLog("编辑设备台账")
    @SaCheckPermission("/iot/device/edit")
    @PostMapping("/iot/device/edit")
    public CommonResult<String> edit(@RequestBody @Valid DeviceEditParam deviceEditParam) {
        deviceService.edit(deviceEditParam);
        return CommonResult.ok();
    }


    @ApiOperationSupport(order = 4)
    @ApiOperation("删除设备台账")
    @CommonLog("删除设备台账")
    @SaCheckPermission("/iot/device/delete")
    @PostMapping("/iot/device/delete")
    public CommonResult<String> delete(@RequestBody DeleteDeviceParam params) {
        deviceService.deleteOnCacade(params);
        return CommonResult.ok();
    }

    /**
     * 获取设备台账详情
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    @ApiOperationSupport(order = 5)
    @ApiOperation("获取设备台账详情")
    @SaCheckPermission("/iot/device/detail")
    @GetMapping("/iot/device/detail")
    public CommonResult<Device> detail(@Valid DeviceIdParam deviceIdParam) {
        return CommonResult.data(deviceService.detail(deviceIdParam));
    }


    /**
     * 获取设备的指标列表
     */
    @ApiOperationSupport(order = 6)
    @ApiOperation("获取设备的指标列表")
    @SaCheckPermission("/iot/device/metrics")
    @GetMapping("/iot/device/metrics")
    public CommonResult<Object> getDeviceMetrics(@RequestParam(value = "id",required = true)String devId) {
        return CommonResult.data(deviceService.listMetrics(devId));
    }

    /**
     * 远端设备控制
     */
    @ApiOperationSupport(order = 7)
    @ApiOperation("远端设备控制")
    @SaCheckPermission("/iot/device/control")
    @PostMapping("/iot/device/control")
    public CommonResult<String> control(@RequestBody @Valid DeviceActionIdParam deviceActionIdParam) {
        deviceService.control(deviceActionIdParam);
        return CommonResult.ok();
    }

}
