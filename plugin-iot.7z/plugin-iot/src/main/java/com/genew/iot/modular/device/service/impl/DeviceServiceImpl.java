/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.genew.common.exception.CommonException;
import com.genew.common.listener.CommonDataChangeEventCenter;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.core.enums.IotDataTypeEnum;
import com.genew.iot.core.util.TbHelper;
import com.genew.iot.modular.collect.core.CollectContext;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.entity.DeviceAction;
import com.genew.iot.modular.device.mapper.DeviceMapper;
import com.genew.iot.modular.device.param.*;
import com.genew.iot.modular.device.service.DeviceActionService;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.device.service.DeviceSyncService;
import com.genew.iot.modular.metric.entity.Metric;
import com.genew.iot.modular.metric.service.MetricService;
import com.genew.iot.modular.product.service.ProductService;
import com.genew.iot.modular.productmetric.service.ProductMetricService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thingsboard.rest.client.RestClient;
import org.thingsboard.server.common.data.id.DeviceId;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 设备台账Service接口实现类
 *
 * @author zw
 * @date 2023/03/27 14:44
 **/
@Service
public class DeviceServiceImpl extends ServiceImpl<DeviceMapper, Device> implements DeviceService {


    @Resource
    private TbHelper tbHelper;

    @Resource
    private DeviceActionService deviceActionService;

    @Resource
    private MetricService metricService;

    @Resource
    private ProductMetricService productMetricService;

    @Resource
    private DeviceSyncService deviceSyncService;

    @Resource
    private ProductService productService;

    @Resource
    private List<AbstractControl> controls;

    @Override
    public Page<Device> page(DevicePageParam devicePageParam) {

        final LambdaQueryWrapper<Device> queryWrapper = Wrappers
                .lambdaQuery(Device.class)
                .select(
                        Device::getId, Device::getCode, Device::getName, Device::getProduct,
                        Device::getOwner, Device::getTbDevId, Device::getTbDevToken, Device::getTypeLabel,
                        Device::getCreateTime, Device::getUpdateTime
                );
        if (ObjectUtil.isNotEmpty(devicePageParam.getCode())) {
            queryWrapper.like(Device::getCode, devicePageParam.getCode());
        }
        if (ObjectUtil.isNotEmpty(devicePageParam.getName())) {
            queryWrapper.like(Device::getName, devicePageParam.getName());
        }
        if (ObjectUtil.isNotEmpty(devicePageParam.getOwner())) {
            queryWrapper.like(Device::getOwner, devicePageParam.getOwner());
        }
        if (ObjectUtil.isNotEmpty(devicePageParam.getTbDevToken())) {
            queryWrapper.like(Device::getTbDevToken, devicePageParam.getTbDevToken());
        }

        queryWrapper.orderByDesc(Device::getUpdateTime, Device::getName);

        final Page<Device> page = this.page(CommonPageRequest.defaultPage(), queryWrapper);

        final List<Device> records = page.getRecords();

        //计算设备绑定的指标数量
        final Set<String> productIds = records.stream().filter(r -> StringUtils.isNotBlank(r.getProduct())).map(Device::getProduct).collect(Collectors.toSet());
        final Set<String> deviceIds = records.stream().map(Device::getId).collect(Collectors.toSet());
        productIds.addAll(deviceIds);
        final List<Metric> metrics = metricService.list(Wrappers.lambdaQuery(Metric.class).in(Metric::getOwnerId, productIds));
        final Map<String, Long> groupByProductMap = metrics.stream().filter(m -> "PRODUCT".equalsIgnoreCase(m.getOwnerType())).collect(Collectors.groupingBy(Metric::getOwnerId, Collectors.counting()));
        final Map<String, Long> groupByDeviceMap = metrics.stream().filter(m -> "DEVICE".equalsIgnoreCase(m.getOwnerType())).collect(Collectors.groupingBy(Metric::getOwnerId, Collectors.counting()));
        final Map<String, Set<String>> protocolMap = metrics.stream().collect(Collectors.toMap(Metric::getOwnerId,
                p -> {
                    Set<String> protocolList = new HashSet<>();
                    protocolList.add(p.getProtocol());
                    return protocolList;
                },
                (Set<String> value1, Set<String> value2) -> {
                    value1.addAll(value2);
                    return value1;
                }
        ));
        records.stream().forEach(device -> {

            final Long n1 = groupByDeviceMap.getOrDefault(device.getId(), 0L);
            final Long n2 = groupByProductMap.getOrDefault(device.getProduct(), 0L);
            device.setMetricNum(n1 + n2);
            device.setProtocolList(protocolMap.get(device.getId()));
        });

        return page;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(DeviceAddParam deviceAddParam) {
        Device device = BeanUtil.toBean(deviceAddParam, Device.class);

        final Date now = new Date();
        device.setCreateTime(now);
        device.setUpdateTime(now);

        this.save(device);

        //同步设备到TB
        if (deviceAddParam.getSync2Tb()) {
            deviceSyncService.sync2Tb(Arrays.asList(device.getId()));
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(DeviceEditParam deviceEditParam) {
        Device device = this.queryEntity(deviceEditParam.getId());
        BeanUtil.copyProperties(deviceEditParam, device);
        this.updateById(device);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<DeviceIdParam> deviceIdParamList) {
        // 执行删除
        this.removeByIds(CollStreamUtil.toList(deviceIdParamList, DeviceIdParam::getId));
    }

    @Override
    public void deleteOnCacade(DeleteDeviceParam params) {

        final List<Device> devices = this.list(Wrappers.lambdaQuery(Device.class).in(Device::getId, params.getIds()));

        final List<Metric> metricList = metricService.list(Wrappers.lambdaQuery(Metric.class).in(Metric::getOwnerId, params.getIds()));
        if (metricList != null && !metricList.isEmpty()) {
            throw new CommonException("设备下有指标，请先删除关联的指标或解绑!");
        }

        // 1. 删除TB 侧设备
        if (params.getCascadeTb()) {
            final RestClient client = tbHelper.login();
            final List<Device> bindDev = devices.stream().filter(dev -> {
                return StringUtils.isNotBlank(dev.getTbDevId());
            }).collect(Collectors.toList());

            Optional.of(bindDev).ifPresent(idList -> {
                idList.forEach(dev -> {
                    // 为尽量减少TB 一侧 与 台账一侧数据不一致性，每次成功删除tb侧设备后，紧接着删除台账侧设备
                    client.deleteDevice(DeviceId.fromString(dev.getTbDevId()));
                    this.removeById(dev.getId());
                });
            });
            client.close();
        }

        //2. 删除设备台账数据
        this.removeBatchByIds(params.getIds());

        //3. 发布删除事件
        CommonDataChangeEventCenter.doDeleteWithDataId(IotDataTypeEnum.DEVICE.getValue(), params.getIds());

    }

    @Override
    public Device detail(DeviceIdParam deviceIdParam) {
        return this.queryEntity(deviceIdParam.getId());
    }

    @Override
    public Device queryEntity(String id) {
        Device device = this.getById(id);
        if (ObjectUtil.isEmpty(device)) {
            throw new CommonException("设备台账不存在，id值为：{}", id);
        }
        return device;
    }

    @Override
    public Object listMetrics(String devId) {

        List<String> res = new ArrayList<>();
        final Device device = getById(devId);
        if (device != null) {

            final List<Metric> privateMetrics = metricService.list(
                    Wrappers.lambdaQuery(Metric.class)
                            .select(Metric::getId, Metric::getName, Metric::getOwnerType)
                            .eq(Metric::getOwnerId, devId)
            );

            final String product = device.getProduct();
            if (StringUtils.isNotBlank(product)) {
                final List<Metric> productLevelMetrics = metricService.list(
                        Wrappers.lambdaQuery(Metric.class)
                                .select(Metric::getId, Metric::getName, Metric::getOwnerType)
                                .eq(Metric::getOwnerId, product));

                privateMetrics.addAll(productLevelMetrics);
            }

            privateMetrics.stream().forEach(metric -> {
                final String ownerType = metric.getOwnerType();
                if (ownerType.equalsIgnoreCase("PRODUCT")) {
                    String name = "产品/".concat(metric.getName());
                    res.add(name);
                } else if (ownerType.equalsIgnoreCase("DEVICE")) {
                    String name = "设备/".concat(metric.getName());
                    res.add(name);
                }
            });
        }

        return res;
    }

    /**
     * 设备远程控制
     * @param deviceActionIdParam
     */
    @Override
    public void control(DeviceActionIdParam deviceActionIdParam) {
        String actionId = deviceActionIdParam.getId();
        DeviceAction deviceAction = deviceActionService.getById(actionId);
        if (Objects.isNull(deviceAction)) {
            throw new CommonException("设备指令不存在，id值为：{}", actionId);
        }
        AbstractControl abstractControl = controls.stream().filter(control -> control.support(deviceAction)).findFirst().orElse(null);
        //远程控制暂仅支持TCP、MQTT协议
        CollectContext.setRemoteControlParam(deviceAction);
        try {
            abstractControl.remoteControl(deviceAction);
        } catch (Exception e) {
            throw new CommonException("设备【{}】远程控制异常，异常原因：{}", deviceAction.getDeviceId(), e.getMessage());
        }
    }
}
