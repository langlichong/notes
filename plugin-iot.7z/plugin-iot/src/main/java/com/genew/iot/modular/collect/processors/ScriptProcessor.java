package com.genew.iot.modular.collect.processors;

import com.genew.iot.modular.collect.core.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.graalvm.polyglot.Context;
import org.graalvm.polyglot.Value;
import org.springframework.stereotype.Component;

/**
 * 脚本引擎：主要用于将采集器直接采集的结果进行标准化
 * 脚本处理结果必须是 JSON 结果
 */
@Slf4j
@Component
public class ScriptProcessor extends AbstractCollectResponseProcessor {

    @Override
    public String id() {
        return "scriptProcessor";
    }

    @Override
    public String name() {
        return "脚本处理器";
    }


    /**
     * 如果指标配置了采集结果处理脚本，则 true 否则 false
     * @param response 指标采集结果封装，可以从里面获取 原始的采集请求 、 指标值、指标值的类型
     * @return
     */
    @Override
    protected boolean support(CollectResponse response) {

        final String beforeScripts = response.getOriginRequest().getBeforeScripts();

        final boolean supported = StringUtils.isNotBlank(beforeScripts);

        return supported;
    }


    @Override
    protected ProcessorResult doProcess(CollectResponse response, ProcessorResult previousResult) {

        if (!support(response)) {
            log.warn("指标【{}】未配置 脚本 !", response.getOriginRequest().getName());
            return previousResult;
        }

        log.info("---scriptProcessor----");
        final CollectRequest originRequest = response.getOriginRequest();

        final String beforeScripts = originRequest.getBeforeScripts();
        ProcessResultType scriptsRtType = originRequest.getBeforeScriptsRtType();
        if(scriptsRtType == null){ // 若指标未配置或其他原因则默认按标量处理
            scriptsRtType = ProcessResultType.PRIMITIVE;
        }

        try {

            String metricVal = executeJsScripts(beforeScripts,response.getCollectResult().toString());

            log.info("script execution result: {}",metricVal);

            previousResult.setResult(metricVal);
            previousResult.setResultType(scriptsRtType);

            log.info("脚本处理结果: {}",previousResult);

            return previousResult;

            } catch(Exception e){
                log.error("脚本片段结果转换异常：", e);
                throw new RuntimeException("脚本片段执行结果无法转换为"+ scriptsRtType.name() +" , 请确认指标【" + response.getOriginRequest().getName() + "】配置的脚本返回值类型!! ");
            }

        }

       private String  executeJsScripts(String funcBody, String param){

            final Context ctx = Context.newBuilder("js").option("engine.WarnInterpreterOnly", "false").allowAllAccess(true).build();

            ctx.eval("js", "function convert(collectResult){" + funcBody + " }");
            final Value convertFunction = ctx.getBindings("js").getMember("convert");
            final Value execute = convertFunction.execute(param);
            final String res = execute.toString();

            ctx.close();

            return res;
        }

    @Override
    public int getOrder() {
        return 0;
    }
}
