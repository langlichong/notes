/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.productmodel.controller;

import cn.dev33.satoken.annotation.SaCheckPermission;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.common.pojo.CommonValidList;
import com.genew.iot.modular.productmodel.entity.ProductModelService;
import com.genew.iot.modular.productmodel.param.ProductModelServiceAddParam;
import com.genew.iot.modular.productmodel.param.ProductModelServiceEditParam;
import com.genew.iot.modular.productmodel.param.ProductModelServiceIdParam;
import com.genew.iot.modular.productmodel.param.ProductModelServicePageParam;
import com.genew.iot.modular.productmodel.service.ProductModelServiceService;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

/**
 * 产品模型-服务控制器
 *
 * @author zw
 * @date  2025/04/21 11:40
 */
@Api(tags = "产品模型-服务控制器")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
public class ProductModelServiceController {

    @Resource
    private ProductModelServiceService productModelServiceService;

    /**
     * 获取产品模型-服务分页
     *
     * @author zw
     * @date  2025/04/21 11:40
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取产品模型-服务分页")
    @SaCheckPermission("/iot/productmodel/service/page")
    @GetMapping("/iot/productmodel/service/page")
    public CommonResult<Page<ProductModelService>> page(ProductModelServicePageParam productModelServicePageParam) {
        return CommonResult.data(productModelServiceService.page(productModelServicePageParam));
    }

    /**
     * 添加产品模型-服务
     *
     * @author zw
     * @date  2025/04/21 11:40
     */
    @ApiOperationSupport(order = 2)
    @ApiOperation("添加产品模型-服务")
    @CommonLog("添加产品模型-服务")
    @SaCheckPermission("/iot/productmodel/service/add")
    @PostMapping("/iot/productmodel/service/add")
    public CommonResult<String> add(@RequestBody @Valid ProductModelServiceAddParam productModelServiceAddParam) {
        productModelServiceService.add(productModelServiceAddParam);
        return CommonResult.ok();
    }

    /**
     * 编辑产品模型-服务
     *
     * @author zw
     * @date  2025/04/21 11:40
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("编辑产品模型-服务")
    @CommonLog("编辑产品模型-服务")
    @SaCheckPermission("/iot/productmodel/service/edit")
    @PostMapping("/iot/productmodel/service/edit")
    public CommonResult<String> edit(@RequestBody @Valid ProductModelServiceEditParam productModelServiceEditParam) {
        productModelServiceService.edit(productModelServiceEditParam);
        return CommonResult.ok();
    }

    /**
     * 删除产品模型-服务
     *
     * @author zw
     * @date  2025/04/21 11:40
     */
    @ApiOperationSupport(order = 4)
    @ApiOperation("删除产品模型-服务")
    @CommonLog("删除产品模型-服务")
    @SaCheckPermission("/iot/productmodel/service/delete")
    @PostMapping("/iot/productmodel/service/delete")
    public CommonResult<String> delete(@RequestBody @Valid @NotEmpty(message = "集合不能为空")
                                                   CommonValidList<ProductModelServiceIdParam> productModelServiceIdParamList) {
        productModelServiceService.delete(productModelServiceIdParamList);
        return CommonResult.ok();
    }

    /**
     * 获取产品模型-服务详情
     *
     * @author zw
     * @date  2025/04/21 11:40
     */
    @ApiOperationSupport(order = 5)
    @ApiOperation("获取产品模型-服务详情")
    @SaCheckPermission("/iot/productmodel/service/detail")
    @GetMapping("/iot/productmodel/service/detail")
    public CommonResult<ProductModelService> detail(@Valid ProductModelServiceIdParam productModelServiceIdParam) {
        return CommonResult.data(productModelServiceService.detail(productModelServiceIdParam));
    }
}
