package com.genew.iot.modular.collect.pool;

import com.genew.iot.modular.metric.dto.protocol.ModbusTcpProtocolConf;
import com.ghgande.j2mod.modbus.facade.ModbusTCPMaster;
import org.apache.commons.pool2.impl.GenericObjectPool;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class ConnectionHolder {
    private static ConcurrentMap<ModbusTcpProtocolConf, GenericObjectPool<ModbusTCPMaster>> connectionPoolMap = new ConcurrentHashMap<>();

    public static int size(){
        return connectionPoolMap.size();
    }

    public static GenericObjectPool<ModbusTCPMaster> get(ModbusTcpProtocolConf key){
        return connectionPoolMap.get(key);
    }

    public static void add(ModbusTcpProtocolConf key,GenericObjectPool<ModbusTCPMaster> connPool){
        connectionPoolMap.put(key, connPool);
    }

    public static void clearHolder(){
        for (GenericObjectPool<ModbusTCPMaster> connPool : ConnectionHolder.connectionPoolMap.values()) {
            connPool.clear();
        }
        connectionPoolMap.clear();
    }
}
