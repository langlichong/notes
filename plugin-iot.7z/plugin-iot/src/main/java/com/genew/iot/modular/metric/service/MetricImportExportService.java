package com.genew.iot.modular.metric.service;

import cn.hutool.json.JSONObject;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

public interface MetricImportExportService {

    void downloadTemplate(HttpServletResponse response);


    JSONObject importMetrics(MultipartFile file);
}
