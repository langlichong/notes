/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.genew.common.exception.CommonException;
import com.genew.iot.core.util.TbHelper;
import com.genew.iot.modular.collect.core.CollectManager;
import com.genew.iot.modular.collect.core.CollectRequest;
import com.genew.iot.modular.collect.core.MetricStatus;
import com.genew.iot.modular.collect.core.TaskId;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.enums.TbAttributeScopes;
import com.genew.iot.modular.device.mapper.DeviceMapper;
import com.genew.iot.modular.device.param.DeviceCredentialParam;
import com.genew.iot.modular.device.param.DeviceSyncParam;
import com.genew.iot.modular.device.param.PostTelemetryParam;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.device.service.DeviceSyncService;
import com.genew.iot.modular.metric.entity.Metric;
import com.genew.iot.modular.metric.service.MetricService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.thingsboard.rest.client.RestClient;
import org.thingsboard.server.common.data.id.DeviceId;
import org.thingsboard.server.common.data.kv.AttributeKvEntry;
import org.thingsboard.server.common.data.kv.TsKvEntry;
import org.thingsboard.server.common.data.security.DeviceCredentials;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 设备台账 同步 Thingsboard
 *
 * @author zw
 * @date  2023/03/27 14:44
 **/
@Slf4j
@Service
public class DeviceSyncServiceImpl extends ServiceImpl<DeviceMapper, Device> implements DeviceSyncService {


    @Resource
    private TbHelper tbHelper;

    @Resource
    private DeviceService deviceService;

    @Resource
    private MetricService metricService;

    @Resource
    private CollectManager collectManager;

    @Override
    public JSONArray sync2Tb(List<String> ids) {

        final JSONArray res = JSONUtil.createArray();

        // 勾选的预同步的设备
        final LambdaQueryWrapper<Device> where = Wrappers.lambdaQuery(Device.class);
        if(ObjectUtil.isNotNull(ids)){
            where.in(Device::getId,ids);
        }

        final List<Device> devices = this.list(where);

        RestClient restClient = tbHelper.login();

        // 设备创建到Thingsboard , 创建成功则将返回的设备ID回填到三方设备表以建立映射关系
        Map<String,String> idMappings = new HashMap<>(); // <三方设备ID,Thingsboard设备ID>
        Map<String,String> devTokenMappings = new HashMap<>(); // 设备ID 与设备token关联关系
        for (Device party3Device : devices) {

            org.thingsboard.server.common.data.Device device = new org.thingsboard.server.common.data.Device();
            // 三方设备的所属系统编号作为TB的设备配置
            device.setName(party3Device.getCode());
            device.setLabel(party3Device.getName());
            device.setType(party3Device.getOwner());

            // 设备在TB 中 token 默认值为: 设备属主 + 设备编码
            String token = party3Device.getTbDevToken();
            if(StringUtils.isBlank(token)){
                token = party3Device.getOwner().concat(party3Device.getCode());
            }

            try{
                // 1. 同步基本信息: 在TB 侧创建设备、设备token、设备Profile
                org.thingsboard.server.common.data.Device tbDevice = restClient.saveDevice(device, token);
                final cn.hutool.json.JSONObject syncMsg = JSONUtil.createObj().set("name", party3Device.getName()).set("success", true).set("msg", "同步成功");
                res.add(syncMsg);

                devTokenMappings.put(party3Device.getId(),token);
                idMappings.put(party3Device.getId(),tbDevice.getId().toString());

                // todo 2. 同步设备属性

            }catch (Exception e){
                String message = e.getMessage();
                if(e instanceof HttpClientErrorException.BadRequest){
                    String responseBodyAsString = ((HttpClientErrorException.BadRequest) e).getResponseBodyAsString();
                    try {
                        message = JSONObject.parseObject(responseBodyAsString).getString("message");
                    } catch (Exception exception) {
                        message = responseBodyAsString;
                    }
                }
                final cn.hutool.json.JSONObject failMsg = JSONUtil.createObj().set("name", party3Device.getName()).set("success",false).set("msg", message);
                res.add(failMsg);
            }
        }

        log.info("设备台账与Thingsboard 设备对应关系: {}",idMappings);

        // 3. 如果回写 TB 设备 ID 到 device 表失败,需要回退操作： 删除已经创建的设备
        boolean bindOkOrNot = updateRefTbDevice(idMappings,devTokenMappings);
        if(!bindOkOrNot){
            for(String tbDevId: idMappings.values()){
                restClient.deleteDevice(DeviceId.fromString(tbDevId));
            }
        }

        restClient.logout();

        log.info("更新 IotDevice#tbDevId: {}",bindOkOrNot);

        return res;
    }

    /**
     * 创建 TB 设备属性 (静态属性：如客户端、服务端、共享属性)
     * @param deviceId 设备ID
     * @param jsonString 设备属性对应JSON
     * @param scope 参考 TbAttributeScopes
     */
    private boolean createMultiplePropsWithScope(RestClient client,String deviceId, String jsonString, TbAttributeScopes scope) throws JsonProcessingException {

        if (scope == null) {
            scope = TbAttributeScopes.SHARED_SCOPE;
        }

        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode attrJson = objectMapper.readTree(jsonString);

        boolean created = client.saveDeviceAttributes(DeviceId.fromString(deviceId), scope.name(), attrJson);

        return created;
    }

    @Override
    public boolean updateRefTbDevice(Map<String,String> idMappings,Map<String,String> devTokenMappings){

        if(idMappings == null || idMappings.isEmpty()){
            return false;
        }

        boolean bindOkOrNot = false;
        try {
            LambdaQueryWrapper<Device> where = Wrappers.lambdaQuery();
            where.in(Device::getId,idMappings.keySet());

            List<Device> devices = this.list(where);
            for(Device device: devices){
                device.setTbDevId(idMappings.get(device.getId()));
                device.setTbDevToken(devTokenMappings.get(device.getId()));
            }

            bindOkOrNot = this.saveOrUpdateBatch(devices);

        } catch (Exception e) {
            throw new CommonException(500,"三方设备同步到Thingsboard异常");
        }

        return bindOkOrNot;
    }

    @Override
    public cn.hutool.json.JSONObject changeDeviceCredentials(DeviceCredentialParam param) {

        final cn.hutool.json.JSONObject res = JSONUtil.createObj();
        final RestClient client = tbHelper.login();
        client.getDeviceCredentialsByDeviceId(DeviceId.fromString(param.getTbDeviceId()))
                .ifPresent( credentials -> {
                    credentials.setCredentialsValue(param.getTokenValue());
                    final DeviceCredentials newOne = client.saveDeviceCredentials(credentials);
                    if(StrUtil.equals(param.getTokenValue(),newOne.getCredentialsValue())){
                        res.set("sucess",true);
                    }else{
                        res.set("sucess",false);
                    }

                });

        client.logout();

        return res;
    }

    @Override
    public boolean postTelemetry(PostTelemetryParam param) {

        boolean res = false;
        final Device dev = this.deviceService.getById(param.getDeviceId());
        if(dev == null || StringUtils.isBlank(dev.getTbDevId())){
            throw new CommonException("操作不合法：设备不存在或设备未关联");
        }

        final RestClient client = tbHelper.login();
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode datapoint = objectMapper.readTree(param.getTelemetryContent());
            res = client.saveEntityTelemetry(DeviceId.fromString(dev.getTbDevId()),"any",datapoint);
            client.logout();
        } catch (JsonProcessingException e) {
            log.error("遥测失败：",e);
            throw new CommonException("遥测失败");
        }finally {
            client.logout();
        }

        return res;
    }

    @Override
    public Object getLatestTelemetries(String deviceId) {

        final Device dev = this.deviceService.getById(deviceId);
        if(dev == null || StringUtils.isBlank(dev.getTbDevId())){
            throw new CommonException("操作不合法：设备不存在或设备未关联");
        }

        final RestClient client = tbHelper.login();
        final DeviceId entityId = DeviceId.fromString(dev.getTbDevId());
        final List<String> timeseriesKeys = client.getTimeseriesKeys(entityId);
        final List<TsKvEntry> latestTimeseries = client.getLatestTimeseries(entityId, timeseriesKeys);

        if(Objects.nonNull(latestTimeseries)){

            final List<cn.hutool.json.JSONObject> datapoints = latestTimeseries.stream().map(tsKv -> {
                return JSONUtil.createObj().set(tsKv.getKey(), tsKv.getValue()).set("time", DateUtil.toLocalDateTime(DateUtil.date(tsKv.getTs())));
            }).collect(Collectors.toList());

            return datapoints;
        }
        client.logout();

        return Collections.emptyList();
    }

    @Override
    public Object getDeviceStates(String deviceId) {

        final Device device = this.deviceService.getById(deviceId);
        if(device == null || StringUtils.isBlank(device.getTbDevId())){
            throw new CommonException("设备不存在 或 未关联");
        }
        final RestClient client = tbHelper.login();

        final List<AttributeKvEntry> activeAttrs = client.getAttributesByScope(
                DeviceId.fromString(device.getTbDevId()),
                TbAttributeScopes.SERVER_SCOPE.name(),
                Arrays.asList("active","lastActivityTime","inactivityAlarmTime","inactivityTimeout","lastDisconnectTime","lastConnectTime","lastActivityTime")
        );


        if(Objects.nonNull(activeAttrs)){
            final List<cn.hutool.json.JSONObject> stateAttrs = activeAttrs.stream().map(
                    entry -> JSONUtil.createObj().set("key", entry.getKey()).set("value",entry.getValue()).set("lastUpdateTs", entry.getLastUpdateTs())
            ).collect(Collectors.toList());

            return stateAttrs;
        }

        return Collections.emptyList();
    }

    @Override
    public void collectData(List<String> ids) {

        // 1. 计算设备的指标(包括继承的指标)

        // 已经同步TB的设备列表
        final List<Device> targetDevices = qryAllSyncDevice(ids);
        if(targetDevices == null || targetDevices.isEmpty()){
            throw new CommonException("所选设备没有同步到TB，跳过数据采集!");
        }
        final Map<String, String> devIdAndTbIdMap = targetDevices.stream().collect(Collectors.toMap(Device::getId, Device::getTbDevId));

        final List<Metric> metrics = getDeviceMetricList(targetDevices);

        log.info("本次满足采集条件的指标总数: {} ",metrics.size());

        // 2. 构造采集任务并发送到任务队列
        for (Metric metric : metrics) {

            final CollectRequest request = BeanUtil.toBean(metric, CollectRequest.class);

            if("PRODUCT".equalsIgnoreCase(metric.getOwnerType())){ //产品上的指标可能需要推送到多个设备

                final String productId = metric.getOwnerId();
                final List<String> push2tbIds = targetDevices.stream().filter(device -> device.getProduct().equalsIgnoreCase(productId)).map(Device::getTbDevId).collect(Collectors.toList());

                request.setPushTargetDevIds(push2tbIds);

            }else{
                request.setPushTargetDevIds(Arrays.asList(devIdAndTbIdMap.get(metric.getOwnerId())));
            }

            collectManager.submitCollectingRequest(request);
        }

        // todo 修改设备采集状态(设备目前无状态字段, 若需修改状态，则需解决场景：某设备有 2 个指标已经采采集中，若后续又绑定了新的指标，则绑定的新指标是否需要马上进入采集状态???)


        // 修改指标运行状态
        final Set<String> metricIds = metrics.stream().map(Metric::getId).collect(Collectors.toSet());
        metricService.update(
                Wrappers.lambdaUpdate(Metric.class)
                        .in(Metric::getId,metricIds)
                        .set(Metric::getCollectStatus, MetricStatus.RUNNING.name())
        );

    }

    @Override
    public void stopCollectData(List<String> selectedIds) {

        // todo 停止采集时：若某个指标绑定到的是产品，即同时有多个设备共享该指标，则存在强制停止或者提醒用户问题
        // todo 此处默认强制停止指标采集，以指标为粒度(此处可以看到采集开始时候采用指标分裂的好处: 停止某个设备采集的时候并不会影响其他设备的数据采集)
        final LambdaQueryWrapper<Device> where = Wrappers.lambdaQuery(Device.class).in(Device::getId, selectedIds);
        final List<Device> devices = deviceService.list(where);

        // 设备私有的指标
        final List<Metric> deviceLevelMetrics = metricService.list(Wrappers.lambdaQuery(Metric.class).in(Metric::getOwnerId, selectedIds));

        // 设备继承的指标
        final Set<String> productIds = devices.stream().map(Device::getProduct).collect(Collectors.toSet());
        final List<Metric> productLevelMetrics = metricService.list(Wrappers.lambdaQuery(Metric.class).in(Metric::getOwnerId, productIds));

        List<Metric> allMetrics = new ArrayList<>();
        allMetrics.addAll(deviceLevelMetrics);
        allMetrics.addAll(productLevelMetrics);

        Set<String> metricIds = new HashSet<>();

        //停止指标采集任务
        for (Metric metric : allMetrics) {
            metricIds.add(metric.getId());
            collectManager.cancelTask(TaskId.fromString(metric.getId()));
        }

        // 修改指标运行状态
        metricService.update(
                Wrappers.lambdaUpdate(Metric.class)
                        .in(Metric::getId,metricIds)
                        .set(Metric::getCollectStatus, MetricStatus.STOPPED.name())
        );


    }

    private List<Device> qryAllSyncDevice(List<String> deviceIds) {
        log.info("-----设备数据采集：过滤为同步到TB的设备---------");
        final LambdaQueryWrapper<Device> where = Wrappers.lambdaQuery(Device.class).isNotNull(Device::getTbDevId);
        if(deviceIds != null && !deviceIds.isEmpty()){//所有设备
            where.in(Device::getId, deviceIds);
        }
        final List<Device> targetDevices = deviceService.list(where);
        return targetDevices;
    }

    /**
     * 获取已经同步到TB的所有设备的指标（包括设备从产品继承的指标）
     * 注：未同步到 TB 侧设备不参与数据采集 ，若ids为空，则查询所有设备的所有指标
     * @param targetDevices 设备id列表
     */
    private List<Metric> getDeviceMetricList(List<Device> targetDevices) {

        final Set<String> targetDevIds = targetDevices.stream().map(Device::getId).collect(Collectors.toSet());

        final Set<String> prodIds = targetDevices.stream().filter(d -> StringUtils.isNotBlank(d.getProduct())).map(Device::getProduct).collect(Collectors.toSet());

        Set<String> allOwnerIds = new HashSet<>();
        allOwnerIds.addAll(targetDevIds);
        allOwnerIds.addAll(prodIds);


        // todo 方案 1：  如果某个 指标 是绑定在产品上，有多少个设备继承了该产品，就需要将该指标分裂出多少份，一旦分裂，则停止采集任务时需要知道taskId（需要为新分裂的任务加上自定义taskId），该方案可能存在性能issue或数据一致性问题
        // todo 方案 2： 指标采集阶段不分裂指标，到了推送阶段则需将采集到的值推送到多个设备 (?? 推送阶段应该尽可能保持逻辑 clean，避免与业务产生纠纷 ??)
        final List<Metric> metrics = metricService.list(Wrappers.lambdaQuery(Metric.class).in(Metric::getOwnerId, allOwnerIds));

        return metrics;
    }

    private List<Device> getSelectedDevices(DeviceSyncParam deviceIdParam) {

        final JSONArray res = JSONUtil.createArray();

        // 勾选的预同步的设备
        final LambdaQueryWrapper<Device> where = Wrappers.lambdaQuery(Device.class);
        if(ObjectUtil.isNotNull(deviceIdParam) && StringUtils.isNotBlank(deviceIdParam.getDeviceIds())){
            where.in(Device::getId, deviceIdParam.getDeviceIds().split(","));
        }

        final List<Device> devices = this.list(where);

        return devices;
    }


    /**
     * 根据指标绑定的产品类型进行指标分裂
     * @param targetDevices
     * @param metrics
     */
    private static void produceNewMetricByProduct(List<Device> targetDevices, List<Metric> metrics) {
        for (Metric metric : metrics) { // 采集时候所有的指标都归属到 device上
            if("PRODUCT".equalsIgnoreCase(metric.getOwnerType())){
                final String ownerId = metric.getOwnerId();
                final Set<Device> devicesExtendProduct = targetDevices.stream().filter(d -> ownerId.equalsIgnoreCase(d.getProduct())).collect(Collectors.toSet());
                for (Device d : devicesExtendProduct) {

                    Metric newOne = new Metric();
                    BeanUtil.copyProperties(metric, newOne);

                    //分裂的指标的ID
                    newOne.setId(d.getId().concat("@").concat(metric.getOwnerId())); // deviceId@productId
                    newOne.setOwnerId(d.getId());

                    metrics.add(newOne);
                }
            }
        }
    }
}
