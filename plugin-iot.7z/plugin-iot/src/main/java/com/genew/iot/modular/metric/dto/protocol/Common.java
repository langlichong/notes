package com.genew.iot.modular.metric.dto.protocol;

public class Common {


}
