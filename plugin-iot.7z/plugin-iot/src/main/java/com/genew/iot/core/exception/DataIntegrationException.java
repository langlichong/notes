package com.genew.iot.core.exception;

import lombok.Data;

@Data
public class DataIntegrationException extends Exception {

    public DataIntegrationException(String message) {
        super(message);
    }

    public DataIntegrationException(String message, Throwable cause) {
        super(message, cause);
    }
}
