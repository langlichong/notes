package com.genew.iot.modular.collect.collector;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.iot.core.config.MqttConfig;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.core.util.MqttUtil;
import com.genew.iot.modular.collect.core.*;
import com.genew.iot.modular.metric.dto.protocol.MqttProtocolConf;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.paho.client.mqttv3.IMqttMessageListener;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Objects;

/**
 * Mqtt订阅采集
 *
 * @author js
 * @date Create on 2023/7/3
 */
@Slf4j
@Component
public class MqttSubCollector extends AbstractCollector<Map, Map> {

    public static final Map<String, String> mqttCache = Maps.newConcurrentMap();

    @Resource
    protected MqttUtil mqttUtil;

    @Override
    @ExceptionLog(value = "Mqtt订阅采集", type = LogTypes.collectData)
    protected CollectResponse<Map, Map> collectData() throws DataIntegrationException {
        final CollectRequest request = CollectContext.getRequest();
        final MqttProtocolConf protocolConf = request.getMqttProtocolConf();
        log.info("--Mqtt订阅采集指标: {}", request.getId().concat(StrUtil.AT).concat(protocolConf.toString()));
        Object object = gatherMqttSubData(request, protocolConf);
        log.info("【mqtt】:接收到的信息:{}", object);
        CollectResponse response = CollectResponse.builder()
                .originRequest(request)
                .collectResult(object)
                .collectResultType(ProcessResultType.JSON)
                .build();
        return response;
    }

    /**
     * 采集Mqtt订阅数据
     *
     * @param request
     * @param protocolConf
     * @return
     */
    private Object gatherMqttSubData(CollectRequest request, MqttProtocolConf protocolConf) throws DataIntegrationException {
        try {
            MqttConfig mqttConfig = mqttUtil.getMqttConfig(protocolConf);
            if (ObjectUtil.isEmpty(mqttConfig)) {
                return StrUtil.EMPTY_JSON;
            }
            if (!mqttUtil.isConnected()) {
                //mqtt连接
                mqttUtil.connect(mqttConfig);
            }
            //mqtt订阅
            mqttUtil.subscribe(mqttConfig.getTopic(), mqttConfig.getQos(), new MqttMessageListener(request));
            Object value = mqttCache.get(protocolConf.getTopic() + StrUtil.UNDERLINE + request.getId());
            if (Objects.nonNull(value)) {
                return value;
            }
        } catch (Exception e) {
            throw new DataIntegrationException("【mqtt】:订阅采集失败", e);
        }
        return StrUtil.EMPTY;
    }

    /**
     * mqtt回调时保存消息内容
     *
     * @param topic
     * @param message
     * @param request
     */
    public void doSaveMqttMessage(String topic, MqttMessage message, CollectRequest request) {
        String messageStr = new String(message.getPayload());
        log.debug("【mqtt】:订阅了主题 topic={}", topic);
        //todo JSONObject jsonObject = JSONUtil.parseObj(messageStr);采集时需指定数据节点，目前数据:System.currentTimeMillis()仅供测试
        mqttCache.put(topic + StrUtil.UNDERLINE + request.getId(), JSONUtil.toJsonStr(messageStr));
        mqttCache.put(request.getId(), topic);
    }


    @Override
    protected boolean abortCollect(TaskId taskId) {
        // 终止采集任务
        abortCollectTask(taskId);
        // 终止采集MqClient
        abortGatheringMqttConnect(taskId);
        return true;
    }

    private void abortGatheringMqttConnect(TaskId taskId) {
        String topicCache = mqttCache.get(taskId.toString());
        // 取消订阅
        mqttUtil.cancelSubscribe(topicCache);
        // 清除缓存
        mqttCache.remove(topicCache);
        mqttCache.remove(topicCache + StrUtil.UNDERLINE + taskId.toString());
    }

    @Override
    protected boolean support(CollectRequest request) {
        if (CollectTypes.MQTT_SUBSCRIBE.name().equalsIgnoreCase(request.getProtocol())) {
            return true;
        }
        return false;
    }

    public class MqttMessageListener implements IMqttMessageListener {

        private CollectRequest request;

        public MqttMessageListener(CollectRequest collectRequest) {
            this.request = collectRequest;
        }

        @Override
        public void messageArrived(String topic, MqttMessage message) {
            doSaveMqttMessage(topic, message, request);
        }
    }
}




