package com.genew.iot.modular.thirdapi.interceptor;

import com.genew.iot.core.constant.IotThirdApiConstant;
import com.squareup.okhttp.Interceptor;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

/**
 * @author js
 * @version 1.0
 * @description: 接口重试拦截器
 * @date 2022/9/20 11:08
 */
@Slf4j
public class RetryInterceptor implements Interceptor {
    /**
     * 最大重试次数
     */
    private int maxRetry;

    public RetryInterceptor(String maxRetry) {
        this.maxRetry = Integer.parseInt(maxRetry);
    }

    @Override
    public Response intercept(Interceptor.Chain chain) throws IOException {
        int retryNum = IotThirdApiConstant.RETRY_NUM;
        Request request = chain.request();
        Response response = chain.proceed(request);
        while (!response.isSuccessful() && retryNum < maxRetry) {
            retryNum++;
            log.debug(">>>第{}次发送请求", (retryNum + 1));
            response = chain.proceed(request);
        }
        return response;
    }
}
