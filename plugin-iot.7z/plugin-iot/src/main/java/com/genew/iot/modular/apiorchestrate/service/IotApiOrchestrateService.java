/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.apiorchestrate.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.genew.iot.modular.apiorchestrate.entity.IotApiOrchestrate;
import com.genew.iot.modular.apiorchestrate.param.*;

import java.util.List;
import java.util.Map;

/**
 * API编排Service接口
 *
 * @author js
 * @date 2023/05/04 14:57
 **/
public interface IotApiOrchestrateService extends IService<IotApiOrchestrate> {

    /**
     * 获取API编排分页
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    Page<IotApiOrchestrate> page(IotApiOrchestratePageParam iotApiOrchestratePageParam);

    /**
     * 添加API编排
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    void add(IotApiOrchestrateAddParam iotApiOrchestrateAddParam);

    /**
     * 编辑API编排
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    void edit(IotApiOrchestrateEditParam iotApiOrchestrateEditParam);

    /**
     * 删除API编排
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    void delete(List<IotApiOrchestrateIdParam> iotApiOrchestrateIdParamList);

    /**
     * 获取API编排详情
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    IotApiOrchestrate detail(IotApiOrchestrateIdParam iotApiOrchestrateIdParam);

    /**
     * 获取API编排详情
     *
     * @author js
     * @date 2023/05/04 14:57
     **/
    IotApiOrchestrate queryEntity(String id);

    /**
     * 根据apiSign获取接口数据
     *
     * @param apiSign
     * @return IotApiOrchestrate
     * @author js
     * @date 2023/05/29 10:09
     **/
    IotApiOrchestrate queryEntityByApiSign(String apiSign);

    /**
     * 获取聚合接口数据
     *
     * @param iotApiOrchestrateQueryParam
     * @return
     */
    Map<String, Object> queryThirdApiData(IotApiOrchestrateQueryParam iotApiOrchestrateQueryParam);
}
