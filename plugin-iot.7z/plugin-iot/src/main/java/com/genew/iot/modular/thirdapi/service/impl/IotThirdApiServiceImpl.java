/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.thirdapi.service.impl;

import cn.afterturn.easypoi.cache.manager.POICacheManager;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.cron.CronUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.extra.spring.SpringUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.genew.common.exception.CommonException;
import com.genew.common.page.CommonPageRequest;
import com.genew.common.util.CommonDownloadUtil;
import com.genew.common.util.CommonIpAddressUtil;
import com.genew.common.util.CommonResponseUtil;
import com.genew.common.util.CommonServletUtil;
import com.genew.iot.api.IotThirdDataQueryApi;
import com.genew.iot.core.constant.IotThirdApiConstant;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.core.param.IotThirdApiQueryParam;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.thirdapi.enums.IotThirdApiJobStatusEnum;
import com.genew.iot.modular.thirdapi.enums.IotThirdApiSystemEnum;
import com.genew.iot.modular.thirdapi.mapper.IotThirdApiMapper;
import com.genew.iot.modular.thirdapi.param.*;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import com.genew.iot.modular.thirdapi.service.IotThirdApiTaskService;
import com.google.common.collect.Lists;
import com.google.common.net.InetAddresses;
import lombok.extern.slf4j.Slf4j;
import org.postgresql.util.PSQLException;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

/**
 * 接口管理Service接口实现类
 *
 * @author js
 * @date 2023/03/28 10:09
 **/
@Service
@Slf4j
public class IotThirdApiServiceImpl extends ServiceImpl<IotThirdApiMapper, IotThirdApi> implements IotThirdApiService {

    @Resource
    private IotThirdDataQueryApi iotThirdDataQueryApi;

    @Resource
    private DeviceService deviceService;

    @Resource
    private Environment environment;

    @Override
    public Page<IotThirdApi> page(IotThirdApiPageParam iotThirdApiPageParam) {
        QueryWrapper<IotThirdApi> queryWrapper = new QueryWrapper<>();
        if (ObjectUtil.isNotEmpty(iotThirdApiPageParam.getApiSignIds())) {
            queryWrapper.lambda().in(IotThirdApi::getApiSign, StrUtil.split(iotThirdApiPageParam.getApiSignIds(), StrUtil.COMMA));
        }
        if (ObjectUtil.isNotEmpty(iotThirdApiPageParam.getSystemId())) {
            queryWrapper.lambda().eq(IotThirdApi::getSystemId, iotThirdApiPageParam.getSystemId());
        }
        if (ObjectUtil.isNotEmpty(iotThirdApiPageParam.getApiAlias())) {
            queryWrapper.lambda().like(IotThirdApi::getApiAlias, iotThirdApiPageParam.getApiAlias());
        }
        if (ObjectUtil.isNotEmpty(iotThirdApiPageParam.getRequestMode())) {
            queryWrapper.lambda().eq(IotThirdApi::getRequestMode, iotThirdApiPageParam.getRequestMode());
        }
        queryWrapper.lambda().select(IotThirdApi::getId, IotThirdApi::getApiAlias, IotThirdApi::getApiSign,
                IotThirdApi::getApiScheme, IotThirdApi::getHost, IotThirdApi::getPort, IotThirdApi::getSystemId,
                IotThirdApi::getApiPath, IotThirdApi::getRequestMode, IotThirdApi::getJobStatus,
                IotThirdApi::getTimingEntityId, IotThirdApi::getTimingCron);
        queryWrapper.lambda().orderByDesc(IotThirdApi::getUpdateTime, IotThirdApi::getId, IotThirdApi::getCreateTime);
        return this.page(CommonPageRequest.defaultPage(), queryWrapper);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(IotThirdApiAddParam iotThirdApiAddParam) {
        IotThirdApi iotThirdApi = new IotThirdApi();
        if ("false".equalsIgnoreCase(iotThirdApiAddParam.getAutoStart())) {
            iotThirdApiAddParam.setJobStatus(IotThirdApiJobStatusEnum.STOPPED.name());
        }
        if (IotThirdApiSystemEnum.SYS_DYNAMIC_SQL.getValue().equals(iotThirdApiAddParam.getSystemId())) {
            HttpServletRequest request = CommonServletUtil.getRequest();
            iotThirdApiAddParam.setHost(CommonIpAddressUtil.getIp(request));
            iotThirdApiAddParam.setPort(Integer.parseInt(environment.getProperty("server.port")));
        }
        BeanUtil.copyProperties(iotThirdApiAddParam, iotThirdApi, "pathParam",
                "queryParam",
                "headerParam", "authParam",
                "bodyParam");
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getPathParam())) {
            iotThirdApi.setPathParam(JSONUtil.parseArray(iotThirdApiAddParam.getPathParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getQueryParam())) {
            iotThirdApi.setQueryParam(JSONUtil.parseArray(iotThirdApiAddParam.getQueryParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getHeaderParam())) {
            iotThirdApi.setHeaderParam(JSONUtil.parseArray(iotThirdApiAddParam.getHeaderParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getAuthParam())) {
            iotThirdApi.setAuthParam(JSONUtil.parseObj(iotThirdApiAddParam.getAuthParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getBodyParam())) {
            iotThirdApi.setBodyParam(JSONUtil.parseObj(iotThirdApiAddParam.getBodyParam()));
        }
        String encryptUrl = encryptApiSign(iotThirdApi);
        iotThirdApi.setApiSign(encryptUrl);
        try {
            if (ObjectUtil.isAllNotEmpty(iotThirdApiAddParam.getTimingCron(),
                    iotThirdApiAddParam.getTimingEntityId())) {
                iotThirdApi = this.addIotThirdApiJob(iotThirdApi);
            }
            this.save(iotThirdApi);
        } catch (Exception e) {
            Throwable cause = e.getCause();
            if (cause instanceof PSQLException) {
                String errMsg = (cause).getMessage();
                if (StringUtils.isNotBlank(errMsg) && errMsg.contains(IotThirdApiConstant.API_ADD_EXCEPTIONS)) {
                    throw new CommonException("接口已经存在，请勿重复配置，接口标识:{}", encryptUrl);
                }
            }
            throw new CommonException("参数错误:{}", iotThirdApi);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void copy(IotThirdApiAddParam iotThirdApiAddParam) {
        if (IotThirdApiJobStatusEnum.RUNNING.getValue().equals(iotThirdApiAddParam.getJobStatus())) {
            throw new CommonException("定时轮询中的接口不可复制：{}", iotThirdApiAddParam.getJobStatus());
        }
        if (IotThirdApiSystemEnum.SYS_DYNAMIC_SQL.getValue().equals(iotThirdApiAddParam.getSystemId())) {
            HttpServletRequest request = CommonServletUtil.getRequest();
            iotThirdApiAddParam.setHost(CommonIpAddressUtil.getIp(request));
            iotThirdApiAddParam.setPort(Integer.parseInt(environment.getProperty("server.port")));
            iotThirdApiAddParam.setApiPath(StrUtil.EMPTY);
        } else {
            Random random = new Random();
            // 复制生成随机IP地址
            String ipString = InetAddresses.fromInteger(random.nextInt()).getHostAddress();
            iotThirdApiAddParam.setHost(ipString);
            iotThirdApiAddParam.setPort(8080);
        }
        iotThirdApiAddParam.setApiAlias(iotThirdApiAddParam.getApiAlias() + "-copy");
        IotThirdApi iotThirdApi = new IotThirdApi();
        BeanUtil.copyProperties(iotThirdApiAddParam, iotThirdApi, "pathParam",
                "queryParam",
                "headerParam", "authParam",
                "bodyParam");
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getPathParam())) {
            iotThirdApi.setPathParam(JSONUtil.parseArray(iotThirdApiAddParam.getPathParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getQueryParam())) {
            iotThirdApi.setQueryParam(JSONUtil.parseArray(iotThirdApiAddParam.getQueryParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getHeaderParam())) {
            iotThirdApi.setHeaderParam(JSONUtil.parseArray(iotThirdApiAddParam.getHeaderParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getAuthParam())) {
            iotThirdApi.setAuthParam(JSONUtil.parseObj(iotThirdApiAddParam.getAuthParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiAddParam.getBodyParam())) {
            iotThirdApi.setBodyParam(JSONUtil.parseObj(iotThirdApiAddParam.getBodyParam()));
        }
        String encryptUrl = encryptApiSign(iotThirdApi);
        iotThirdApi.setApiSign(encryptUrl);
        this.save(iotThirdApi);
    }

    private IotThirdApi addIotThirdApiJob(IotThirdApi iotThirdApi) {
        CronUtil.schedule(iotThirdApi.getApiSign(), iotThirdApi.getTimingCron(), () -> {
            // 运行定时任务
            SpringUtil.getBean(IotThirdApiTaskService.class).action(iotThirdApi);
        });
        iotThirdApi.setJobStatus(IotThirdApiJobStatusEnum.RUNNING.getValue());
        return iotThirdApi;
    }

    /**
     * 加密，封装唯一接口标识(加密内容:所属系统@请求方式+Http协议+IP+PORT+接口路径)
     *
     * @param iotThirdApi
     * @return
     */
    private String encryptApiSign(IotThirdApi iotThirdApi) {
        String apiUrl = iotThirdApi.getSystemId().concat("@")
                .concat(iotThirdApi.getRequestMode())
                .concat(iotThirdApi.getApiScheme())
                .concat(iotThirdApi.getHost())
                .concat("" + iotThirdApi.getPort())
                .concat(iotThirdApi.getApiPath());
        return SecureUtil.md5(apiUrl);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(IotThirdApiEditParam iotThirdApiEditParam) {
        if ("false".equalsIgnoreCase(iotThirdApiEditParam.getAutoStart())) {
            iotThirdApiEditParam.setJobStatus(IotThirdApiJobStatusEnum.STOPPED.name());
        }
        if (IotThirdApiJobStatusEnum.RUNNING.getValue().equals(iotThirdApiEditParam.getJobStatus())) {
            throw new CommonException("定时轮询中的接口不可编辑：{}", iotThirdApiEditParam.getJobStatus());
        }

        IotThirdApi iotThirdApi = this.queryEntity(iotThirdApiEditParam.getId());
        BeanUtil.copyProperties(iotThirdApiEditParam, iotThirdApi, "pathParam",
                "queryParam",
                "headerParam", "authParam",
                "bodyParam");
        if (StringUtils.isNotBlank(iotThirdApiEditParam.getPathParam())) {
            iotThirdApi.setPathParam(JSONUtil.parseArray(iotThirdApiEditParam.getPathParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiEditParam.getQueryParam())) {
            iotThirdApi.setQueryParam(JSONUtil.parseArray(iotThirdApiEditParam.getQueryParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiEditParam.getHeaderParam())) {
            iotThirdApi.setHeaderParam(JSONUtil.parseArray(iotThirdApiEditParam.getHeaderParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiEditParam.getAuthParam())) {
            iotThirdApi.setAuthParam(JSONUtil.parseObj(iotThirdApiEditParam.getAuthParam()));
        }
        if (StringUtils.isNotBlank(iotThirdApiEditParam.getBodyParam())) {
            iotThirdApi.setBodyParam(JSONUtil.parseObj(iotThirdApiEditParam.getBodyParam()));
        }
        iotThirdApi.setApiSign(encryptApiSign(iotThirdApi));
        // 判断接口是否已选择定时
        if (IotThirdApiJobStatusEnum.RUNNING.getValue().equals(iotThirdApiEditParam.getJobStatus())) {
            iotThirdApi = this.addIotThirdApiJob(iotThirdApi);
        }
        this.updateById(iotThirdApi);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<IotThirdApiIdParam> iotThirdApiIdParamList) {
        // 执行删除
        this.removeByIds(CollStreamUtil.toList(iotThirdApiIdParamList, IotThirdApiIdParam::getId));
        List<String> iotThirdApiIdList = CollStreamUtil.toList(iotThirdApiIdParamList, IotThirdApiIdParam::getId);
        List<IotThirdApi> iotThirdApiList = this.listByIds(iotThirdApiIdList);
        if (ObjectUtil.isNotEmpty(iotThirdApiList)) {
            List<String> devJobIdList = Lists.newArrayList();
            iotThirdApiList.forEach(iotThirdApi -> {
                if (IotThirdApiJobStatusEnum.RUNNING.getValue().equals(iotThirdApi.getJobStatus())) {
                    devJobIdList.add(iotThirdApi.getApiSign());
                }
            });
            if (ObjectUtil.isNotEmpty(devJobIdList)) {
                // 将运行中的停止
                devJobIdList.forEach(CronUtil::remove);
            }
        }
    }

    @Override
    public IotThirdApi detail(IotThirdApiIdParam iotThirdApiIdParam) {
        IotThirdApi iotThirdApi = new IotThirdApi();
        if (StringUtils.isBlank(iotThirdApiIdParam.getId()) && StringUtils.isBlank(iotThirdApiIdParam.getApiSign())) {
            throw new CommonException("接口不存在，入参为：{}", iotThirdApiIdParam);
        }
        if (StringUtils.isNotBlank(iotThirdApiIdParam.getApiSign())) {
            iotThirdApi = this.queryEntityByApiSign(iotThirdApiIdParam.getApiSign());
        } else if (StringUtils.isNotBlank(iotThirdApiIdParam.getId())) {
            iotThirdApi = this.queryEntity(iotThirdApiIdParam.getId());
        }
        return iotThirdApi;
    }

    @Override
    public IotThirdApi queryEntity(String id) {
        IotThirdApi iotThirdApi = this.getById(id);
        if (ObjectUtil.isEmpty(iotThirdApi)) {
            throw new CommonException("接口不存在，id值为：{}", id);
        }
        return iotThirdApi;
    }

    @Override
    public IotThirdApi queryEntityByApiSign(String apiSign) {
        QueryWrapper<IotThirdApi> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(IotThirdApi::getApiSign, apiSign);
        IotThirdApi iotThirdApi = this.getOne(queryWrapper);
        if (ObjectUtil.isEmpty(iotThirdApi)) {
            throw new CommonException("接口不存在，apiSign值为：{}", apiSign);
        }
        return iotThirdApi;
    }

    @Override
    public List<IotThirdApi> queryEntityByApiSigns(List<String> apiSigns) {
        QueryWrapper<IotThirdApi> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().in(IotThirdApi::getApiSign, apiSigns);
        queryWrapper.lambda().orderByAsc(IotThirdApi::getApiSign);
        List<IotThirdApi> iotThirdApiList = this.list(queryWrapper);
        if (ObjectUtil.isEmpty(iotThirdApiList)) {
            throw new CommonException("接口不存在，apiSigns值为：{}", apiSigns);
        }
        return iotThirdApiList;
    }

    /**
     * 查询三方接口数据
     *
     * @param iotThirdApiQueryParam
     * @return
     */
    @Override
    public Map<String, Object> queryThirdApiData(IotThirdApiQueryParam iotThirdApiQueryParam) {
        return iotThirdDataQueryApi.queryThirdApiData(iotThirdApiQueryParam);
    }

    /**
     * 获取接口列表
     *
     * @param iotThirdApiListParam
     * @return
     */
    @Override
    public List<IotThirdApi> list(IotThirdApiListParam iotThirdApiListParam) {
        QueryWrapper<IotThirdApi> queryWrapper = new QueryWrapper<>();
        if (StringUtils.isNotBlank(iotThirdApiListParam.getSystemId())) {
            queryWrapper.lambda().eq(IotThirdApi::getSystemId, iotThirdApiListParam.getSystemId());
        }
        queryWrapper.lambda().select(IotThirdApi::getId, IotThirdApi::getApiSign, IotThirdApi::getApiAlias);
        return this.list(queryWrapper);
    }

    @Override
    public void downloadImportTemplate(HttpServletResponse response) throws IOException {
        try {
            InputStream inputStream = POICacheManager.getFile("thirdApiImportTemplate.xlsx");
            byte[] bytes = IoUtil.readBytes(inputStream);
            CommonDownloadUtil.download("接口下载模板.xlsx", bytes, response);
        } catch (Exception e) {
            log.error(">>>接口导入模板下载失败，原因{}", e.getMessage());
            CommonResponseUtil.renderError(response, "接口导入模板下载失败");
        }
    }

    @Override
    public JSONObject importBatchIotThirdApi(MultipartFile file) {
        try {
            int successCount = 0;
            int errorCount = 0;
            JSONArray errorDetail = JSONUtil.createArray();
            // 创建临时文件
            File tempFile = FileUtil.writeBytes(file.getBytes(), FileUtil.file(FileUtil.getTmpDir() +
                    FileUtil.FILE_SEPARATOR + "thirdApiImportTemplate.xlsx"));
            // 读取excel
            List<IotThirdApiImportParam> iotThirdApiImportParams = EasyExcel.read(tempFile).head(IotThirdApiImportParam.class).sheet()
                    .headRowNumber(2).doReadSync();
            List<IotThirdApi> allApiList = this.list();
            for (int i = 0; i < iotThirdApiImportParams.size(); i++) {
                JSONObject jsonObject = this.doImport(allApiList, iotThirdApiImportParams.get(i), i);
                if (jsonObject.getBool("success")) {
                    successCount += 1;
                } else {
                    errorCount += 1;
                    errorDetail.add(jsonObject);
                }
            }
            return JSONUtil.createObj()
                    .set("totalCount", iotThirdApiImportParams.size())
                    .set("successCount", successCount)
                    .set("errorCount", errorCount)
                    .set("errorDetail", errorDetail);
        } catch (Exception e) {
            log.error(">>>接口导入失败，原因{}", e.getMessage());
            throw new CommonException("接口导入失败{}", e.getMessage());
        }
    }

    /**
     * 执行导入
     *
     * @author xuyuxiang
     * @date 2023/3/7 13:22
     **/
    public JSONObject doImport(List<IotThirdApi> allApiList, IotThirdApiImportParam iotThirdApiImportParam, int i) {
        String apiAlias = iotThirdApiImportParam.getApiAlias();
        String apiScheme = iotThirdApiImportParam.getApiScheme();
        String host = iotThirdApiImportParam.getHost();
        String port = iotThirdApiImportParam.getPort();
        String requestMode = iotThirdApiImportParam.getRequestMode();
        String apiPath = iotThirdApiImportParam.getApiPath();
        String systemId = iotThirdApiImportParam.getSystemId();
        IotThirdApi iotThirdApi;
        iotThirdApi = BeanUtil.toBeanIgnoreError(iotThirdApiImportParam, IotThirdApi.class);
        // 校验必填参数
        if (ObjectUtil.hasEmpty(apiAlias, apiScheme, host, port, requestMode, apiPath, systemId)) {
            return JSONUtil.createObj().set("index", i + 1).set("success", false).set("msg", "必填字段存在空值");
        } else {
            try {
                String encryptUrl = encryptApiSign(iotThirdApi);
                // 查找账号对应索引
                int index = CollStreamUtil.toList(allApiList, IotThirdApi::getApiSign).indexOf(encryptUrl);

                boolean isAdd = false;
                if (index == -1) {
                    isAdd = true;
                } else {
                    iotThirdApi = allApiList.get(index);
                }
                // 拷贝属性
                BeanUtil.copyProperties(iotThirdApiImportParam, iotThirdApi, true);
                iotThirdApi.setApiSign(encryptUrl);
                if (isAdd) {
                    // 设置id
                    iotThirdApi.setId(IdWorker.getIdStr());
                    // 更新全部用户
                    allApiList.add(iotThirdApi);
                } else {
                    // 删除指定索引元素
                    allApiList.remove(index);
                    // 插入指定索引元素
                    allApiList.add(index, iotThirdApi);
                }
                // 保存或更新
                this.saveOrUpdate(iotThirdApi);
                // 返回成功
                return JSONUtil.createObj().set("success", true);
            } catch (Exception e) {
                log.error(">>>接口导入异常，原因{}", e.getMessage());
                return JSONUtil.createObj().set("success", false).set("index", i + 1).set("msg", "数据导入异常");
            }
        }
    }

    @Override
    public void exportBatchIotThirdApi(IotThirdApiListParam iotThirdApiListParam, HttpServletResponse response) throws IOException {
        File destTemplateFile = null;
        try {
            QueryWrapper<IotThirdApi> queryWrapper = new QueryWrapper<>();
            if (ObjectUtil.isNotEmpty(iotThirdApiListParam.getIotThirdApiIds())) {
                queryWrapper.lambda().in(IotThirdApi::getId, iotThirdApiListParam.getIotThirdApiIds().split(","));
                queryWrapper.lambda().select(IotThirdApi::getApiAlias, IotThirdApi::getApiSign, IotThirdApi::getSystemId,
                        IotThirdApi::getRequestMode, IotThirdApi::getApiScheme, IotThirdApi::getHost, IotThirdApi::getPort,
                        IotThirdApi::getApiPath, IotThirdApi::getJsonPath);
            }
            List<IotThirdApi> iotThirdApiList = this.list(queryWrapper);
            // 读取模板流
            InputStream inputStream = POICacheManager.getFile("thirdApiExportTemplate.xlsx");
            // 创建一个临时模板
            destTemplateFile = FileUtil.writeFromStream(inputStream, FileUtil.file(FileUtil.getTmpDir() +
                    File.separator + "thirdApiExportTemplate.xlsx"));
            // 生成excel
            EasyExcel.write(destTemplateFile.getPath(), IotThirdApiExportParam.class).sheet("接口管理列表")
                    .doWrite(iotThirdApiList);
            // 下载
            CommonDownloadUtil.download(destTemplateFile, response);
        } catch (Exception e) {
            log.error(">>>导出失败，原因{}", e.getMessage());
            CommonResponseUtil.renderError(response, "导出失败");
        } finally {
            // 删除临时文件
            if (ObjectUtil.isNotEmpty(destTemplateFile)) {
                FileUtil.del(destTemplateFile);
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void runJob(IotThirdApi iotThirdApiSignParam) {
        IotThirdApi iotThirdApi = this.queryEntityByApiSign(iotThirdApiSignParam.getApiSign());
        if (IotThirdApiJobStatusEnum.RUNNING.getValue().equals(iotThirdApi.getJobStatus())) {
            throw new CommonException("定时任务已经处于运行状态，apiSign值为：{}", iotThirdApi.getApiSign());
        }
        if (StringUtils.isBlank(iotThirdApi.getTimingEntityId())) {
            throw new CommonException("接口未选择设备，apiSign值为：{}", iotThirdApi.getApiSign());
        }
        CronUtil.schedule(iotThirdApi.getApiSign(), iotThirdApi.getTimingCron(), () -> {
            // 运行定时任务
            SpringUtil.getBean(IotThirdApiTaskService.class).action(iotThirdApi);
        });
        this.update(new LambdaUpdateWrapper<IotThirdApi>().eq(IotThirdApi::getApiSign, iotThirdApi.getApiSign())
                .set(IotThirdApi::getJobStatus, IotThirdApiJobStatusEnum.RUNNING.getValue()));
        log.info(" -------------- 启动定时轮询接口成功--------------，任务ID：{}", iotThirdApi.getApiSign());
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void runJobNow(IotThirdApiSignParam iotThirdApiSignParam) {
        IotThirdApi iotThirdApi = this.queryEntityByApiSign(iotThirdApiSignParam.getApiSign());
        if (IotThirdApiJobStatusEnum.STOPPED.getValue().equals(iotThirdApi.getJobStatus())) {
            // 如果是停止的，则先开启运行
            this.runJob(iotThirdApi);
        }
        // 直接运行一次
        SpringUtil.getBean(IotThirdApiTaskService.class).action(iotThirdApi);
    }

    @Override
    public Device getDeviceByTimingEntityId(IotThirdApi iotThirdApi) {
        Device device = deviceService.getById(iotThirdApi.getTimingEntityId());
        if (Objects.isNull(device) || StringUtils.isBlank(device.getTbDevId())) {
            throw new CommonException("推送遥测的设备不存在或设备未关联，timingEntityId值为：{}", iotThirdApi.getTimingEntityId());
        }
        return device;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void stopJob(IotThirdApi iotThirdApiSignParam) {
        IotThirdApi iotThirdApi = this.queryEntityByApiSign(iotThirdApiSignParam.getApiSign());
        if (IotThirdApiJobStatusEnum.STOPPED.getValue().equals(iotThirdApi.getJobStatus())) {
            throw new CommonException("定时轮询中的接口已经停止，apiSign值为：{}", iotThirdApi.getApiSign());
        }
        // 将运行中的定时任务停止
        CronUtil.remove(iotThirdApi.getApiSign());
        this.update(new LambdaUpdateWrapper<IotThirdApi>().eq(IotThirdApi::getApiSign, iotThirdApi.getApiSign())
                .set(IotThirdApi::getJobStatus, IotThirdApiJobStatusEnum.STOPPED.getValue()));
        log.info(" -------------- 停止定时轮询接口成功 --------------，任务ID：{}", iotThirdApi.getApiSign());
    }

    @PostConstruct
    public void initJob() {
        SpringUtil.getBean(IotThirdApiService.class).list(new LambdaQueryWrapper<IotThirdApi>()
                .eq(IotThirdApi::getJobStatus, IotThirdApiJobStatusEnum.RUNNING.getValue())
                .select(IotThirdApi::getJobStatus, IotThirdApi::getApiSign, IotThirdApi::getTimingCron, IotThirdApi::getTimingEntityId))
                .forEach(iotThirdApi -> CronUtil.schedule(iotThirdApi.getApiSign(), iotThirdApi.getTimingCron(), () -> {
                    // 运行定时任务
                    SpringUtil.getBean(IotThirdApiTaskService.class).action(iotThirdApi);
                }));
    }

}
