package com.genew.iot.modular.collect.customized.ba4;

import lombok.Data;

/**
 * @author : renqiang
 * @date : 2023-03-20 15:39
 * @description : 本安4路 上报数据实体
 */
@Data
public class Ba4Model {


    /**
     * 电源状态信息，交直流供电状态（0-电池供电；1-交流供电）
     */
    private Integer batteryStatus;

    /**
     * 充放电状态（0-正在维护放电；1-未维护放电）
     */
    private Integer dischargeStatus;

    /**
     * 电源电池容量 （0-工作正常；1-无电池）
     */
    private Integer capacity;

    /**
     * 电池容量百分比
     */
    private Integer percentageOfCapacity;

    /**
     * 第一路 状态（0-正常；1-故障）
     */
    private Integer ba1Status;

    /**
     * 第一路 电流值（mA）
     */
    private Integer ba1Electricity;

    /**
     * 第二路 状态（0-正常；1-故障）
     */
    private Integer ba2Status;

    /**
     * 第二路 电流值（mA）
     */
    private Integer ba2Electricity;

    /**
     * 第三路 状态（0-正常；1-故障）
     */
    private Integer ba3Status;

    /**
     * 第三路 电流值（mA）
     */
    private Integer ba3Electricity;

    /**
     * 第四路 状态（0-正常；1-故障）
     */
    private Integer ba4Status;

    /**
     * 第四路 电流值（mA）
     */
    private Integer ba4Electricity;

    /**
     * 电池剩余电量 (单位：aH)    电池容量百分比  * 16aH    =   电池剩余电量 (单位：aH)
     */
    private Double remainingCapacity;

}
