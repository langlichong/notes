/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.productmodel.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.genew.common.enums.CommonSortOrderEnum;
import com.genew.common.exception.CommonException;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.modular.productmodel.entity.ProductModelEvent;
import com.genew.iot.modular.productmodel.mapper.ProductModelEventMapper;
import com.genew.iot.modular.productmodel.param.ProductModelEventAddParam;
import com.genew.iot.modular.productmodel.param.ProductModelEventEditParam;
import com.genew.iot.modular.productmodel.param.ProductModelEventIdParam;
import com.genew.iot.modular.productmodel.param.ProductModelEventPageParam;
import com.genew.iot.modular.productmodel.service.ProductModelEventService;

import java.util.List;

/**
 * 产品模型-事件Service接口实现类
 *
 * @author zw
 * @date  2025/04/21 11:46
 **/
@Service
public class ProductModelEventServiceImpl extends ServiceImpl<ProductModelEventMapper, ProductModelEvent> implements ProductModelEventService {

    @Override
    public Page<ProductModelEvent> page(ProductModelEventPageParam productModelEventPageParam) {
        QueryWrapper<ProductModelEvent> queryWrapper = new QueryWrapper<>();
        if(ObjectUtil.isNotEmpty(productModelEventPageParam.getName())) {
            queryWrapper.lambda().like(ProductModelEvent::getName, productModelEventPageParam.getName());
        }
        if(ObjectUtil.isNotEmpty(productModelEventPageParam.getProductId())) {
            queryWrapper.lambda().eq(ProductModelEvent::getProductId, productModelEventPageParam.getProductId());
        }
        if(ObjectUtil.isAllNotEmpty(productModelEventPageParam.getSortField(), productModelEventPageParam.getSortOrder())) {
            CommonSortOrderEnum.validate(productModelEventPageParam.getSortOrder());
            queryWrapper.orderBy(true, productModelEventPageParam.getSortOrder().equals(CommonSortOrderEnum.ASC.getValue()),
                    StrUtil.toUnderlineCase(productModelEventPageParam.getSortField()));
        } else {
            queryWrapper.lambda().orderByAsc(ProductModelEvent::getId);
        }
        return this.page(CommonPageRequest.defaultPage(), queryWrapper);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(ProductModelEventAddParam productModelEventAddParam) {
        ProductModelEvent productModelEvent = BeanUtil.toBean(productModelEventAddParam, ProductModelEvent.class);
        this.save(productModelEvent);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(ProductModelEventEditParam productModelEventEditParam) {
        ProductModelEvent productModelEvent = this.queryEntity(productModelEventEditParam.getId());
        BeanUtil.copyProperties(productModelEventEditParam, productModelEvent);
        this.updateById(productModelEvent);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<ProductModelEventIdParam> productModelEventIdParamList) {
        // 执行删除
        this.removeByIds(CollStreamUtil.toList(productModelEventIdParamList, ProductModelEventIdParam::getId));
    }

    @Override
    public ProductModelEvent detail(ProductModelEventIdParam productModelEventIdParam) {
        return this.queryEntity(productModelEventIdParam.getId());
    }

    @Override
    public ProductModelEvent queryEntity(String id) {
        ProductModelEvent productModelEvent = this.getById(id);
        if(ObjectUtil.isEmpty(productModelEvent)) {
            throw new CommonException("产品模型-事件不存在，id值为：{}", id);
        }
        return productModelEvent;
    }
}
