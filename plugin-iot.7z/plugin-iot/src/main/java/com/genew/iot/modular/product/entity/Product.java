/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.product.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.dromara.core.trans.vo.TransPojo;

import java.util.Date;

/**
 * 产品实体
 *
 * @author huhu
 * @date  2023/06/29 15:41
 **/
@Getter
@Setter
@TableName("iot_product")
public class Product implements TransPojo {

    /** 主键 */
    @TableId
    @ApiModelProperty(value = "主键", position = 1)
    private String id;

    /** 产品名称 */
    @ApiModelProperty(value = "产品名称", position = 2)
    private String name;

    /** 产品分类 */
    @ApiModelProperty(value = "产品分类", position = 3)
    private String category;

    /** 产品指标 */
    @ApiModelProperty(value = "制造商", position = 3)
    private String manufacture;

    /** 静态属性 */
    @ApiModelProperty(value = "静态属性", position = 4)
    private String attrs;

    /** REMARK */
    @ApiModelProperty(value = "REMARK", position = 7)
    private String remark;

    /** 产品指标 */
    @ApiModelProperty(value = "指标数量", position = 4)
    @TableField(exist = false)
    private Long metricNum;

    /** 创建时间 */
    @ApiModelProperty(value = "创建时间", position = 8)
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /** 创建人 */
    @ApiModelProperty(value = "创建人", position = 9)
    @TableField(fill = FieldFill.INSERT)
    private String createUser;

    /** 更新时间 */
    @ApiModelProperty(value = "更新时间", position = 10)
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

    /** 更新人 */
    @ApiModelProperty(value = "更新人", position = 11)
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private String updateUser;


    @ApiModelProperty(value = "采集协议", position = 10)
    private String protocol ;

    @ApiModelProperty(value = "主机IP", position = 11)
    private String hostIp ;

    @ApiModelProperty(value = "主机端口", position = 12)
    private String hostPort;

    @ApiModelProperty(value = "访问账号", position = 13)
    private String account ;

    @ApiModelProperty(value = "账号口令", position = 14)
    private String passphrase;
}
