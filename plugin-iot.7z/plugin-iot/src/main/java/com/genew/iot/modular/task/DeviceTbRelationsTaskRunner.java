package com.genew.iot.modular.task;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.genew.common.timer.CommonTimerTaskRunner;
import com.genew.iot.core.util.TbHelper;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.service.DeviceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.thingsboard.rest.client.RestClient;
import org.thingsboard.server.common.data.id.DeviceId;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 设备台账中设备与Thingsboard映射关系维护
 * 场景：用户从TB管理端直接删除了某个设备，而不是通过管理端的设备台账维护页面删除设备所导致的数据不一致性
 */
@Slf4j
@Component
public class DeviceTbRelationsTaskRunner implements CommonTimerTaskRunner {


    @Resource
    private DeviceService deviceService;

    @Resource
    private TbHelper tbHelper;

    @Override
    public void action() {

        log.warn("... Iot module  Start clear TB Device mappings ...");

        // 获取设备台账，并使用台账中的tb映射字段到 tb侧检测设备是否存在，不存在则置空台设备账表中的相关字段
        final List<Device> devices = deviceService.list(Wrappers.lambdaQuery(Device.class).isNotNull(Device::getTbDevId));
        if(devices == null || devices.isEmpty()){
            log.warn("不存在已关联TB的设备台账!");
            return;
        }

        final Map<String, String> deviceRelationMap = devices.stream().collect(Collectors.toMap(Device::getTbDevId, Device::getId));

        // 查询TB侧设备
        final List<DeviceId> tbDeviceIds = devices.stream().map(Device::getTbDevId).map(DeviceId::fromString).collect(Collectors.toList());

        final RestClient tbRestClient = tbHelper.login();
        final List<org.thingsboard.server.common.data.Device> tbDevices = tbRestClient.getDevicesByIds(tbDeviceIds);
        if(tbDevices != null && !tbDevices.isEmpty()){
            final Set<String> existTbDeviceIds = tbDevices.stream().map(org.thingsboard.server.common.data.Device::getId).map(DeviceId::toString).collect(Collectors.toSet());
            // 剔除映射关系正常的
            existTbDeviceIds.forEach( deviceRelationMap::remove);
        }

        final List<String> requireClearIds = deviceRelationMap.values().stream().collect(Collectors.toList());

        if(Objects.nonNull(requireClearIds) && !requireClearIds.isEmpty()){
            final boolean update = deviceService.update(Wrappers.lambdaUpdate(Device.class).set(Device::getTbDevId, null).in(Device::getId, requireClearIds));
            log.warn("设备台账TB映射关系清理, 影响的设备：{}", requireClearIds);
        }

        log.warn("... End to clear TB Device mappings ...");

    }
}
