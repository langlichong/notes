package com.genew.iot.modular.collect.core;

import lombok.EqualsAndHashCode;

import java.io.Serializable;

@EqualsAndHashCode
public final class TaskId implements Serializable {

    private String id;

    public TaskId(String taskId) {
        this.id = taskId;
    }

    public static TaskId fromString(String taskId) {
        return new TaskId(taskId);
    }

    @Override
    public String toString() {
        return id;
    }
}
