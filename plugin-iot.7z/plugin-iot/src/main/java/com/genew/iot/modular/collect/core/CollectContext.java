package com.genew.iot.modular.collect.core;

import com.genew.iot.modular.device.entity.DeviceAction;

public class CollectContext {

    private static final ThreadLocal<CollectRequest> requestHolder = new ThreadLocal<CollectRequest>();


    public static void setRequest(CollectRequest request) {
        requestHolder.set(request);
    }

    public static CollectRequest getRequest() {
        return requestHolder.get();
    }


    public static void removeRequest() {
        requestHolder.remove();
    }


    private static final ThreadLocal<DeviceAction> controlHolder = new ThreadLocal<>();

    public static void setRemoteControlParam(DeviceAction deviceAction) {
        controlHolder.set(deviceAction);
    }

    public static DeviceAction getRemoteControlParam() {
        return controlHolder.get();
    }

    public static void removeRemoteControlParam() {
        requestHolder.remove();
    }
}
