package com.genew.iot.modular.device.service;

import cn.hutool.json.JSONObject;
import com.genew.iot.modular.device.param.DeviceExportParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

public interface DeviceImportExportService {

    void downloadImportTemplate(HttpServletResponse response);

    void exportDevices(DeviceExportParam exportParam, HttpServletResponse response);

    JSONObject importDevices(MultipartFile file);
}
