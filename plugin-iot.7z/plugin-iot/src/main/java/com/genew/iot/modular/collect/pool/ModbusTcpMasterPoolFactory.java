package com.genew.iot.modular.collect.pool;

import com.ghgande.j2mod.modbus.facade.ModbusTCPMaster;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.jetbrains.annotations.NotNull;

import java.time.Duration;

@Slf4j
public class ModbusTcpMasterPoolFactory implements PooledObjectFactory<ModbusTCPMaster> {

    public static final int TIMEOUT = 5000;
    private String host;
    private int port;

    public ModbusTcpMasterPoolFactory(String host, Integer port) {
        this.host = host;
        this.port = port;
    }

    public synchronized GenericObjectPool createPool(){

        // 给池子添加支持的配置信息
        GenericObjectPoolConfig<ModbusTCPMaster> config = getPoolConfig();

        GenericObjectPool<ModbusTCPMaster> connPool = new GenericObjectPool<>(this, config);

        return connPool;
    }

    @NotNull
    private static GenericObjectPoolConfig<ModbusTCPMaster> getPoolConfig() {

        GenericObjectPoolConfig<ModbusTCPMaster> config = new GenericObjectPoolConfig<ModbusTCPMaster>();
        // 2.1 最大池化对象数量
        config.setMaxTotal(20);
        // 2.2 最大空闲池化对象数量
        config.setMaxIdle(8);
        // 2.3 最小空闲池化对象数量
        config.setMinIdle(3);
        // 2.4 间隔多久检查一次池化对象状态,驱逐空闲对象,检查最小空闲数量小于就创建
        config.setTimeBetweenEvictionRuns(Duration.ofSeconds(10));
        // 2.5 阻塞就报错
        config.setBlockWhenExhausted(true);
        // 2.6 最大等待时长超过5秒就报错,如果不配置一直进行等待
        config.setMaxWait(Duration.ofSeconds(10));
        //开启jmx监控
        config.setJmxEnabled(true);

        /*config.setTestOnBorrow(true);
        config.setFairness(true);*/

        return config;
    }


    @Override
    public void activateObject(PooledObject<ModbusTCPMaster> p) throws Exception {
        log.debug("---activate connection --");
       /* final ModbusTCPMaster client = p.getObject();
        if(!client.isConnected()){
            client.connect();
        }*/
    }

    @Override
    public void destroyObject(PooledObject<ModbusTCPMaster> p) throws Exception {
        final ModbusTCPMaster client = p.getObject();
        if(client.isConnected()){
            client.disconnect();
        }
    }

    @Override
    public PooledObject<ModbusTCPMaster> makeObject() throws Exception {

        ModbusTCPMaster client = new ModbusTCPMaster(host,port);
        client.setTimeout(TIMEOUT);
        client.connect();

        return new DefaultPooledObject<>(client);
    }

    @Override
    public void passivateObject(PooledObject<ModbusTCPMaster> p) throws Exception {

    }

    @Override
    public boolean validateObject(PooledObject<ModbusTCPMaster> p) {
        final ModbusTCPMaster client = p.getObject();
        // 如果连接关闭说明已经失效就返回false告诉池子,已经失效,会自动移除
        return !client.isConnected();
    }
}
