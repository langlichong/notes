/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.apiorchestrate.provider;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.genew.iot.api.IotOrchestrateQueryApi;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.modular.apiorchestrate.entity.IotApiOrchestrate;
import com.genew.iot.modular.apiorchestrate.service.IotApiOrchestrateService;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import com.genew.sys.api.SysRelationApi;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 接口管理API接口提供者
 *
 * @author js
 * @date 2023/03/28 10:09
 **/
@Service
@Slf4j
public class IotApiOrchestrateProvider implements IotOrchestrateQueryApi {

    @Resource
    private IotApiOrchestrateService iotApiOrchestrateService;

    @Resource
    private IotThirdApiService iotThirdApiService;

    @Resource
    private SysRelationApi sysRelationApi;

    @Override
    public List<String> checkIsHasChildList(String targetId) {
        List<String> resultList = Lists.newArrayList();
        List<IotThirdApi> thirdApiAllList = Lists.newArrayList();
        List<IotThirdApi> iotThirdApiList = getThirdApiList(targetId);
        if (ObjectUtil.isEmpty(iotThirdApiList)) {
            return null;
        }
        if (ObjectUtil.isNotEmpty(iotThirdApiList)) {
            // 添加聚合接口子接口
            thirdApiAllList.addAll(iotThirdApiList);
            // 添加子接口中含动态获取的接口
            thirdApiAllList.addAll(getTokenThirdApiList(iotThirdApiList));
        }
        if (ObjectUtil.isNotEmpty(thirdApiAllList)) {
            resultList =
                    thirdApiAllList.stream().map(iotThirdApi -> iotThirdApi.getApiPath() + StrUtil.BRACKET_START + iotThirdApi.getApiAlias() + StrUtil.BRACKET_END).collect(Collectors.toList());
        }
        return resultList;
    }

    @Override
    public List<String> checkIsHasMoreParentList(String targetId) {
        List<String> resultList = Lists.newArrayList();
        List<IotThirdApi> thirdApiAllList = Lists.newArrayList();
        List<IotThirdApi> iotThirdApiList = getThirdApiList(targetId);
        if (ObjectUtil.isEmpty(iotThirdApiList)) {
            return null;
        }
        iotThirdApiList.forEach(iotThirdApi -> {
            boolean thirdApiPem = sysRelationApi.checkPermissionListByTargetId(iotThirdApi.getApiPath());
            if (!thirdApiPem) {
                return;
            }
            List<IotApiOrchestrate> apiOrchestrateList = Lists.newArrayList();
            List<IotApiOrchestrate> list =
                    iotApiOrchestrateService.list(new LambdaQueryWrapper<IotApiOrchestrate>().like(IotApiOrchestrate::getRefApiId,
                            iotThirdApi.getApiSign()));
            list.forEach(iotApiOrchestrate -> {
                boolean orchestratePem = sysRelationApi.checkPermissionListByTargetId(iotApiOrchestrate.getApiPath());
                if (!orchestratePem) {
                    return;
                }
                apiOrchestrateList.add(iotApiOrchestrate);
            });
            if (apiOrchestrateList.size() == 1) {
                thirdApiAllList.add(iotThirdApi);
            }
        });
        if (ObjectUtil.isNotEmpty(thirdApiAllList)) {
            thirdApiAllList.addAll(getTokenThirdApiList(thirdApiAllList));
            resultList =
                    thirdApiAllList.stream().map(iotThirdApi -> iotThirdApi.getApiPath() + StrUtil.BRACKET_START + iotThirdApi.getApiAlias() + StrUtil.BRACKET_END).collect(Collectors.toList());
        }
        return resultList;
    }

    private List<IotThirdApi> getThirdApiList(String targetId) {
        IotApiOrchestrate iotApiOrchestrate =
                iotApiOrchestrateService.getOne(new LambdaQueryWrapper<IotApiOrchestrate>().eq(IotApiOrchestrate::getApiPath, targetId));
        if (ObjectUtil.isEmpty(iotApiOrchestrate)) {
            return null;
        }
        String refApiId = iotApiOrchestrate.getRefApiId();
        List<String> apiList = Arrays.asList(refApiId.split(","));
        List<IotThirdApi> iotThirdApiList = iotThirdApiService.queryEntityByApiSigns(apiList);
        return iotThirdApiList;
    }

    /**
     * 获取三方接口中选择动态获取时的接口
     *
     * @param iotThirdApiList
     * @return
     */
    private List<IotThirdApi> getTokenThirdApiList(List<IotThirdApi> iotThirdApiList) {
        List<IotThirdApi> tokenThirdApiList = Lists.newArrayList();
        iotThirdApiList.forEach(iotThirdApi -> {
            Map<String, Object> paramMap = JSONUtil.toBean(iotThirdApi.getAuthParam(), Map.class, true);
            if (ObjectUtil.isEmpty(paramMap)) {
                return;
            }
            Map<String, Object> tokenUrlMap = (Map<String, Object>) paramMap.get("getTokenUrlMap");
            Map<String, Object> refreshTokenUrlMap = (Map<String, Object>) paramMap.get("refreshTokenUrlMap");
            if (ObjectUtil.isNotEmpty(tokenUrlMap)) {
                String apiSign = (String) tokenUrlMap.get("code");
                if (ObjectUtil.isEmpty(apiSign)) {
                    return;
                }
                tokenThirdApiList.add(iotThirdApiService.queryEntityByApiSign(apiSign));
            }
            if (ObjectUtil.isNotEmpty(refreshTokenUrlMap)) {
                String apiSign = (String) refreshTokenUrlMap.get("code");
                if (ObjectUtil.isEmpty(apiSign)) {
                    return;
                }
                tokenThirdApiList.add(iotThirdApiService.queryEntityByApiSign(apiSign));
            }
        });
        return tokenThirdApiList;
    }
}
