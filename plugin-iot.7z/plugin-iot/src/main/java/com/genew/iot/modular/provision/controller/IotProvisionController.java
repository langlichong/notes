/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.provision.controller;

import cn.dev33.satoken.annotation.SaCheckPermission;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.common.pojo.CommonValidList;
import com.genew.iot.modular.provision.entity.IotProvision;
import com.genew.iot.modular.provision.param.IotProvisionAddParam;
import com.genew.iot.modular.provision.param.IotProvisionEditParam;
import com.genew.iot.modular.provision.param.IotProvisionIdParam;
import com.genew.iot.modular.provision.param.IotProvisionPageParam;
import com.genew.iot.modular.provision.service.IotProvisionService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 预选项配置控制器
 *
 * @author js
 * @date  2023/05/24 14:12
 */
@Api(tags = "预选项配置控制器")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
public class IotProvisionController {

    @Resource
    private IotProvisionService iotProvisionService;

    /**
     * 获取预选项配置分页
     *
     * @author js
     * @date  2023/05/24 14:12
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取预选项配置分页")
    @SaCheckPermission("/iot/provision/page")
    @GetMapping("/iot/provision/page")
    public CommonResult<Page<IotProvision>> page(IotProvisionPageParam iotProvisionPageParam) {
        return CommonResult.data(iotProvisionService.page(iotProvisionPageParam));
    }

    /**
     * 添加预选项配置
     *
     * @author js
     * @date  2023/05/24 14:12
     */
    @ApiOperationSupport(order = 2)
    @ApiOperation("添加预选项配置")
    @CommonLog("添加预选项配置")
    @SaCheckPermission("/iot/provision/add")
    @PostMapping("/iot/provision/add")
    public CommonResult<String> add(@RequestBody @Valid IotProvisionAddParam iotProvisionAddParam) {
        iotProvisionService.add(iotProvisionAddParam);
        return CommonResult.ok();
    }

    /**
     * 编辑预选项配置
     *
     * @author js
     * @date  2023/05/24 14:12
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("编辑预选项配置")
    @CommonLog("编辑预选项配置")
    @SaCheckPermission("/iot/provision/edit")
    @PostMapping("/iot/provision/edit")
    public CommonResult<String> edit(@RequestBody @Valid IotProvisionEditParam iotProvisionEditParam) {
        iotProvisionService.edit(iotProvisionEditParam);
        return CommonResult.ok();
    }

    /**
     * 删除预选项配置
     *
     * @author js
     * @date  2023/05/24 14:12
     */
    @ApiOperationSupport(order = 4)
    @ApiOperation("删除预选项配置")
    @CommonLog("删除预选项配置")
    @SaCheckPermission("/iot/provision/delete")
    @PostMapping("/iot/provision/delete")
    public CommonResult<String> delete(@RequestBody @Valid @NotEmpty(message = "集合不能为空")
                                                   CommonValidList<IotProvisionIdParam> iotProvisionIdParamList) {
        iotProvisionService.delete(iotProvisionIdParamList);
        return CommonResult.ok();
    }

    /**
     * 获取预选项配置详情
     *
     * @author js
     * @date  2023/05/24 14:12
     */
    @ApiOperationSupport(order = 5)
    @ApiOperation("获取预选项配置详情")
    @SaCheckPermission("/iot/provision/detail")
    @GetMapping("/iot/provision/detail")
    public CommonResult<IotProvision> detail(@Valid IotProvisionIdParam iotProvisionIdParam) {
        return CommonResult.data(iotProvisionService.detail(iotProvisionIdParam));
    }

    /**
     * 获取所有配置项列表
     */
    @ApiOperationSupport(order = 6)
    @ApiOperation("获取所有预配置项")
    @SaCheckPermission("/iot/provision/list")
    @GetMapping("/iot/provision/list")
    public CommonResult<List<IotProvision>> listAll() {

        final LambdaQueryWrapper<IotProvision> where = Wrappers.lambdaQuery(IotProvision.class).select(IotProvision::getId, IotProvision::getName);
        return CommonResult.data(iotProvisionService.list(where));
    }
}
