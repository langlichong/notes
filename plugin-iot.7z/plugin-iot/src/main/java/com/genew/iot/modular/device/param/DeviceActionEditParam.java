/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 设备指令编辑参数
 *
 * @author huhu
 * @date  2023/09/06 17:16
 **/
@Getter
@Setter
public class DeviceActionEditParam {

    /** ID */
    @ApiModelProperty(value = "ID", required = true, position = 1)
    @NotBlank(message = "id不能为空")
    private String id;

    /** 指令名称 */
    @ApiModelProperty(value = "指令名称", required = true, position = 2)
    @NotBlank(message = "name不能为空")
    private String name;

    /** 指令描述 */
    @ApiModelProperty(value = "指令描述", required = true, position = 3)
    @NotBlank(message = "description不能为空")
    private String description;

    /** 指令协议 */
    @ApiModelProperty(value = "指令协议", required = true, position = 4)
    @NotBlank(message = "protocol不能为空")
    private String protocol;

    /** 目的主机 */
    @ApiModelProperty(value = "目的主机", required = true, position = 5)
    @NotBlank(message = "host不能为空")
    private String host;

    /** 目的端口 */
    @ApiModelProperty(value = "目的端口", required = true, position = 6)
    @NotNull(message = "port不能为空")
    private Integer port;

    /** 指令端点 */
    @ApiModelProperty(value = "指令端点", required = true, position = 7)
    @NotBlank(message = "endpoint不能为空")
    private String endpoint;

    /** 负载内容 */
    @ApiModelProperty(value = "负载内容", position = 8)
    private String payload;

    /** 依赖的指令 */
    @ApiModelProperty(value = "依赖的指令", position = 9)
    private String depsAction;

    /** 认证参数 */
    @ApiModelProperty(value = "认证参数", position = 10)
    private String authParam;

    /** 目标设备 */
    @ApiModelProperty(value = "目标设备", required = true, position = 11)
    @NotBlank(message = "deviceId不能为空")
    private String deviceId;

}
