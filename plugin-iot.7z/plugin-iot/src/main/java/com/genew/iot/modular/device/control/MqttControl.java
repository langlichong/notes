package com.genew.iot.modular.device.control;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONUtil;
import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.iot.core.config.MqttConfig;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.core.util.MqttUtil;
import com.genew.iot.modular.collect.core.CollectTypes;
import com.genew.iot.modular.device.entity.DeviceAction;
import com.genew.iot.modular.device.param.DeviceActionAuthParam;
import com.genew.iot.modular.device.service.impl.AbstractControl;
import com.genew.iot.modular.metric.dto.protocol.MqttProtocolConf;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 功能描述：MQTT远程控制器
 *
 * @Author： js
 * @create： 2023/9/11 16:44
 */
@Component
public class MqttControl extends AbstractControl {
    @Resource
    private MqttUtil mqttUtil;

    @Override
    @ExceptionLog(value = "MQTT远程控制", type = LogTypes.remoteControl)
    public void remoteControl(DeviceAction deviceAction) throws DataIntegrationException {
        try {
            DeviceActionAuthParam deviceActionAuthParam = JSONUtil.toBean(deviceAction.getAuthParam(), DeviceActionAuthParam.class);
            String hostIp = deviceAction.getHost();
            Integer hostPort = deviceAction.getPort();
            String username = deviceActionAuthParam.getUsername();
            String password = deviceActionAuthParam.getPassword();
            String topic = deviceAction.getEndpoint();
            String message = deviceAction.getPayload();
            MqttProtocolConf protocolConf = new MqttProtocolConf();
            protocolConf.setHostIp(hostIp);
            protocolConf.setHostPort(hostPort);
            protocolConf.setUsername(username);
            protocolConf.setPassword(password);
            protocolConf.setTopic(topic);
            MqttConfig mqttConfig = mqttUtil.getMqttConfig(protocolConf);
            if (ObjectUtil.isEmpty(mqttConfig)) {
                return;
            }
            if (!mqttUtil.isConnected()) {
                //mqtt连接
                mqttUtil.connect(mqttConfig);
            }
            mqttUtil.publish(1, true, topic, message);
        } catch (Exception e) {
            throw new DataIntegrationException(e.getMessage(), e);
        }
    }

    @Override
    public boolean support(DeviceAction deviceAction) {
        String protocol = deviceAction.getProtocol();
        if (CollectTypes.MQTT_SUBSCRIBE.name().startsWith(protocol)) {
            return true;
        }
        return false;
    }
}

