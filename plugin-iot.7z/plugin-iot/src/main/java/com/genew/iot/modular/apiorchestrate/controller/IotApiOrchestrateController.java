/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.apiorchestrate.controller;

import cn.dev33.satoken.annotation.SaCheckPermission;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.genew.common.annotation.CommonLog;
import com.genew.common.annotation.CommonNoRepeat;
import com.genew.common.pojo.CommonResult;
import com.genew.common.pojo.CommonValidList;
import com.genew.iot.modular.apiorchestrate.entity.IotApiOrchestrate;
import com.genew.iot.modular.apiorchestrate.param.*;
import com.genew.iot.modular.apiorchestrate.service.IotApiOrchestrateService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.Map;

/**
 * API编排控制器
 *
 * @author js
 * @date 2023/05/04 14:57
 */
@Api(tags = "API编排控制器")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
public class IotApiOrchestrateController {

    @Resource
    private IotApiOrchestrateService iotApiOrchestrateService;

    /**
     * 获取API编排分页
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取API编排分页")
    @SaCheckPermission("/iot/apiorchestrate/page")
    @GetMapping("/iot/apiorchestrate/page")
    public CommonResult<Page<IotApiOrchestrate>> page(IotApiOrchestratePageParam iotApiOrchestratePageParam) {
        return CommonResult.data(iotApiOrchestrateService.page(iotApiOrchestratePageParam));
    }

    /**
     * 添加API编排
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    @ApiOperationSupport(order = 2)
    @ApiOperation("添加API编排")
    @CommonLog("添加API编排")
    @SaCheckPermission("/iot/apiorchestrate/add")
    @PostMapping("/iot/apiorchestrate/add")
    public CommonResult<String> add(@RequestBody @Valid IotApiOrchestrateAddParam iotApiOrchestrateAddParam) {
        iotApiOrchestrateService.add(iotApiOrchestrateAddParam);
        return CommonResult.ok();
    }

    /**
     * 编辑API编排
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("编辑API编排")
    @CommonLog("编辑API编排")
    @SaCheckPermission("/iot/apiorchestrate/edit")
    @PostMapping("/iot/apiorchestrate/edit")
    public CommonResult<String> edit(@RequestBody @Valid IotApiOrchestrateEditParam iotApiOrchestrateEditParam) {
        iotApiOrchestrateService.edit(iotApiOrchestrateEditParam);
        return CommonResult.ok();
    }

    /**
     * 删除API编排
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    @ApiOperationSupport(order = 4)
    @ApiOperation("删除API编排")
    @CommonLog("删除API编排")
    @SaCheckPermission("/iot/apiorchestrate/delete")
    @PostMapping("/iot/apiorchestrate/delete")
    public CommonResult<String> delete(@RequestBody @Valid @NotEmpty(message = "集合不能为空")
                                               CommonValidList<IotApiOrchestrateIdParam> iotApiOrchestrateIdParamList) {
        iotApiOrchestrateService.delete(iotApiOrchestrateIdParamList);
        return CommonResult.ok();
    }

    /**
     * 获取API编排详情
     *
     * @author js
     * @date 2023/05/04 14:57
     */
    @ApiOperationSupport(order = 5)
    @ApiOperation("获取API编排详情")
    @SaCheckPermission("/iot/apiorchestrate/detail")
    @GetMapping("/iot/apiorchestrate/detail")
    public CommonResult<IotApiOrchestrate> detail(@Valid IotApiOrchestrateIdParam iotApiOrchestrateIdParam) {
        return CommonResult.data(iotApiOrchestrateService.detail(iotApiOrchestrateIdParam));
    }

    /**
     * 获取聚合接口数据
     *
     * @return
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 6)
    @ApiOperation("获取聚合接口数据")
    @SaCheckPermission("/iot/apiorchestrate/queryThirdApiData")
    @PostMapping("/iot/apiorchestrate/queryThirdApiData")
    @CommonNoRepeat
    public Map<String, Object> queryThirdApiData(@RequestBody @Valid IotApiOrchestrateQueryParam iotApiOrchestrateQueryParam) {
        return iotApiOrchestrateService.queryThirdApiData(iotApiOrchestrateQueryParam);
    }
}
