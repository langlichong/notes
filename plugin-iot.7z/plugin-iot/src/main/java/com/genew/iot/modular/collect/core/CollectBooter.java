package com.genew.iot.modular.collect.core;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.metric.entity.Metric;
import com.genew.iot.modular.metric.service.MetricService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
public class CollectBooter implements CommandLineRunner {


    @Resource
    private MetricService metricService;

    @Resource
    private DeviceService deviceService;

    @Resource
    private CollectManager collectManager;

    @Override
    public void run(String... args)  {

        //todo 应用重新启动后，将服务崩溃前已经在运行状态的任务重新跑起来
        final List<Metric> runningTask = metricService.list(Wrappers.lambdaQuery(Metric.class).eq(Metric::getCollectStatus, MetricStatus.RUNNING.name()));

        for (Metric m : runningTask) {
            //todo  device信息
            CollectManager.submitCollectRequest(m, deviceService);
        }

        collectManager.start();
    }


}
