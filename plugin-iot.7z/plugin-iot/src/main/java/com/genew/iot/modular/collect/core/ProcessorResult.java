package com.genew.iot.modular.collect.core;

import lombok.Data;

@Data
public class ProcessorResult {

    private Object result ;
    private ProcessResultType resultType;

    public ProcessorResult(Object result, ProcessResultType resultType) {

        this.result = result;
        this.resultType = resultType;
    }
}
