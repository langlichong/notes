package com.genew.iot.modular.collect.collector;

import cn.hutool.core.net.url.UrlBuilder;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.modular.collect.core.*;
import com.genew.iot.modular.metric.dto.protocol.HttpProtocolConf;
import lombok.extern.slf4j.Slf4j;
import org.graalvm.polyglot.Context;
import org.graalvm.polyglot.Value;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.concurrent.ConcurrentHashMap;

/**
 * HTTP API 采集
 */
@Slf4j
@Component
public class HttpApiCollector extends AbstractCollector<JSONObject, String> {

    private static ConcurrentHashMap<String, DataSource> dsCache = new ConcurrentHashMap<>();

    @Override
    @ExceptionLog(value = "HTTP API 采集", type = LogTypes.collectData)
    protected CollectResponse<JSONObject, String> collectData() throws DataIntegrationException {

        final CollectRequest request = CollectContext.getRequest();
        final HttpProtocolConf protocolConf = request.getHttpProtocolConf();

        final JSONObject valueObject = JSONUtil.createObj()
                .set("ts", System.currentTimeMillis() + "")
                // todo 待改造
                //.set("sensor",request.getOwnerSensorName())
                .set("unit", request.getDataUnit());

        //推送格式： {"指标名称": "指标值对象"}
        final JSONObject dataPoint = JSONUtil.createObj()
                .set(request.getName(), valueObject);

        String schema = protocolConf.getApiSchema();
        String httpMethod = protocolConf.getHttpMethod();
        String hostIp = protocolConf.getHostIp();
        int port = protocolConf.getHostPort();
        final String path = protocolConf.getResourcePath();
        String httpBody = protocolConf.getHttpBody();

        final String urlStr = UrlBuilder.of(schema, hostIp, port, path, null, null, null).build();
        log.info("--- HttpMethod = {},URL= {}", httpMethod, urlStr);

        String apiResponse = null;
        try {
            if ("GET".equalsIgnoreCase(httpMethod)) {
                apiResponse = HttpUtil.get(urlStr);
            } else if ("POST".equalsIgnoreCase(httpMethod)) {
                apiResponse = HttpUtil.post(urlStr, httpBody);
            }
        } catch (Exception e) {
            throw new DataIntegrationException("HTTP API 采集异常", e);
        }


        log.info("-- HTTP响应: {}", apiResponse);
        String metricVal = apiResponse;
        valueObject.set("value", metricVal);

        final CollectResponse response = CollectResponse.builder()
                .originRequest(request)
                .collectResult(JSONUtil.parseObj(metricVal))
                .collectResultType(ProcessResultType.JSON)
                .build();

        return response;
    }


    /**
     * 调用 Graalvm js 执行 js函数
     *
     * @param funcBody JS 函数body内容，由用户在前端自定义
     * @param param    传递给用户自定义JS的参数，一般是直接采集到的原始数据
     * @return 用户自定义脚本执行结果
     */
    private String executeJsScripts(String funcBody, String param) {

        log.info("-- execute js function---");

        final Context ctx = Context.newBuilder("js").option("engine.WarnInterpreterOnly", "false").allowAllAccess(true).build();

        ctx.eval("js", "function preExtract(param){" + funcBody + " }");
        final Value preExtractFunction = ctx.getBindings("js").getMember("preExtract");
        final String res = preExtractFunction.execute(param).asString();

        ctx.close();

        return res;
    }


    @Override
    protected boolean support(CollectRequest request) {

        if (request.getProtocol().equalsIgnoreCase(CollectTypes.HTTP_API.name())) {
            return true;
        }
        return false;
    }

}
