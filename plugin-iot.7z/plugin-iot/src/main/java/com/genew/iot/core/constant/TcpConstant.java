package com.genew.iot.core.constant;

/**
 * 功能描述：TCP常量类
 *
 * @Author： js
 * @create： 2023/9/1 17:25
 */
public class TcpConstant {

    /**
     * TCP服务端端口
     */
    public static final String TCP_SERVER_HOST_PORT = "TCP_SERVER_HOST_PORT";

    /**
     * 0   0000 0001
     */
    public static final int bit0 = 0x01;
    /**
     * 1   0000 0010
     */
    public static final int bit1 = 0x02;
    /**
     * 2   0000 0100
     */
    public static final int bit2 = 0x04;
    /**
     * 3   0000 1000
     */
    public static final int bit3 = 0x08;
    /**
     * 4   0001 0000
     */
    public static final int bit4 = 0x10;
    /**
     * 5   0010 0000
     */
    public static final int bit5 = 0x20;
    /**
     * 6   0100 0000
     */
    public static final int bit6 = 0x40;
    /**
     * 7   1000 0000
     */
    public static final int bit7 = 0x80;

    /**
     * 常州本安4 路 第三个字节值 类型处理 8-4路电源值；2-状态值处理
     */
    public static final String THIRDLY_BYTE_VALUE_8 = "8";

    public static final String THIRDLY_BYTE_VALUE_2 = "2";

    /**
     * 两字节
     * 高两位最大值 1100 0000 0000 0000
     */
    public static final int height2Bit = 0xc000;

    /**
     * 除高两位外的其余位数 最大值  0011 1111 1111 1111
     */
    public static final int height2OtherBit = 0x3fff;


    /**
     * 低两位最大值 0000 0011
     */
    public static final int low2Bit = 0x03;

    /**
     * 低位 2-3位  0000 1100
     */
    public static final int low23Bit = 0x0c;

    /**
     * 一个字节最大值  1111 1111
     */
    public static final int flag = 0xff;

    /**
     * 常州本安4 路 固定安时
     */
    public static final Integer AH_VALUE = 16;

    /**
     * 一个字节占 8位
     */
    public static final int BITS_OF_BYTE = 8;

    /**
     * 多项式
     */
    public static final int POLYNOMIAL = 0XA001;

    /**
     * CRC寄存器默认初始值
     */
    public static final int INITIAL_VALUE = 0XFFFF;

}

