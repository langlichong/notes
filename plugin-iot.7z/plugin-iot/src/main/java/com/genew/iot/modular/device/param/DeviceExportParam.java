package com.genew.iot.modular.device.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DeviceExportParam {

    @ApiModelProperty(value = "设备编码")
    private String code ;

    @ApiModelProperty(value = "设备名称")
    private String name;

    @ApiModelProperty(value = "用户属主")
    private String owner;

    @ApiModelProperty(value = "设备Id串：逗号分割")
    private String deviceIds;
}
