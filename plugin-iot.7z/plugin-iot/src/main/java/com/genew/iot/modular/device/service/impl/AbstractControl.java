package com.genew.iot.modular.device.service.impl;

import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.modular.device.entity.DeviceAction;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author lenovo
 */
@Data
@Slf4j
@Component
@NoArgsConstructor
public abstract class AbstractControl {

    /**
     * 设备远程控制
     *
     * @return
     * @param deviceAction
     * @throws DataIntegrationException
     */
    public abstract void remoteControl(DeviceAction deviceAction) throws DataIntegrationException;

    /**
     * 本控制器是否支持 该类型的控制请求
     *
     * @param deviceAction
     * @return
     */
    public abstract boolean support(DeviceAction deviceAction);
}
