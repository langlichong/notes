/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.thirdapi.service.impl;

import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSON;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.genew.common.exception.CommonException;
import com.genew.iot.core.constant.IotThirdApiConstant;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.core.param.IotThirdApiQueryParam;
import com.genew.iot.core.util.TbHelper;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import com.genew.iot.modular.thirdapi.service.IotThirdApiTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.thingsboard.rest.client.RestClient;
import org.thingsboard.server.common.data.id.DeviceId;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Objects;

/**
 * 接口管理定时任务实现类
 *
 * @author js
 * @date 2023/04/06 15:50
 **/
@Slf4j
@Service
public class IotThirdApiTaskServiceImpl implements IotThirdApiTaskService {

    @Resource
    private TbHelper tbHelper;

    @Resource
    private IotThirdApiService iotThirdApiService;

    @Override
    public void action(IotThirdApi iotThirdApi) {
        Device device = iotThirdApiService.getDeviceByTimingEntityId(iotThirdApi);
        IotThirdApiQueryParam iotThirdApiQueryParam = new IotThirdApiQueryParam();
        iotThirdApiQueryParam.setApiSign(iotThirdApi.getApiSign());
        RestClient restClient = tbHelper.login();
        restClient.getDeviceCredentialsByDeviceId(DeviceId.fromString(device.getTbDevId()))
                .ifPresent(credentials -> {
                    pushIotThirdApiData(device, iotThirdApiQueryParam, restClient);
                });
    }

    /**
     * 推送遥测数据
     *
     * @param device
     * @param iotThirdApiQueryParam
     * @param client
     */

    private void pushIotThirdApiData(Device device, IotThirdApiQueryParam iotThirdApiQueryParam, RestClient client) {
        String json = "";
        Map<String, Object> jsonMap = iotThirdApiService.queryThirdApiData(iotThirdApiQueryParam);
        if (Objects.equals(jsonMap.get(IotThirdApiConstant.CODE), HttpStatus.HTTP_OK)) {
            json = String.valueOf(jsonMap.get(IotThirdApiConstant.DATA));
        }
        if (StringUtils.isBlank(json)) {
            log.warn("遥测数据推送结果:{},设备ID{}，推送设备数据json:{}", false, device.getTbDevId(), null);
            throw new CommonException("遥测数据推送失败:{}", jsonMap.get(IotThirdApiConstant.MESSAGE));
        }
        pushTelemetryData(DeviceId.fromString(device.getTbDevId()), client, JSONUtil.parse(json));
    }

    @Override
    public void pushTelemetryData(DeviceId deviceId, RestClient client, JSON json) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode telemetryJson = objectMapper.readTree(JSONUtil.toJsonStr(json));
            boolean isEnabled = client.saveEntityTelemetry(deviceId, "any",
                    telemetryJson);
            log.debug("遥测数据推送结果:{},设备ID{}，推送设备数据json:{}", isEnabled, deviceId.getId(), telemetryJson);
        } catch (Exception e) {
            String resultMsg = resolveResultMessage(e);
            log.error("遥测数据推送失败：{}", resultMsg);
            throw new CommonException("遥测数据推送失败:{}", resultMsg);
        }
    }

    /**
     * 解析Tb返回异常
     *
     * @param e
     * @return
     */
    private String resolveResultMessage(Exception e) {
        String resultMsg = "";
        if (e instanceof HttpClientErrorException.BadRequest) {
            String responseBodyAsString = ((HttpClientErrorException.BadRequest) e).getResponseBodyAsString();
            try {
                resultMsg = JSONUtil.parseObj(responseBodyAsString).getStr(IotThirdApiConstant.MESSAGE);
            } catch (Exception exception) {
                resultMsg = responseBodyAsString;
            }
        }
        return resultMsg;
    }

}
