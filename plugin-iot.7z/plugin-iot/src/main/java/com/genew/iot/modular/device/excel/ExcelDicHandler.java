package com.genew.iot.modular.device.excel;

import cn.afterturn.easypoi.handler.inter.IExcelDictHandler;
import cn.hutool.json.JSONObject;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@NoArgsConstructor
public class ExcelDicHandler implements IExcelDictHandler {

    private List<JSONObject> dicts ;

    public ExcelDicHandler(List<JSONObject> dicts){

        this.dicts = dicts;
    }

    @Override
    public List<Map> getList(String dict) {

        List<Map> list = new ArrayList<>();
        if(Objects.nonNull(this.dicts)){

            this.dicts.forEach( json -> {
                Map<String, String> dictMap = new HashMap<>();
                dictMap.put("dictKey", json.getStr("dictValue"));
                dictMap.put("dictValue", json.getStr("dictLabel"));

                list.add(dictMap);
            });
        }

        return list;
    }

    // 导出用到
    @Override
    public String toName(String dict, Object obj, String name, Object value) {
        if ("owner".equals(dict)) {
            final String val = value.toString();
            switch (val) {
                case "BUILDIN":
                    return "内部";
                default:
                    return "";
            }
        }
        return null;
    }

    // 导入用到
    @Override
    public String toValue(String dict, Object obj, String name, Object value) {
        if ("owner".equals(dict)) {
            String valueStr = String.valueOf(value);
            switch (valueStr) {
                case "内部":
                    return "BUILDIN";
                default:
                    return "";
            }
        }
        return null;
    }
}