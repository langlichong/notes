package com.genew.iot.modular.collect.core;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;

/**
 * 数据采集响应结果处理器；实现Ordered ，用于表示Processor的执行优先级
 */
@Slf4j
public  abstract class AbstractCollectResponseProcessor implements Ordered {

    /**
     * 唯一标识: 推荐直接使用处理器的类名称做为id
     */
    public abstract String id();

    /**
     * 名称：中文名称（后期会通过前端指标配置页面让用户选择）
     */
    public abstract String name();

    /**
     * 用于确定当前处理器的 是否会被执行
     * @param response 指标采集结果封装，可以从里面获取 原始的采集请求 、 指标值对象
     * @return true则执行， false则不执行
     */
    protected abstract boolean support(CollectResponse response);


    /**
     * 下一个处理器
     */
    protected AbstractCollectResponseProcessor nextProcessor;


    public ProcessorResult process(CollectResponse originCollectResponse, ProcessorResult previousResult){

        ProcessorResult processorResult = doProcess(originCollectResponse,previousResult);
        if(nextProcessor != null ){
            return nextProcessor.process(originCollectResponse,processorResult);
        }

        return processorResult;

    }


    /**
     * 对原始采集结果进行处理 或 对前序处理的结果再处理 , 并返回处理结果
     * @param originCollectResponse 原始采集结果
     * @param previousResult
     */
    protected abstract ProcessorResult doProcess(CollectResponse originCollectResponse, ProcessorResult previousResult);



    public void setNextProcessor(AbstractCollectResponseProcessor nextProcessor){
        this.nextProcessor = nextProcessor;
    }

}
