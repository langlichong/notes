package com.genew.iot.modular.device.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import cn.afterturn.easypoi.handler.inter.IExcelModel;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

@Data
public class DeviceImportModel implements Serializable, IExcelModel {

    @NotEmpty
    @Excel(name = "设备编码(必填)", width = 20,  orderNum = "1")
    private String code;


    @NotEmpty
    @Excel(name = "设备名称(必填)",width = 20, orderNum = "2")
    private String name;

    /**
     * 设备属主：暂定为字典项 DEVICE_OWNER 中值
     */
    @NotEmpty
    @Excel(name = "设备属主(必填)" ,dict = "owner",addressList = true, width = 20, orderNum = "3")
    private String owner;

    /**
     * 当前设备映射到Thingsboard中设备ID
     */
    @Excel(name = "关联TB设备ID",width = 20, orderNum = "4")
    private String tbDevId;

    /**
     * 设备token: 该值会作为Thingsboard中设备的token
     */
    @Excel(name = "关联TB设备Token",width = 20, orderNum = "5")
    private String tbDevToken;

    @Override
    public String getErrorMsg() {
        return null;
    }

    @Override
    public void setErrorMsg(String errorMsg) {

    }
}
