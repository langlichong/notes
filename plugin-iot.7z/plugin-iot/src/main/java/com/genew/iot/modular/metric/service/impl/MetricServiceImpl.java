/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.metric.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.genew.common.enums.CommonSortOrderEnum;
import com.genew.common.exception.CommonException;
import com.genew.common.listener.CommonDataChangeEventCenter;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.core.enums.IotDataTypeEnum;
import com.genew.iot.core.util.TbHelper;
import com.genew.iot.modular.collect.core.MetricStatus;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.metric.entity.Metric;
import com.genew.iot.modular.metric.mapper.MetricMapper;
import com.genew.iot.modular.metric.param.MetricAddParam;
import com.genew.iot.modular.metric.param.MetricEditParam;
import com.genew.iot.modular.metric.param.MetricIdParam;
import com.genew.iot.modular.metric.param.MetricPageParam;
import com.genew.iot.modular.metric.service.MetricService;
import com.genew.iot.modular.metric.tree.DeviceSensorNode;
import com.genew.iot.modular.sensor.entity.Sensor;
import com.genew.iot.modular.sensor.service.SensorService;
import com.google.common.collect.ArrayListMultimap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.thingsboard.rest.client.RestClient;
import org.thingsboard.server.common.data.id.DeviceId;
import org.thingsboard.server.common.data.kv.TsKvEntry;

import javax.annotation.Resource;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 设备传感器指标Service接口实现类
 *
 * @author huhu
 * @date  2023/04/12 15:27
 **/
@Slf4j
@Service
public class MetricServiceImpl extends ServiceImpl<MetricMapper, Metric> implements MetricService {

    @Resource
    private DeviceService deviceService;

    @Resource
    private SensorService sensorService;

    @Resource
    private MetricService metricService;

    @Resource
    private MetricMapper metricsMapper;

    @Resource
    private TbHelper tbHelper;

    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    @Override
    public Page<Metric> page(MetricPageParam metricPageParam) {
        QueryWrapper<Metric> queryWrapper = new QueryWrapper<>();
        if(ObjectUtil.isNotEmpty(metricPageParam.getName())) {
            queryWrapper.lambda().like(Metric::getName, metricPageParam.getName());
        }
        if(ObjectUtil.isNotEmpty(metricPageParam.getOwnerType())) {
            queryWrapper.lambda().like(Metric::getOwnerType, metricPageParam.getOwnerType());
        }
        if(ObjectUtil.isNotEmpty(metricPageParam.getOwnerId())){
            queryWrapper.lambda().eq(Metric::getOwnerId, metricPageParam.getOwnerId());
        }
        if(ObjectUtil.isNotEmpty(metricPageParam.getCollectStatus())){
            queryWrapper.lambda().eq(Metric::getCollectStatus, metricPageParam.getCollectStatus());
        }
        if(ObjectUtil.isNotEmpty(metricPageParam.getProtocol())) {
            queryWrapper.lambda().like(Metric::getProtocol, metricPageParam.getProtocol());
        }
        if(ObjectUtil.isAllNotEmpty(metricPageParam.getSortField(), metricPageParam.getSortOrder())) {
            CommonSortOrderEnum.validate(metricPageParam.getSortOrder());
            queryWrapper.orderBy(true, metricPageParam.getSortOrder().equals(CommonSortOrderEnum.ASC.getValue()),
                    StrUtil.toUnderlineCase(metricPageParam.getSortField()));
        } else {
            queryWrapper.lambda().last("order by update_time desc nulls last,name desc ");
        }
        return this.page(CommonPageRequest.defaultPage(), queryWrapper);
    }

    @Transactional(rollbackFor = Exception.class,propagation = Propagation.NESTED)
    @Override
    public void add(MetricAddParam metricAddParam) {
        Metric metric = BeanUtil.toBean(metricAddParam, Metric.class);

        validateMetricDuplication(metric,true);

        final Date now = new Date();
        metric.setCreateTime(now);
        metric.setUpdateTime(now);

        this.save(metric);

        //派发数据采集请求事件
        dispatchDataCollectEvent(metric);
    }

    @Transactional(rollbackFor = Exception.class,propagation = Propagation.NESTED)
    @Override
    public void edit(MetricEditParam metricEditParam) {
        Metric metric = this.queryEntity(metricEditParam.getId());
        BeanUtil.copyProperties(metricEditParam, metric);

        validateMetricDuplication(metric,false);

        this.updateById(metric);

        dispatchDataCollectEvent(metric);
    }

    private  void dispatchDataCollectEvent(Metric measurements) {
        if(measurements != null && "true".equalsIgnoreCase(measurements.getAutoStart())){
            final JSONObject measure = JSONUtil.parseObj(measurements);
            final JSONArray eventParam = JSONUtil.createArray();
            eventParam.add(measure);
            //todo ?? doAddWithData or doUpdateWithData
            CommonDataChangeEventCenter.doAddWithData(IotDataTypeEnum.MEASUREMENT.getValue(),eventParam);
            // 派发采集事件后，修改采集状态为 running
            metricService.update(
                    Wrappers.lambdaUpdate(Metric.class)
                            .eq(Metric::getId,measurements.getId())
                            .set(Metric::getCollectStatus, MetricStatus.RUNNING.name())
            );
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<MetricIdParam> metricIdParamList) {
        // 执行删除
        final List<String> ids = CollStreamUtil.toList(metricIdParamList, MetricIdParam::getId);
        this.removeByIds(ids);

        CommonDataChangeEventCenter.doDeleteWithDataId(IotDataTypeEnum.MEASUREMENT.getValue(),ids);
    }

    @Override
    public Metric detail(MetricIdParam metricIdParam) {
        return this.queryEntity(metricIdParam.getId());
    }

    @Override
    public Metric queryEntity(String id) {
        Metric measurements = this.getById(id);
        if(ObjectUtil.isEmpty(measurements)) {
            throw new CommonException("设备传感器指标不存在，id值为：{}", id);
        }
        return measurements;
    }

    @Override
    public List<DeviceSensorNode> tree() {

        final List<Device> devices = deviceService.list();
        List<DeviceSensorNode> deviceTreeNodes = devices.stream().map(
                device -> DeviceSensorNode.builder().id(device.getId()).parentId("0").name(device.getName()).type("DEVICE").build())
                .collect(Collectors.toList());

        final List<Sensor> sensors = sensorService.list();
        final List<DeviceSensorNode> sensorTreeNodes = sensors.stream().map(
                        sensor -> DeviceSensorNode.builder().id(sensor.getId()).parentId(sensor.getOwner()).name(sensor.getName()).type("SENSOR").build())
                .collect(Collectors.toList());

        final ArrayListMultimap<String,DeviceSensorNode> sensorMap = ArrayListMultimap.create();
        sensorTreeNodes.forEach( sensor -> sensorMap.put(sensor.getParentId(),sensor));

        deviceTreeNodes.forEach( deviceNode -> deviceNode.setChildren(sensorMap.get(deviceNode.getId())));


        return deviceTreeNodes;
    }

    @Override
    public Object getMeasurementsDetailByIds(List<String> ids) {

        return metricsMapper.getMeasurementsDetailInfo(ids);

    }

    @Override
    public Object getLatestValue(String id) {

        final Metric metric = metricService.getById(id);
        final String ownerId = metric.getOwnerId();

        final Device device = deviceService.getById(ownerId);
        final RestClient client = tbHelper.login();
        final DeviceId entityId = DeviceId.fromString(device.getTbDevId());
        final List<String> timeseriesKeys = client.getTimeseriesKeys(entityId);
        final List<TsKvEntry> latestTimeseries = client.getLatestTimeseries(entityId, timeseriesKeys);

        if(Objects.nonNull(latestTimeseries)){

            final List<cn.hutool.json.JSONObject> datapoints = latestTimeseries.stream().map(tsKv -> {
                final long ts = tsKv.getTs();
                final String humanReadableDate = dateTimeFormatter.format(LocalDateTime.ofInstant(Instant.ofEpochMilli(ts), ZoneId.systemDefault()));
                return JSONUtil.createObj().set(humanReadableDate, tsKv.getValue());
            }).collect(Collectors.toList());

            return datapoints;
        }
        client.logout();


        return "";
    }

    @Override
    public void clone(MetricIdParam idParam) {

        final Metric metric = getById(idParam.getId());

        final String name = metric.getName();

        final LambdaQueryWrapper<Metric> nameCountQryWhere = Wrappers.lambdaQuery(Metric.class).likeRight(Metric::getName, name);
        long nameCount = this.count(nameCountQryWhere);

        String cloneName = name.concat("-").concat(String.valueOf((nameCount++)));


        Date now = new Date();
        Metric clone = new Metric();
        BeanUtil.copyProperties(metric, clone);

        clone.setName(cloneName);
        clone.setAutoStart("false");
        clone.setCollectStatus(MetricStatus.STOPPED.name());
        clone.setCreateTime(now);
        clone.setUpdateTime(now);
        clone.setId(null);

        final boolean save = this.save(clone);
    }


    public void validateMetricDuplication(Metric metric,boolean create) {

        long thresholdNum = -1 ;
        if(create){
            thresholdNum = 0;
        }else{
            thresholdNum = 1;
        }

        if(StringUtils.isNotBlank(metric.getOwnerType()) && StringUtils.isBlank(metric.getOwnerId())){
            throw new CommonException("ownerType不为空 而 ownerId为空 !");
        }

        final LambdaQueryWrapper<Metric> condition = Wrappers.lambdaQuery(Metric.class).eq(Metric::getName, metric.getName());

        if(StringUtils.isNotBlank(metric.getOwnerType())){
            condition.eq(Metric::getOwnerType, metric.getOwnerType());
            //如果指标绑定了产品
            if("PRODUCT".equalsIgnoreCase(metric.getOwnerType())){
                condition.eq(Metric::getOwnerId, metric.getOwnerId());
                final long count = this.count(condition);
                if(count > thresholdNum){
                    log.warn("产品下指标重复: productId = {}, metricName= {}", metric.getOwnerId(),metric.getName());
                    throw new CommonException("同一个产品下不能有重复的指标名称: ".concat(metric.getName()));
                }
            }else if("DEVICE".equalsIgnoreCase(metric.getOwnerType())){

                final Device device = deviceService.getById(metric.getOwnerId());
                if(StringUtils.isNotBlank(device.getProduct())){
                    condition.and(i -> i.eq(Metric::getOwnerId, metric.getOwnerId()).or().eq(Metric::getOwnerId, device.getProduct()));
                }else{
                    condition.eq(Metric::getOwnerId, metric.getOwnerId());
                }

                final long count = this.count(condition);
                if(count > thresholdNum){
                    log.warn("设备下指标重复: deviceId = {}, metricName= {}", metric.getOwnerId(),metric.getName());
                    throw new CommonException("同一个设备下指标(包括从产品继承的指标)不能重复: ".concat(metric.getName()));
                }
            }
        }

    }
}
