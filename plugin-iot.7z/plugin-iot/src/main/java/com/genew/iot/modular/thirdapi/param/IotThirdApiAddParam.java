/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.thirdapi.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 接口管理添加参数
 *
 * @author js
 * @date 2023/03/28 10:09
 **/
@Getter
@Setter
public class IotThirdApiAddParam {

    /**
     * 主机地址
     */
    @ApiModelProperty(value = "接口IP", position = 6)
    private String host;

    /**
     * 主机端口
     */
    @ApiModelProperty(value = "接口端口", position = 7)
    private Integer port;

    /**
     * 所属系统
     */
    @ApiModelProperty(value = "所属系统", position = 8)
    private String systemId;

    /**
     * 接口名称
     */
    @ApiModelProperty(value = "接口名称", position = 9)
    private String apiAlias;

    /**
     * 是否立即执行
     */
    @ApiModelProperty(value = "是否立即执行", position = 10)
    private String autoStart;

    /**
     * 接口协议
     */
    @ApiModelProperty(value = "接口协议", position = 11)
    private String apiScheme;

    /**
     * 接口标识
     */
    @ApiModelProperty(value = "接口标识", position = 12)
    private String apiSign;

    /**
     * 请求方式
     */
    @ApiModelProperty(value = "请求方法", position = 13)
    private String requestMode;

    /**
     * 接口url
     */
    @ApiModelProperty(value = "接口路径", position = 14)
    private String apiPath;

    /**
     * 路径参数
     */
    @ApiModelProperty(value = "路径参数", position = 15)
    private String pathParam;

    /**
     * 查询参数
     */
    @ApiModelProperty(value = "查询参数", position = 16)
    private String queryParam;

    /**
     * 请求头参数
     */
    @ApiModelProperty(value = "请求头参数", position = 17)
    private String headerParam;

    /**
     * 认证参数
     */
    @ApiModelProperty(value = "认证参数", position = 18)
    private String authParam;

    /**
     * Body体参数
     */
    @ApiModelProperty(value = "Body体参数", position = 19)
    private String bodyParam;

    /**
     * 返回tokenPath
     */
    @ApiModelProperty(value = "返回tokenPath", position = 20)
    private String jsonPath;

    /**
     * 返回状态
     */
    @ApiModelProperty(value = "返回状态", position = 21)
    private Integer respStatus;

    /**
     * 数据源
     */
    @ApiModelProperty(value = "数据源", position = 22)
    private String dataSourceId;

    /**
     * 定时任务cron
     */
    @ApiModelProperty(value = "定时任务cron", position = 23)
    private String timingCron;

    /**
     * 对象id
     */
    @ApiModelProperty(value = "对象id", position = 24)
    private String timingEntityId;

    /**
     * 静态返回参数
     */
    @ApiModelProperty(value = "静态返回参数", position = 25)
    private String staticRespJson;

    /**
     * 定时任务状态
     */
    @ApiModelProperty(value = "定时任务状态", position = 26)
    private String jobStatus;

    /**
     * 接口前置处理脚本
     */
    @ApiModelProperty(value = "接口前置处理脚本", position = 27)
    private String beforeScripts;

    /**
     * 接口后置处理脚本
     */
    @ApiModelProperty(value = "接口后置处理脚本", position = 28)
    private String afterScripts;

}
