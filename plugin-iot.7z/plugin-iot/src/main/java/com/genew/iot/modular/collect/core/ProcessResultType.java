package com.genew.iot.modular.collect.core;

public enum ProcessResultType {

    PRIMITIVE("标量(简单值)","primitive"),

    JSON("JSON对象","json"),
    JSON_STRING("JSON对象字符串","json_string"),

    JSONARRY("JSON数组","jsonarray"),
    JSONARRY_STRING("JSON数组字符串","jsonarray_string");


    private final String name ;
    private final String value ;

    ProcessResultType(String name, String value){

        this.name = name;
        this.value = value;
    }


    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }
}
