package com.genew.iot.modular.metric.service.impl;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.result.ExcelImportResult;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.genew.common.exception.CommonException;
import com.genew.common.util.CommonDownloadUtil;
import com.genew.dbs.api.DataSourceApi;
import com.genew.dbs.core.entity.DsSource;
import com.genew.dev.api.DevDictApi;
import com.genew.iot.modular.collect.core.MetricStatus;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.metric.dto.MetricExcelModel;
import com.genew.iot.modular.metric.entity.Metric;
import com.genew.iot.modular.metric.handler.MetricExcelDicHandler;
import com.genew.iot.modular.metric.service.MetricImportExportService;
import com.genew.iot.modular.metric.service.MetricService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;


@Slf4j
@Service
public class MetricImportExportServiceImpl implements MetricImportExportService {

    @Resource
    private DevDictApi devDictApi;

    @Resource
    private DeviceService deviceService;

    @Resource
    private MetricService metricService;

    @Resource
    private DataSourceApi dataSourceApi;

    @Override
    public void downloadTemplate(HttpServletResponse response) {

        final List<JSONObject> dataCollectionType = devDictApi.selectDictByCode("DATA_COLLECTION_TYPE");
        final List<JSONObject> dataTypes = devDictApi.selectDictByCode("SENSOR_DATA_TYPE");
        final List<Device> devices = deviceService.list(Wrappers.lambdaQuery(Device.class).select(Device::getId, Device::getName));
        final List<DsSource> dataSourceList = dataSourceApi.getDataSourceList();

        ExportParams exportParams = new ExportParams("指标_导入模板","指标批量导入模板");
        exportParams.setDictHandler(new MetricExcelDicHandler(devices,dataTypes,dataSourceList,dataCollectionType));

        List<MetricExcelModel> data = new ArrayList<>();
        final Workbook wb = ExcelExportUtil.exportExcel(exportParams, MetricExcelModel.class, data);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            wb.write(bos);
            wb.close();
            final byte[] contents = bos.toByteArray();
            CommonDownloadUtil.download("指标批量导入模板.xls", contents, response);
        } catch (IOException e) {
           log.error("指标导入模板下载异常: ",e);
        }

    }


    @Override
    public JSONObject importMetrics(MultipartFile file) {

        final List<JSONObject> dataCollectionType = devDictApi.selectDictByCode("DATA_COLLECTION_TYPE");
        final List<JSONObject> dataTypes = devDictApi.selectDictByCode("SENSOR_DATA_TYPE");
        final List<Device> devices = deviceService.list(Wrappers.lambdaQuery(Device.class).select(Device::getId, Device::getName));
        final List<DsSource> dataSourceList = dataSourceApi.getDataSourceList();
        try {
            int successCount = 0;
            int errorCount = 0;

            ImportParams importParams = new ImportParams();
            importParams.setTitleRows(1);
            importParams.setDictHandler(new MetricExcelDicHandler(devices,dataTypes, dataSourceList, dataCollectionType));
            importParams.setNeedVerify(true);

            final ExcelImportResult<MetricExcelModel> result = ExcelImportUtil.importExcelMore(file.getInputStream(), MetricExcelModel.class, importParams);
            final List<MetricExcelModel> metricModelList = result.getList();

            JSONArray errorDetail = JSONUtil.createArray();

            // 文件校验
            if(result.isVerifyFail()){
                StringBuffer errBuf = new StringBuffer();
                for (MetricExcelModel entity : result.getFailList()) {
                    final JSONObject err = JSONUtil.createObj().set("index", entity.getRowNum()).set("msg", entity.getErrorMsg());
                    errorDetail.add(err);
                }

                return JSONUtil.createObj()
                        .set("totalCount", result.getFailList().size() + result.getList().size())
                        .set("successCount", 0)
                        .set("errorCount", result.getFailList().size() + result.getList().size())
                        .set("errorDetail", errorDetail);
            }


            // 重复指标验证：同一个设备下不能有重复的指标
            final Set<String> importMetricNames = CollStreamUtil.toSet(metricModelList, MetricExcelModel::getName);
            final long count = metricModelList.stream().distinct().count();
            if(count < metricModelList.size()){
                //find duplicate elements
                final Set<String> duplicateNames = metricModelList.stream().filter(e -> Collections.frequency(metricModelList, e) > 1).distinct().map(MetricExcelModel::getName).collect(Collectors.toSet());
                final JSONObject err = JSONUtil.createObj().set("msg", "存在重复指标(同一设备下不能有重复指标)" + duplicateNames.toString());
                errorDetail.add(err);
                return JSONUtil.createObj()
                        .set("totalCount", metricModelList.size())
                        .set("successCount", successCount)
                        .set("errorCount",errorCount)
                        .set("errorDetail",errorDetail);
            }

            Date createTime = new Date();
            for (int i = 0; i < metricModelList.size(); i++) {

                JSONObject jsonObject = this.doImport(metricModelList.get(i), i,createTime);
                if(jsonObject.getBool("success")) {
                    successCount++;
                } else{
                    errorCount++;
                    errorDetail.add(jsonObject);
                }
            }
            return JSONUtil.createObj()
                    .set("totalCount", metricModelList.size())
                    .set("successCount", successCount)
                    .set("errorCount", errorCount)
                    .set("errorDetail", errorDetail);
        } catch (Exception e) {
            log.error(">>>文件导入失败，原因{}", e);
            throw new CommonException("文件导入失败");
        }
    }


    public JSONObject doImport(MetricExcelModel model, int i, Date createTime) {

        try {

            // todo 导入按协议进行配置
            Metric metric = new Metric();

            final String protocol = model.getProtocol();

            metric.setName(model.getName());

            metric.setDataType(model.getDataType());
            metric.setDataUnit(model.getDataUnit());
            //metric.setDataAddr(model.getAddress());

            metric.setOwnerType("DEVICE");
            metric.setOwnerId(model.getDevice());

            metric.setProtocol(model.getProtocol());


            final Long intervalTime = model.getIntervalTime();
            metric.setIntervalTime(intervalTime == null?10: intervalTime);

            metric.setBeforeScripts(model.getScriptContent());
            metric.setScriptRtType(model.getScriptRtType());

            if(StringUtils.isNotBlank(model.getProtocolConf())){
                metric.setProtocolConf(model.getProtocolConf());
            }


            metric.setCreateTime(createTime);
            metric.setUpdateTime(createTime);

            metric.setCollectStatus(MetricStatus.STOPPED.name());
            metric.setAutoStart("false");

            metricService.save(metric);

            return JSONUtil.createObj().set("success", true);
        } catch (Exception e) {
            log.error(">>>数据导入异常，原因{}", e);
            return JSONUtil.createObj().set("success", false).set("index", i + 1).set("msg", "指标导入异常");
        }

    }
}
