/*
Copyright [2020] [https://www.xiaonuo.vip]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：

1.请不要删除和修改根目录下的LICENSE文件。
2.请不要删除和修改Snowy源码头部的版权声明。
3.请保留源码和相关描述文件的项目出处，作者声明等。
4.分发源码时候，请注明软件出处 https://gitee.com/xiaonuobase/snowy
5.在修改包名，模块名称，项目代码等时，请注明软件出处 https://gitee.com/xiaonuobase/snowy
6.若您的项目无法满足以上几点，可申请商业授权，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.controller;

import cn.hutool.json.JSONObject;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.iot.modular.device.param.DeviceExportParam;
import com.genew.iot.modular.device.service.DeviceImportExportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 设备台账导入、导出
 */
@Api(tags = "设备台账导入导出")
@RestController
@CrossOrigin
@RequestMapping("/iot/device/excel")
public class DeviceImportExportController {

    @Resource
    private DeviceImportExportService importExportService ;

   /**
     * 设备台账-导入模板下载
     */
    @ApiOperation("下载设备导入模板")
    @CommonLog("下载用户导入模板")
    @GetMapping(value = "template", produces = MediaType.APPLICATION_JSON_VALUE)
    public CommonResult<String> downloadDeviceImportTemplate(HttpServletResponse response) throws IOException {
        importExportService.downloadImportTemplate(response);
        return CommonResult.ok();
    }


    /**
     * 设备台账-批量导入
     */
    @ApiOperation("设备台账-批量导入")
    @CommonLog("设备台账-批量导入")
    @PostMapping("import")
    public CommonResult<JSONObject> importDevice(@RequestPart("file") @ApiParam(value="文件", required = true) MultipartFile file) {
        return CommonResult.data(importExportService.importDevices(file));
    }

    /**
     * 设备导出
     */
    @ApiOperation("设备信息导出")
    @CommonLog("设备信息导出")
    @GetMapping(value = "export", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public void exportDevice(DeviceExportParam exportParam, HttpServletResponse response) throws IOException {
        importExportService.exportDevices(exportParam, response);
    }



}
