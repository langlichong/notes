/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.sensor.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.genew.common.enums.CommonSortOrderEnum;
import com.genew.common.exception.CommonException;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.modular.metric.service.MetricService;
import com.genew.iot.modular.sensor.entity.Sensor;
import com.genew.iot.modular.sensor.mapper.SensorMapper;
import com.genew.iot.modular.sensor.param.SensorAddParam;
import com.genew.iot.modular.sensor.param.SensorEditParam;
import com.genew.iot.modular.sensor.param.SensorIdParam;
import com.genew.iot.modular.sensor.param.SensorPageParam;
import com.genew.iot.modular.sensor.service.SensorService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * 传感器Service接口实现类
 *
 * @author huhu
 * @date  2023/04/11 14:57
 **/
@Service
public class SensorServiceImpl extends ServiceImpl<SensorMapper, Sensor> implements SensorService {

    @Resource
    private MetricService metricService;
    @Override
    public Page<Sensor> page(SensorPageParam sensorPageParam) {
        QueryWrapper<Sensor> queryWrapper = new QueryWrapper<>();
        if(ObjectUtil.isNotEmpty(sensorPageParam.getName())) {
            queryWrapper.lambda().like(Sensor::getName, sensorPageParam.getName());
        }
        if(ObjectUtil.isNotEmpty(sensorPageParam.getOwner())) {
            queryWrapper.lambda().like(Sensor::getOwner, sensorPageParam.getOwner());
        }
        if(ObjectUtil.isAllNotEmpty(sensorPageParam.getSortField(), sensorPageParam.getSortOrder())) {
            CommonSortOrderEnum.validate(sensorPageParam.getSortOrder());
            queryWrapper.orderBy(true, sensorPageParam.getSortOrder().equals(CommonSortOrderEnum.ASC.getValue()),
                    StrUtil.toUnderlineCase(sensorPageParam.getSortField()));
        } else {
            queryWrapper.lambda().orderByDesc(Sensor::getUpdateTime,Sensor::getCreateTime,Sensor::getName);
        }
        return this.page(CommonPageRequest.defaultPage(), queryWrapper);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(SensorAddParam sensorAddParam) {
        Sensor sensor = BeanUtil.toBean(sensorAddParam, Sensor.class);
        this.save(sensor);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(SensorEditParam sensorEditParam) {
        Sensor sensor = this.queryEntity(sensorEditParam.getId());
        BeanUtil.copyProperties(sensorEditParam, sensor);
        this.updateById(sensor);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<SensorIdParam> sensorIdParamList) {
        this.removeByIds(CollStreamUtil.toList(sensorIdParamList, SensorIdParam::getId));
    }

    @Override
    public Sensor detail(SensorIdParam sensorIdParam) {
        return this.queryEntity(sensorIdParam.getId());
    }

    @Override
    public Sensor queryEntity(String id) {
        Sensor sensor = this.getById(id);
        if(ObjectUtil.isEmpty(sensor)) {
            throw new CommonException("传感器不存在，id值为：{}", id);
        }
        return sensor;
    }
}
