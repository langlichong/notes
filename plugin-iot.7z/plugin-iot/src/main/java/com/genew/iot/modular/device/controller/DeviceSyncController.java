/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.controller;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.iot.modular.device.param.DeviceCredentialParam;
import com.genew.iot.modular.device.param.PostTelemetryParam;
import com.genew.iot.modular.device.service.DeviceSyncService;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 设备台账 同步 Thingsboard
 */
@Api(tags = "设备台账同步Thingsboard")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
@RequestMapping("/iot/device")
public class DeviceSyncController {

    @Resource
    private DeviceSyncService deviceSyncService;

    @ApiOperation("同步设备到TB")
    @CommonLog("同步设备到TB")
    @PostMapping("sync2tb")
    public CommonResult<JSONArray> syncTB(@RequestBody List<String> ids) {
        final JSONArray res = deviceSyncService.sync2Tb(ids);
        return CommonResult.data(res);
    }

    @ApiOperation("修改TB设备token")
    @CommonLog("修改TB设备token")
    @PostMapping("sync-token")
    public CommonResult<JSONObject> changeDeviceCredentials(@RequestBody @Valid DeviceCredentialParam param){

        JSONObject res = deviceSyncService.changeDeviceCredentials(param);

        return CommonResult.data(res);

    }

    @ApiOperation("发送遥测数据")
    @CommonLog("发送遥测数据")
    @PostMapping("telemetry")
    public CommonResult<Boolean> postTelemetry2TbDevice(@RequestBody @Valid PostTelemetryParam param){

        boolean res = deviceSyncService.postTelemetry(param);

        return res?CommonResult.ok():CommonResult.error("遥测发送失败");

    }


    @ApiOperation("获取设备最新遥测")
    @CommonLog("获取设备最新遥测")
    @GetMapping("latest-telemetry")
    public CommonResult<Object> getLatestTelemetry(@RequestParam("id")String deviceId){

        Object res = deviceSyncService.getLatestTelemetries(deviceId);

        return CommonResult.data(res);

    }

    @ApiOperation("查询TB侧设备的 服务端 状态相关属性集")
    @CommonLog("查询TB侧设备的 服务端 状态相关属性集")
    @GetMapping("states")
    public CommonResult<Object> getDeviceActiveState(@RequestParam("id")String deviceId){

        Object res = deviceSyncService.getDeviceStates(deviceId);

        return CommonResult.data(res);

    }


    @ApiOperation("采集数据")
    @CommonLog("采集数据")
    @PostMapping("start-collect")
    public CommonResult<JSONArray> collectData(@RequestBody List<String> ids) {
        deviceSyncService.collectData(ids);
        return CommonResult.ok();
    }


    @ApiOperation("停止采集数据")
    @CommonLog("停止采集数据")
    @PostMapping("stop-collect")
    public CommonResult<JSONArray> stopCollect(@RequestBody List<String> ids) {
        deviceSyncService.stopCollectData(ids);
        return CommonResult.ok();
    }

}
