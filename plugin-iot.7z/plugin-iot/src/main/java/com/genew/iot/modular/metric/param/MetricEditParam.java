/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.metric.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 设备传感器指标编辑参数
 *
 * @author huhu
 * @date  2023/04/12 15:27
 **/
@Getter
@Setter
public class MetricEditParam {

    /** 主键 */
    @ApiModelProperty(value = "主键", required = true, position = 1)
    @NotBlank(message = "id不能为空")
    private String id;

    /** 指标名称 */
    @ApiModelProperty(value = "指标名称", required = true, position = 2)
    @NotBlank(message = "name不能为空")
    private String name;

    /** 属主类型 */
    @ApiModelProperty(value = "属主类型", required = true, position = 3)
    private String ownerType;

    /** 属主标识 */
    @ApiModelProperty(value = "属主标识", required = true, position = 3)
    private String ownerId;


    /** 数据类型 */
    @ApiModelProperty(value = "数据类型", required = true, position = 5)
    @NotNull(message = "dataType不能为空")
    private String dataType;

    /** 数据单位 */
    @ApiModelProperty(value = "数据单位", position = 6)
    private String dataUnit;

    /** 采集协议 */
    @ApiModelProperty(value = "采集协议", position = 7)
    private String protocol;

    /** 采集时间间隔(秒) */
    @ApiModelProperty(value = "采集时间间隔(秒)", position = 10)
    private Long intervalTime;

    @ApiModelProperty(value = "是否立即开始采集: true ,false", position = 14)
    private String autoStart;

    /** 采集状态 */
    @ApiModelProperty(value = "采集状态", position = 15)
    private String collectStatus;

    @ApiModelProperty(value = "推送前数据处理脚本", position = 16)
    private String beforeScripts;

    private String extJson;

    private String protocolConf;
    private String scriptRtType;
    private String responseProcessors;
}
