package com.genew.iot.modular.collect.collector;

import cn.hutool.core.util.StrUtil;
import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.core.util.OpcUaUtil;
import com.genew.iot.modular.collect.core.*;
import com.genew.iot.modular.metric.dto.protocol.OpcUaProtocolConf;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.milo.opcua.sdk.client.OpcUaClient;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * OPC-UA 订阅方式数据采集
 *
 * @author js
 * @date 2023/03/27 14:22
 */
@Slf4j
@Component
public class OpcUaSubCollector extends AbstractCollector<Map, Map> {

    @Resource
    protected OpcUaUtil opcUaUtil;

    @Override
    @ExceptionLog(value = "OPC-UA 订阅方式数据采集", type = LogTypes.collectData)
    protected CollectResponse<Map, Map> collectData() throws DataIntegrationException {
        final CollectRequest request = CollectContext.getRequest();
        final OpcUaProtocolConf opcUaProtocolConf = request.getOpcUaConf();
        log.info("--OPC-UA 订阅方式采集指标: {}", request.getId().concat(StrUtil.AT).concat(opcUaProtocolConf.toString()));
        Object object = gatherOpcUaSubData(request, opcUaProtocolConf);
        CollectResponse response = CollectResponse.builder()
                .originRequest(request)
                .collectResult(object)
                .collectResultType(ProcessResultType.PRIMITIVE)
                .build();
        return response;
    }

    /**
     * 采集Opc-Ua订阅数据
     *
     * @param request
     * @param opcUaProtocolConf
     * @return
     */
    private Object gatherOpcUaSubData(CollectRequest request, OpcUaProtocolConf opcUaProtocolConf) throws DataIntegrationException {
        //创建OPC UA客户端并开启连接
        try {
            OpcUaClient client = opcUaUtil.opcUaClientCache.get(request.getId());
            if (Objects.isNull(client)) {
                client = opcUaUtil.connect(request, opcUaProtocolConf);
            }
            // 订阅
            Supplier<CollectResponse> supplier = () -> {
                try {
                    return collectData();
                } catch (DataIntegrationException e) {
                    log.info("OPC-UA重新订阅采集失败:{}", e.getMessage());
                }
                return null;
            };
            opcUaUtil.subscribe(request, opcUaProtocolConf.getIdentifier(), client, supplier);
            //取值
            Object value = OpcUaUtil.opcUaSubCache.get(opcUaProtocolConf.getIdentifier());
            if (Objects.nonNull(value)) {
                return value;
            }
        } catch (Exception e) {
            throw new DataIntegrationException("OPC-UA订阅采集失败", e);
        }
        return StrUtil.EMPTY;
    }

    @Override
    protected boolean abortCollect(TaskId taskId) {
        // 终止采集任务
        abortCollectTask(taskId);
        // 终止采集opcClient
        abortGatheringOpcUaConnect(taskId);
        return true;
    }

    /**
     * 关闭OPC-连接
     *
     * @param taskId
     */
    private void abortGatheringOpcUaConnect(TaskId taskId) {
        OpcUaClient client = opcUaUtil.opcUaClientCache.get(taskId.toString());
        opcUaUtil.closeOpcUaConnect(client);
        opcUaUtil.opcUaClientCache.remove(taskId.toString());
    }

    @Override
    protected boolean support(CollectRequest request) {
        if (CollectTypes.OPC_UA_SUBSCRIBE.name().equalsIgnoreCase(request.getProtocol())) {
            return true;
        }
        return false;
    }
}
