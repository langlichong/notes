/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.genew.iot.modular.product.entity.Product;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.dromara.core.trans.anno.Trans;
import org.dromara.core.trans.constant.TransType;
import org.dromara.core.trans.vo.TransPojo;

import java.util.Date;
import java.util.Set;

/**
 * 设备台账实体
 *
 * @author zw
 * @date  2023/03/27 14:44
 **/
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@TableName(value = "iot_device", autoResultMap = true)
public class Device implements TransPojo {

    /** 主键 */
    @TableId
    @ApiModelProperty(value = "主键", position = 1)
    private String id;

    /** 设备编号 */
    @ApiModelProperty(value = "设备编号", position = 2)
    private String code;

    /** 设备名称 */
    @ApiModelProperty(value = "设备名称", position = 3)
    private String name;


    /** 设备类型标签名称 */
    @ApiModelProperty(value = "类型标签", position = 3)
    private String typeLabel;


    /** 产品类别 */
    @ApiModelProperty(value = "产品类别", position = 4)
    @Trans(type = TransType.SIMPLE, target = Product.class, fields = "name", ref = "productName")
    private String product;

    @TableField(exist = false)
    @ApiModelProperty(value = "产品名称", position = 5)
    private String productName;

    /** 设备编号 */
    @Trans(type = TransType.DICTIONARY, key = "DEVICE_OWNER")
    @ApiModelProperty(value = "设备属主", position = 6)
    private String owner;

    /** 对应TB设备ID */
    @ApiModelProperty(value = "对应TB设备ID", position = 7)
    private String tbDevId;

    /** 对应TB设备accessToken */
    @ApiModelProperty(value = "对应TB设备accessToken", position = 8)
    private String tbDevToken;

    /** 设备属性，如规格参数 json */
    @ApiModelProperty(value = "设备(静态)属性:JSON 格式", position = 9)
    private String attrs;

    /** 描述 */
    @ApiModelProperty(value = "REMARK", position = 10)
    private String remark;


    /** 创建时间 */
    @ApiModelProperty(value = "创建时间", position = 11)
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /** 创建人 */
    @ApiModelProperty(value = "创建人", position = 12)
    @TableField(fill = FieldFill.INSERT)
    private String createUser;

    /** 更新时间 */
    @ApiModelProperty(value = "更新时间", position = 13)
    @TableField(fill = FieldFill.UPDATE)
    private Date updateTime;

    /** 更新人 */
    @ApiModelProperty(value = "更新人", position = 14)
    @TableField(fill = FieldFill.UPDATE)
    private String updateUser;

    /** 指标个数 */
    @ApiModelProperty(value = "指标个数", position = 14)
    @TableField(exist = false)
    private Long metricNum;

    /** 指标协议 */
    @ApiModelProperty(value = "指标协议", position = 14)
    @TableField(exist = false)
    private Set<String> protocolList;

}
