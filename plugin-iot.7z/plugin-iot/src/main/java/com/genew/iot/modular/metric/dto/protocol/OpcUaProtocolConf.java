package com.genew.iot.modular.metric.dto.protocol;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 功能描述：Opc-Ua协议配置
 *
 * @Author： js
 * @create： 2023/8/30 11:37
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class OpcUaProtocolConf extends Common {
    /**
     * 主机地址
     */
    protected String hostIp;

    /**
     * 主机端口
     */
    protected Integer hostPort;

    /**
     * 标识地址
     */
    protected String identifier;
}

