/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.service;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import com.baomidou.mybatisplus.extension.service.IService;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.param.DeviceCredentialParam;
import com.genew.iot.modular.device.param.PostTelemetryParam;

import java.util.List;
import java.util.Map;

/**
 * 设备台账Service接口
 *
 * @author zw
 * @date  2023/03/27 14:44
 **/
public interface DeviceSyncService extends IService<Device> {

    /**
     * 同步 台账 到 Thingsboard
     * @param syncParam
     */
    JSONArray sync2Tb(List<String> ids);


    /**
     * 更新台账设备与 TB 侧设备引用ID
     * @param idMappings Map<台账中设备ID，TB中设备ID>
     * @return
     */
    boolean updateRefTbDevice(Map<String,String> idMappings,Map<String,String> devTokenMappings);

    /**
     * 修改设备 accessToken
     */
    JSONObject changeDeviceCredentials(DeviceCredentialParam param);

    /**
     * 发送遥测数据给 TB 中对应的设备
     */
    boolean postTelemetry(PostTelemetryParam param);

    Object getLatestTelemetries(String deviceId);

    /**
     * 查询TB侧设备的 服务端属性中状态相关属性集
     * @param deviceId 设备台账ID
     * @return
     */
    Object getDeviceStates(String deviceId);

    void collectData(List<String> deviceIdParam);

    void stopCollectData(List<String> syncParam);
}
