package com.genew.iot.core.util;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.genew.dev.api.DevConfigApi;
import com.genew.iot.core.config.MqttConfig;
import com.genew.iot.core.constant.MqttSubConstant;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.modular.collect.collector.MqttSubCollector;
import com.genew.iot.modular.metric.dto.protocol.MqttProtocolConf;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;

/**
 * Description:
 *
 * @Author js
 * @Date 2023/07/04
 */
@Slf4j
@Component
public class MqttUtil {

    /**
     * 客户端订阅ID
     */
    private final String clientId = "SUB" + (int) (Math.random() * 100000000);

    /**
     * MQTT异步客户端
     */
    public MqttAsyncClient mqttClient;
    /**
     * 连接配置
     */
    private MqttConnectOptions mqttConnectOptions;

    @Resource
    private DevConfigApi devConfigApi;

    /**
     * 功能描述: 客户端连接
     *
     * @param mqttConfig
     * @Author js
     * @Date 2023/07/04
     */
    public void connect(MqttConfig mqttConfig) {
        try {
            if (isConnected()) {
                return;
            }
            //设置配置
            if (mqttConnectOptions == null) {
                setOptions(mqttConfig);
            }
            //创建客户端
            if (mqttClient == null) {
                createClient(mqttConfig);
            }
            IMqttToken token = mqttClient.connect(mqttConnectOptions);
            token.waitForCompletion();
        } catch (Exception e) {
            log.error("【mqtt异常】:mqtt连接失败，message={}", e.getMessage());
        }
    }

    /**
     * 功能描述: 创建客户端
     *
     * @param mqttConfig
     * @Author js
     * @Date 2023/07/04
     */
    private void createClient(MqttConfig mqttConfig) {
        if (mqttClient == null) {
            try {
              /*host为主机名，clientId是连接MQTT的客户端ID，MemoryPersistence设置clientId的保存方式
                默认是以内存方式保存*/
                mqttClient = new MqttAsyncClient(mqttConfig.getHost(), clientId, new MemoryPersistence());
                log.debug("【mqtt】:mqtt客户端启动成功");
            } catch (MqttException e) {
                log.error("【mqtt异常】:mqtt客户端连接失败，error={}", e.getMessage());
            }
        }
    }

    /**
     * 功能描述: 设置连接属性
     * setCleanSession  true 断开连接即清楚会话  false 保留连接信息 离线还会继续发消息
     *
     * @param mqttConfig
     * @Author js
     * @Date 2023/07/04
     */
    private void setOptions(MqttConfig mqttConfig) {
        if (mqttConnectOptions != null) {
            mqttConnectOptions = null;
        }
        if (mqttConfig == null) {
            log.warn("【mqtt异常】：连接失败，失败原因：配置文件缺失。");
            return;
        }
        mqttConnectOptions = new MqttConnectOptions();
        //设置连接用户名
        mqttConnectOptions.setUserName(mqttConfig.getUsername());
        //设置连接密码
        mqttConnectOptions.setPassword(mqttConfig.getPassword().toCharArray());
        //设置超时时间，单位为秒
        mqttConnectOptions.setConnectionTimeout(mqttConfig.getTimeout());
        //设置心跳时间 单位为秒，表示服务器每隔1.5*20秒的时间向客户端发送心跳判断客户端是否在线
        mqttConnectOptions.setKeepAliveInterval(mqttConfig.getInterval());
        //设置连接URL
        mqttConnectOptions.setServerURIs(new String[]{mqttConfig.getHost()});
        //设置自动重新连接
        mqttConnectOptions.setAutomaticReconnect(true);
        //是否清空session，设置为false表示服务器会保留客户端的连接记录，客户端重连之后能获取到服务器在客户端断开连接期间推送的消息
        //设置为true表示每次连接到服务端都是以新的身份
        mqttConnectOptions.setCleanSession(mqttConfig.isClearSession());
        //设置遗嘱消息的话题，若客户端和服务器之间的连接意外断开，服务器将发布客户端的遗嘱信息
        mqttConnectOptions.setWill("willTopic", (clientId + "与服务器断开连接").getBytes(), 0, false);
    }

    /**
     * 是否处于连接状态
     */
    public boolean isConnected() {
        return mqttClient != null && mqttClient.isConnected();
    }

    /**
     * 功能描述: 断开与mqtt的连接
     *
     * @Author js
     * @Date 2023/07/04
     */
    public synchronized void disconnect() {
        //判断客户端是否null 是否连接
        if (isConnected()) {
            try {
                IMqttToken token = mqttClient.disconnect();
                token.waitForCompletion();
            } catch (MqttException e) {
                log.error("【mqtt异常】: 断开mqtt连接发生错误，message={}", e.getMessage());
            }
        }
        mqttClient = null;
    }

    /**
     * 功能描述: 重新连接MQTT
     *
     * @Author js
     * @Date 2023/07/04
     */
    public synchronized void refresh() throws MqttException {
        if (isConnected()) {
            mqttClient.disconnect();
            mqttClient.reconnect();
        }
    }


    /**
     * 功能描述: 发布
     *
     * @param qos         连接方式
     * @param retained    是否保留
     * @param topic       主题
     * @param pushMessage 消息体
     * @Author js
     * @Date 2023/07/04
     */
    public void publish(int qos, boolean retained, String topic, String pushMessage) throws DataIntegrationException {
        log.debug("【mqtt】:发布主题" + topic);
        MqttMessage message = new MqttMessage();
        message.setQos(qos);
        message.setRetained(retained);
        message.setPayload(pushMessage.getBytes());
        if (isConnected()) {
            try {
                IMqttToken token = mqttClient.publish(topic, message);
                token.waitForCompletion();
            } catch (MqttException e) {
                log.error("【mqtt异常】: 发布主题时发生错误 topic={},message={}", topic, e.getMessage());
                throw new DataIntegrationException("Mqtt远程控制失败", e);
            }
        }
    }

    /**
     * 功能描述: 订阅某个主题
     *
     * @param topic               主题
     * @param qos                 消息质量
     *                            Qos1：消息发送一次，不确保
     *                            Qos2：至少分发一次，服务器确保接收消息进行确认
     *                            Qos3：只分发一次，确保消息送达和只传递一次
     * @param mqttMessageListener
     * @Author js
     * @Date 2023/07/04
     */
    public void subscribe(String topic, int qos, MqttSubCollector.MqttMessageListener mqttMessageListener) {
        if (isConnected()) {
            try {
                IMqttToken token = mqttClient.subscribe(topic, qos, mqttMessageListener);
                token.waitForCompletion();
            } catch (MqttException e) {
                log.error("【mqtt异常】:订阅主题 topic={} 失败 message={}", topic, e.getMessage());
            }
        }
    }

    /**
     * 功能描述: 取消订阅某个主题
     *
     * @param topic 主题
     * @Author js
     * @Date 2023/07/04
     */
    public void cancelSubscribe(String topic) {
        log.info("【mqtt】:取消订阅了主题 topic={}", topic);
        if (isConnected()) {
            try {
                IMqttToken token = mqttClient.unsubscribe(topic);
                token.waitForCompletion();
            } catch (MqttException e) {
                log.error("【mqtt异常】:取消订阅主题 topic={} 失败 message={}", topic, e.getMessage());
            }
        }
    }

    /**
     * 功能描述: 订阅某些主题
     *
     * @param topics               主题
     * @param qos                  消息质量
     *                             Qos1：消息发送一次，不确保
     *                             Qos2：至少分发一次，服务器确保接收消息进行确认
     *                             Qos3：只分发一次，确保消息送达和只传递一次
     * @param mqttMessageListeners
     * @Author js
     * @Date 2023/07/04
     */
    public void batchSubscribe(String[] topics, int[] qos, MqttSubCollector.MqttMessageListener[] mqttMessageListeners) {
        log.debug("【mqtt】:订阅了主题 topic={}", Arrays.toString(topics));
        try {
            IMqttToken token = mqttClient.subscribe(topics, qos, mqttMessageListeners);
            token.waitForCompletion();
        } catch (MqttException e) {
            log.error("【mqtt异常】:订阅主题 topic={} 失败 message={}", topics, e.getMessage());
        }
    }

    /**
     * 获取Mqtt配置
     *
     * @param protocolConf
     * @return
     */
    public MqttConfig getMqttConfig(MqttProtocolConf protocolConf) {
        int timeout = Integer.parseInt(devConfigApi.getValueByKey(MqttSubConstant.SNOWY_MQTT_CONNECTION_TIMEOUT_KEY));
        int interval = Integer.parseInt(devConfigApi.getValueByKey(MqttSubConstant.SNOWY_MQTT_KEEPALIVE_INTERVAL_KEY));
        boolean clearSession = Boolean.valueOf(devConfigApi.getValueByKey(MqttSubConstant.SNOWY_MQTT_CLEAR_SESSION_KEY));
        String qosStr = devConfigApi.getValueByKey(MqttSubConstant.SNOWY_MQTT_QOS_KEY);
        int qos = Integer.parseInt(qosStr);
        String username = protocolConf.getUsername();
        if (StringUtils.isBlank(username)) {
            log.warn("【mqtt异常】:预配置Mqtt服务器用户名不能为空:{} ", protocolConf);
            return null;
        }
        String password = protocolConf.getPassword();
        if (StringUtils.isBlank(password)) {
            log.warn("【mqtt异常】:预配置Mqtt服务器密码不能为空:{} ", protocolConf);
            return null;
        }
        return MqttConfig.builder()
                .host(MqttSubConstant.MQTT_HOST_PREFIX + protocolConf.getHostIp() + StrUtil.COLON + protocolConf.getHostPort())
                .username(username)
                .password(password)
                .timeout(timeout)
                .interval(interval)
                .clearSession(clearSession)
                .topic(protocolConf.getTopic())
                .qos(qos).build();
    }
}
