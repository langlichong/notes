/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.device.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.param.*;

import java.util.List;

/**
 * 设备台账Service接口
 *
 * @author zw
 * @date  2023/03/27 14:44
 **/
public interface DeviceService extends IService<Device> {

    /**
     * 获取设备台账分页
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    Page<Device> page(DevicePageParam devicePageParam);

    /**
     * 添加设备台账
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    void add(DeviceAddParam deviceAddParam);

    /**
     * 编辑设备台账
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    void edit(DeviceEditParam deviceEditParam);

    /**
     * 删除设备台账
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    void delete(List<DeviceIdParam> deviceIdParamList);

    /**
     * 删除设备：DeleteDeviceParam.cascadeTb 为 True，则同时会删除TB侧设备
     * @param params  DeleteDeviceParam
     */
    void deleteOnCacade(DeleteDeviceParam params);

    /**
     * 获取设备台账详情
     *
     * @author zw
     * @date  2023/03/27 14:44
     */
    Device detail(DeviceIdParam deviceIdParam);

    /**
     * 获取设备台账详情
     *
     * @author zw
     * @date  2023/03/27 14:44
     **/
    Device queryEntity(String id);

    Object listMetrics(String devId);

    /**
     * 设备远程指令控制(仅支持基于TCP协议的设备)
     *
     * @param deviceActionIdParam
     * @return
     */
    void control(DeviceActionIdParam deviceActionIdParam);
}
