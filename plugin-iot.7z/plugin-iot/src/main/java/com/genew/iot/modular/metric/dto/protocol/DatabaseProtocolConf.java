package com.genew.iot.modular.metric.dto.protocol;

import lombok.Data;

@Data
public class DatabaseProtocolConf extends Common{

    /**
     * 协议名称
     */
    protected String protocol;


    /**
     * 数据源ID
     */
    private String dataSource;

    /**
     * SQL 内容
     */
    protected String sqlContent;


}
