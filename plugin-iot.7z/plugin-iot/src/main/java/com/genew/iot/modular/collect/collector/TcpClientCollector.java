package com.genew.iot.modular.collect.collector;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.core.util.TcpUtil;
import com.genew.iot.modular.collect.core.*;
import com.genew.iot.modular.metric.dto.protocol.TcpProtocolConf;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Objects;

/**
 * 功能描述：TCP订阅(Socket)采集-e.g.常州本安4路电源
 *
 * @Author： js
 * @create： 2023/8/24 11:29
 */
@Slf4j
@Component
public class TcpClientCollector extends AbstractCollector<JSONObject, String> {

    @Resource
    protected TcpUtil tcpUtil;

    @Override
    @ExceptionLog(value = "TCP订阅(Socket)采集", type = LogTypes.collectData)
    protected CollectResponse<JSONObject, String> collectData() throws DataIntegrationException {
        final CollectRequest request = CollectContext.getRequest();
        final TcpProtocolConf tcpProtocolConf = request.getTcpProtocolConf();
        log.info("--TcpClient方式采集指标: {}", request.getId().concat(StrUtil.AT).concat(tcpProtocolConf.toString()));
        Object object = gatherTcpClientData(tcpProtocolConf);
        CollectResponse response = CollectResponse.builder()
                .originRequest(request)
                .collectResult(object)
                .collectResultType(ProcessResultType.JSON).build();
        return response;
    }

    private Object gatherTcpClientData(TcpProtocolConf tcpProtocolConf) throws DataIntegrationException {
        Map<String, String> resultMap = tcpUtil.socketClientCollectData(tcpProtocolConf);
        if (Objects.nonNull(resultMap)) {
            return JSONUtil.parseObj(resultMap);
        }
        return StrUtil.EMPTY;
    }

    @Override
    protected boolean support(CollectRequest request) {
        if (CollectTypes.TCP_SUBSCRIBE.name().equalsIgnoreCase(request.getProtocol())) {
            return true;
        }
        return false;
    }
}

