/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.product.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpStatus;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.genew.common.enums.CommonSortOrderEnum;
import com.genew.common.exception.CommonException;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.metric.entity.Metric;
import com.genew.iot.modular.metric.service.MetricService;
import com.genew.iot.modular.product.entity.Product;
import com.genew.iot.modular.product.mapper.ProductMapper;
import com.genew.iot.modular.product.param.ProductAddParam;
import com.genew.iot.modular.product.param.ProductEditParam;
import com.genew.iot.modular.product.param.ProductIdParam;
import com.genew.iot.modular.product.param.ProductPageParam;
import com.genew.iot.modular.product.service.ProductService;
import com.genew.iot.modular.productmetric.entity.ProductMetric;
import com.genew.iot.modular.productmetric.service.ProductMetricService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 产品Service接口实现类
 *
 * @author huhu
 * @date  2023/06/29 15:41
 **/
@Service
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements ProductService {

    @Resource
    private DeviceService deviceService;

    @Resource
    private ProductMetricService productMetricService;

    @Resource
    private MetricService metricService;

    @Override
    public Page<Product> page(ProductPageParam productPageParam) {
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        if(ObjectUtil.isNotEmpty(productPageParam.getName())) {
            queryWrapper.lambda().like(Product::getName, productPageParam.getName());
        }
        if(ObjectUtil.isAllNotEmpty(productPageParam.getSortField(), productPageParam.getSortOrder())) {
            CommonSortOrderEnum.validate(productPageParam.getSortOrder());
            queryWrapper.orderBy(true, productPageParam.getSortOrder().equals(CommonSortOrderEnum.ASC.getValue()),
                    StrUtil.toUnderlineCase(productPageParam.getSortField()));
        } else {
            queryWrapper.lambda().last("order by update_time desc nulls last ");
        }
        final Page<Product> page = this.page(CommonPageRequest.defaultPage(), queryWrapper);
        final List<Product> records = page.getRecords();

        // 计算每个产品的指标数量
        final Set<String> productIds = records.stream().map(Product::getId).collect(Collectors.toSet());
        final List<Metric> metrics = metricService.list(
                Wrappers.lambdaQuery(Metric.class)
                        .select(Metric::getId,Metric::getOwnerId)
                        .in(Metric::getOwnerId, productIds)

        );

        final Map<String, Long> metricCountMap = metrics.stream().collect(Collectors.groupingBy(Metric::getOwnerId, Collectors.counting()));
        records.stream().forEach(product -> product.setMetricNum(metricCountMap.get(product.getId())));

        return page;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(ProductAddParam productAddParam) {
        Product product = BeanUtil.toBean(productAddParam, Product.class);
        Date now = new Date();
        product.setCreateTime(now);
        product.setUpdateTime(now);

        this.save(product);

        /*maintainProductMetricsRelation(product.getId(),productAddParam.getMetrics(),true);*/

    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(ProductEditParam productEditParam) {
        Product product = this.queryEntity(productEditParam.getId());
        BeanUtil.copyProperties(productEditParam, product);

        this.updateById(product);

        /*maintainProductMetricsRelation(product.getId(),productEditParam.getMetrics(),false);*/

    }

    private void maintainProductMetricsRelation(String productId, List<String> metrics,boolean createNewProduct) {

        // 移除旧映射关系
        if(!createNewProduct){
            productMetricService.remove(Wrappers.lambdaQuery(ProductMetric.class).eq(ProductMetric::getProductId, productId));
        }

        //保存新关系
        List<ProductMetric> pmList = new ArrayList<>();
        for (String metricId : metrics) {
            final ProductMetric productMetric = ProductMetric.builder().productId(productId).metricId(metricId).build();
            pmList.add(productMetric);
        }

        productMetricService.saveBatch(pmList);
    }

    @Transactional(rollbackFor = Exception.class,propagation = Propagation.NESTED)
    @Override
    public void delete(List<ProductIdParam> productIdParamList) {

        final List<String> ids = CollStreamUtil.toList(productIdParamList, ProductIdParam::getId);

        // 删除前验证是否有设备已经绑定了该产品
        final long refCounts = deviceService.count(Wrappers.lambdaQuery(Device.class).in(Device::getProduct, ids));
        if(refCounts > 0){
            throw new CommonException(HttpStatus.HTTP_FORBIDDEN,"产品被设备绑定,禁止删除!");
        }

        // 验证产品下是否有指标绑定
        final long count = metricService.count(Wrappers.lambdaQuery(Metric.class).in(Metric::getOwnerId, ids));
        if(count > 0){
            throw new CommonException(HttpStatus.HTTP_FORBIDDEN,"产品绑定了指标，请先删除指标或解绑!");
        }

        // 执行删除 产品
        this.removeByIds(ids);

        //删除产品与指标关联数据
        productMetricService.remove(Wrappers.lambdaQuery(ProductMetric.class).in(ProductMetric::getProductId,ids));
    }

    @Override
    public Product detail(ProductIdParam productIdParam) {
        return this.queryEntity(productIdParam.getId());
    }

    @Override
    public Product queryEntity(String id) {
        Product product = this.getById(id);
        if(ObjectUtil.isEmpty(product)) {
            throw new CommonException("产品不存在，id值为：{}", id);
        }
        return product;
    }
}
