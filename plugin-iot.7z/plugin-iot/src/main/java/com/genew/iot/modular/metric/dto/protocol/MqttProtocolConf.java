package com.genew.iot.modular.metric.dto.protocol;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 功能描述：Mqtt协议配置
 *
 * @Author： js
 * @create： 2023/8/30 11:38
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MqttProtocolConf extends Common {
    /**
     * 主机地址
     */
    protected String hostIp;

    /**
     * 主机端口
     */
    protected Integer hostPort;

    /**
     * 订阅主题
     */
    protected String topic;

    /**
     * 用户名
     */
    protected String username;

    /**
     * 密码
     */
    protected String password;

}

