/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.provision.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.genew.common.enums.CommonSortOrderEnum;
import com.genew.common.exception.CommonException;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.modular.provision.entity.IotProvision;
import com.genew.iot.modular.provision.mapper.IotProvisionMapper;
import com.genew.iot.modular.provision.param.IotProvisionAddParam;
import com.genew.iot.modular.provision.param.IotProvisionEditParam;
import com.genew.iot.modular.provision.param.IotProvisionIdParam;
import com.genew.iot.modular.provision.param.IotProvisionPageParam;
import com.genew.iot.modular.provision.service.IotProvisionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 预选项配置Service接口实现类
 *
 * @author js
 * @date 2023/05/24 14:12
 **/
@Service
public class IotProvisionServiceImpl extends ServiceImpl<IotProvisionMapper, IotProvision> implements IotProvisionService {

    @Override
    public Page<IotProvision> page(IotProvisionPageParam iotProvisionPageParam) {
        QueryWrapper<IotProvision> queryWrapper = new QueryWrapper<>();
        if (ObjectUtil.isNotEmpty(iotProvisionPageParam.getRefSystem())) {
            queryWrapper.lambda().eq(IotProvision::getRefSystem, iotProvisionPageParam.getRefSystem());
        }
        if (ObjectUtil.isAllNotEmpty(iotProvisionPageParam.getSortField(), iotProvisionPageParam.getSortOrder())) {
            CommonSortOrderEnum.validate(iotProvisionPageParam.getSortOrder());
            queryWrapper.orderBy(true, iotProvisionPageParam.getSortOrder().equals(CommonSortOrderEnum.ASC.getValue()),
                    StrUtil.toUnderlineCase(iotProvisionPageParam.getSortField()));
        } else {
            queryWrapper.lambda().orderByDesc(IotProvision::getUpdateTime, IotProvision::getId, IotProvision::getSortCode);
        }
        return this.page(CommonPageRequest.defaultPage(), queryWrapper);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(IotProvisionAddParam iotProvisionAddParam) {
        IotProvision iotProvision = BeanUtil.toBean(iotProvisionAddParam, IotProvision.class);
        this.save(iotProvision);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(IotProvisionEditParam iotProvisionEditParam) {
        IotProvision iotProvision = this.queryEntity(iotProvisionEditParam.getId());
        BeanUtil.copyProperties(iotProvisionEditParam, iotProvision);
        this.updateById(iotProvision);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<IotProvisionIdParam> iotProvisionIdParamList) {
        // 执行删除
        this.removeByIds(CollStreamUtil.toList(iotProvisionIdParamList, IotProvisionIdParam::getId));
    }

    @Override
    public IotProvision detail(IotProvisionIdParam iotProvisionIdParam) {
        return this.queryEntity(iotProvisionIdParam.getId());
    }

    @Override
    public IotProvision queryEntity(String id) {
        IotProvision iotProvision = this.getById(id);
        if (ObjectUtil.isEmpty(iotProvision)) {
            throw new CommonException("预选项配置不存在，id值为：{}", id);
        }
        return iotProvision;
    }
}
