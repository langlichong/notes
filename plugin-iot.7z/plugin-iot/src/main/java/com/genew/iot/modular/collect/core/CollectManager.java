package com.genew.iot.modular.collect.core;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.metric.entity.Metric;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import java.util.stream.Collectors;

@Data
@Slf4j
@Component
public final class CollectManager {

    @Resource
    private ThreadPoolTaskScheduler threadPool;

    /**
     * 缓存已经提交线程池的任务
     */
    private  Map<TaskId,ScheduledFuture> taskCache = new HashMap();

    private  Map<TaskId, AbstractCollector> taskCollectorMappings = new HashMap();

    //todo 构建采集上下文：如获取当前使用的采集器、当前的采集请求等 ，优化使用参数传递的管控风险

    @Resource
    private List<AbstractCollector> collectors;


    private void goAhead(){

        while (true){

            //1. 取一个采集请求
            final CollectRequest request = CollectRequestQueue.getRequest();

            //2. 在所有的采集器中寻找支持该任务的采集器,若没有则提示
            AbstractCollector supportedCollector = collectors.stream().filter(collector -> collector.support(request)).findFirst().orElse(null);
            if(supportedCollector == null){
                log.error("---- 数据采集：没有匹配的数据采集器, 任务: {}",request);
                continue;
            }

            //将协议配置json串转为 java bean
            ProtocolConfConverter.convert2BeanByCollectType(request);

            //3. 根据是否定时类型采集，向线程池提交任务
            final Runnable task = () -> {
                //数据采集上下文中放入 采集请求对象
                CollectContext.setRequest(request);
                supportedCollector.doCollect();
            };

            final Long intervalTimeInSeconds = request.getIntervalTime();
            //需要定时采集的指标
            if( intervalTimeInSeconds != null && intervalTimeInSeconds > 0){
                final ScheduledFuture<?> scheduledTask = threadPool.scheduleAtFixedRate(task,intervalTimeInSeconds * 1000);

                taskCache.put(TaskId.fromString(request.getId()),scheduledTask);

            }else{ // 一次性任务 , 不需要缓存
                threadPool.submit(task);
            }

            taskCollectorMappings.put(TaskId.fromString(request.getId()),supportedCollector);

        }
    }


    public void start(){
        log.info(" -------------- 启动数据采集 --------------");
        goAhead();
    }


    public void stop(){
        CollectRequestQueue.clear();
        for (ScheduledFuture task : taskCache.values()) {
            task.cancel(true);
        }
        //threadPool.shutdown();
    }


    public  boolean cancelTask(TaskId taskId){
        log.warn("---终止采集任务：taskId = {}",taskId);
        boolean abort = true ;
        if(taskCollectorMappings.containsKey(taskId)){
            abort = taskCollectorMappings.get(taskId).abortCollect(taskId);
            if(abort){
                taskCollectorMappings.remove(taskId);
            }
        }
        return abort;
    }

    public void submitCollectingRequest(CollectRequest request){
        CollectRequestQueue.addRequest(request);
    }

    public static void submitCollectRequest(Metric metric, DeviceService deviceService) {

        final CollectRequest request = BeanUtil.toBean(metric, CollectRequest.class);
        if("product".equalsIgnoreCase(metric.getOwnerType())){
            final List<Device> devices = deviceService.list(Wrappers.lambdaQuery(Device.class).isNotNull(Device::getTbDevId).eq(Device::getProduct, metric.getOwnerId()));
            final List<String> tbIds = devices.stream().map(Device::getTbDevId).collect(Collectors.toList());
            request.setPushTargetDevIds(tbIds);
        }else{
            final Device device = deviceService.getById(metric.getOwnerId());
            request.setPushTargetDevIds(Arrays.asList(device.getTbDevId()));
        }

        CollectRequestQueue.addRequest(request);
    }
}
