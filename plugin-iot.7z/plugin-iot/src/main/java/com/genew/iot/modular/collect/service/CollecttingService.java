package com.genew.iot.modular.collect.service;

import com.genew.iot.modular.metric.param.MetricIdParam;

import java.util.List;

public interface CollecttingService {
    void stopOrStartCollecttingOnSingle(MetricIdParam idParam);

    void startBatchCollectting(List<String> ids);

    void stopBatchCollectting(List<String> ids);
}
