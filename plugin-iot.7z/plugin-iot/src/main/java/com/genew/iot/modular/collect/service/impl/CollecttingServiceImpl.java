package com.genew.iot.modular.collect.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.genew.common.exception.CommonException;
import com.genew.iot.modular.collect.core.CollectManager;
import com.genew.iot.modular.collect.core.MetricStatus;
import com.genew.iot.modular.collect.core.TaskId;
import com.genew.iot.modular.collect.service.CollecttingService;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.metric.entity.Metric;
import com.genew.iot.modular.metric.param.MetricIdParam;
import com.genew.iot.modular.metric.service.MetricService;
import com.genew.iot.modular.sensor.service.SensorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class CollecttingServiceImpl implements CollecttingService {

    @Resource
    private MetricService metricService;

    @Resource
    private SensorService sensorService;

    @Resource
    private DeviceService deviceService;

    @Resource
    private CollectManager collectManager;


    @Override
    public void stopOrStartCollecttingOnSingle(MetricIdParam idParam){

        final Metric metric = metricService.getById(idParam.getId());
        final String currentStatus = metric.getCollectStatus();
        log.info("单指标采集任务启停, 指标ID: {},指标名称:{},当前状态: {}",metric.getId(),metric.getName(),currentStatus);
        String status = null;
        if(MetricStatus.RUNNING.name().equalsIgnoreCase(currentStatus)){
            // 取消任务
            final boolean ok = collectManager.cancelTask(TaskId.fromString(metric.getId()));
            if(ok){
                status = MetricStatus.STOPPED.name();
            }

        }else if(MetricStatus.STOPPED.name().equalsIgnoreCase(currentStatus)){

            //停止状态则加入到采集队列中
            CollectManager.submitCollectRequest(metric, deviceService);

            status = MetricStatus.RUNNING.name();
        }
        if(status != null){
            metricService.update(Wrappers.lambdaUpdate(Metric.class).eq(Metric::getId,metric.getId()).set(Metric::getCollectStatus,status));
        }
    }

    @Override
    public void startBatchCollectting(List<String> ids) {

        final List<Metric> metrics = metricService.list(Wrappers.lambdaQuery(Metric.class).isNotNull(Metric::getOwnerId).in(Metric::getId, ids));
        final boolean existProductBinding = metrics.stream().anyMatch(m -> "product".equalsIgnoreCase(m.getOwnerType()));
        if(existProductBinding){
            throw new CommonException("不能选择绑定到产品的指标进行数据采集 !");
        }
        //验证metric所绑定的设备已经同步到 TB
        final Set<String> devIds = metrics.stream().map(Metric::getOwnerId).collect(Collectors.toSet());
        final long count = deviceService.count(Wrappers.lambdaQuery(Device.class).isNotNull(Device::getTbDevId).in(Device::getId, devIds));
        if(devIds.size() != count){
            throw new CommonException("请确认指标绑定的设备已同步到 TB !");
        }
        for (Metric metric : metrics) {
            CollectManager.submitCollectRequest(metric,deviceService);
        }

        // 修改指标运行状态
        metricService.update(
                Wrappers.lambdaUpdate(Metric.class)
                        .in(Metric::getId,ids)
                        .set(Metric::getCollectStatus, MetricStatus.RUNNING.name())
        );
    }

    @Override
    public void stopBatchCollectting(List<String> ids) {
        final List<Metric> measurementsList = metricService.list(Wrappers.lambdaQuery(Metric.class).in(Metric::getId, ids));
        for (Metric measurement : measurementsList) {
            collectManager.cancelTask(TaskId.fromString(measurement.getId()));
        }

        // 修改指标运行状态
        metricService.update(
                Wrappers.lambdaUpdate(Metric.class)
                        .in(Metric::getId,ids)
                        .set(Metric::getCollectStatus, MetricStatus.STOPPED.name())
        );
    }
}
