package com.genew.iot.modular.collect.customized.dy485;

import lombok.Data;

import java.util.Arrays;

/**
 * @author : renqiang
 * @date : 2022-12-14 17:10
 * @description :
 */
@Data
public class BmsBody {


    /**
     * 地址
     */
    private byte address;

    /**
     * 功能码
     */
    private byte functionCode;

    /**
     * 长度
     */
    private byte dataPackageLength;

    /**
     * 数据包
     */
    private byte[] dataBody;

    /**
     * crc
     */
    private byte[] crc;

    /**
     * 放电状态
     */
    private Integer dischargeStatus;

    /**
     * 放电时长
     */
    private Integer dischargeDuration;


    @Override
    public String toString() {
        return "BmsBody{" +
                "address=" + Byte.toUnsignedInt(address) +
                ", functionCode=" + Byte.toUnsignedInt(functionCode) +
                ", dataPackageLength=" + Byte.toUnsignedInt(dataPackageLength) +
                ", dataBody=" + Arrays.toString(dataBody) +
                ", crc=" + Arrays.toString(crc) +
                ", dischargeStatus=" + dischargeStatus +
                ", dischargeDuration=" + dischargeDuration +
                '}';
    }
}
