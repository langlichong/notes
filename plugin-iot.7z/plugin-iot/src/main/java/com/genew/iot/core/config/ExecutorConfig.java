package com.genew.iot.core.config;

import com.genew.iot.core.constant.IotOpcUaConstant;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author js
 * @version 1.0
 * @description: 线程池配置类
 * @date 2022/11/23 11:27
 */
@Slf4j
@Configuration
public class ExecutorConfig {

    /**
     * 采集数据线程池
     */
    @Bean("threadPool")
    public static final ThreadPoolTaskScheduler threadPool() {
        log.info("start threadPoolTaskExecutor");
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        // 返回可用处理器的Java虚拟机的数量
        int processNum = Runtime.getRuntime().availableProcessors();
        int corePoolSize = calculateCorePoolSize(processNum);
        // 核心池大小
        scheduler.setPoolSize(corePoolSize);
        // 队列程度
        scheduler.setThreadPriority(Thread.MAX_PRIORITY);
        scheduler.setThreadNamePrefix("Data-Collect-");
        scheduler.setDaemon(true);
        // 线程空闲时间
        scheduler.setWaitForTasksToCompleteOnShutdown(true);
        scheduler.setAwaitTerminationSeconds(IotOpcUaConstant.OPC_THREAD_POOL_KEEP_ALIVE_TIME);
        // 拒绝策略
        scheduler.setRejectedExecutionHandler(getRejectedExecutionHandler());
        scheduler.initialize();
        return scheduler;
    }

    @NotNull
    private static RejectedExecutionHandler getRejectedExecutionHandler() {
        return (r, executor) -> {
            if (!executor.isShutdown()) {
                try {
                    executor.getQueue().put(r);
                } catch (InterruptedException e) {
                    log.error("getRejectedExecutionHandler failed:{}", e.getMessage());
                }
            }
        };
    }

    private static int calculateCorePoolSize(int processNum) {
        int corePoolSize = (int) (processNum / (1 - 0.6));
        log.info("核心线程数:{}", corePoolSize);
        return corePoolSize;
    }

    /**
     * 异步编排线程池
     *
     * @return ThreadPoolTaskExecutor
     */
    @Bean(name = "apiAsyncPool")
    public ThreadPoolExecutor apiAsyncPool() {
        return new ThreadPoolExecutor(
                //核心线程数
                10,
                //最大线程数
                20,
                60,
                TimeUnit.SECONDS,
                //队列大小
                new LinkedBlockingDeque<>(10),
                //定义线程名称
                new ThreadFactory() {
                    private final AtomicInteger mThreadNum = new AtomicInteger(1);

                    @Override
                    public Thread newThread(Runnable r) {
                        return new Thread(r, "apiAsyncPool-" + mThreadNum.getAndIncrement());
                    }
                },
                //拒绝策略
                new ThreadPoolExecutor.AbortPolicy()
        );
    }

}
