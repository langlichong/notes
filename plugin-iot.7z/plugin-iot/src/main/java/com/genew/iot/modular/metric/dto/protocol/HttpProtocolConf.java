package com.genew.iot.modular.metric.dto.protocol;

import lombok.Data;

@Data
public class HttpProtocolConf extends Common{

    /**
     * 协议名称
     */
    protected String protocol;


    /**
     * 协议schema: http , https
     */
    private String apiSchema;

    /**
     * 主机地址
     */
    protected String hostIp;

    /**
     * 主机端口
     */
    protected Integer hostPort;

    /**
     * 请求方法
     */
    private String httpMethod;

    /**
     * 请求路径
     */
    private String resourcePath;

    /**
     * http body
     */
    private String  httpBody ;


}
