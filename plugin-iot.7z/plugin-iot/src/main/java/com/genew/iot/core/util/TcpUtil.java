package com.genew.iot.core.util;

import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.genew.common.util.CommonIpAddressUtil;
import com.genew.dev.api.DevConfigApi;
import com.genew.iot.core.constant.TcpConstant;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.modular.collect.core.CollectRequest;
import com.genew.iot.modular.collect.core.CollectTypes;
import com.genew.iot.modular.collect.customized.ba4.Ba4Model;
import com.genew.iot.modular.collect.customized.ba4.BaDataBody;
import com.genew.iot.modular.collect.customized.ba4.RoadStatus;
import com.genew.iot.modular.collect.customized.dy485.BmsBody;
import com.genew.iot.modular.collect.customized.dy485.BmsDataBody;
import com.genew.iot.modular.metric.dto.protocol.TcpProtocolConf;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * 功能描述：TCP采集工具类
 *
 * @Author： js
 * @create： 2023/8/28 15:44
 */
@Slf4j
@Component
public class TcpUtil {

    private final ConcurrentMap<String, Socket> socketHashMap = Maps.newConcurrentMap();

    private final ConcurrentMap<String, CollectRequest> requestHashMap = Maps.newConcurrentMap();

    private final ConcurrentMap<String, ServerReceiveThread> threadHashMap = Maps.newConcurrentMap();

    private final ConcurrentMap<String, Map<String, String>> tcpValueCache = Maps.newConcurrentMap();

    private ServerSocket serverSocket = null;

    @Bean
    @Async
    public void socketCreate() throws DataIntegrationException {
        try {
            DevConfigApi devConfigApi = SpringUtil.getBean(DevConfigApi.class);
            int hostPort = Integer.parseInt(devConfigApi.getValueByKey(TcpConstant.TCP_SERVER_HOST_PORT));
            serverSocket = new ServerSocket(hostPort);
            log.info("------------socket服务端:{}开启------------", CommonIpAddressUtil.getLocalIP().concat(StrUtil.COLON) + hostPort);
            while (true) {
                Socket socket = serverSocket.accept();
                log.info("------------正在监听socket客户端:{}------------", socket.getRemoteSocketAddress());
                if (Objects.isNull(socketHashMap.get(socket.getInetAddress().getHostAddress()))) {
                    socketHashMap.put(socket.getInetAddress().getHostAddress(), socket);
                }
                if (Objects.isNull(threadHashMap.get(socket.getInetAddress().getHostAddress()))) {
                    threadHashMap.put(socket.getInetAddress().getHostAddress(), new ServerReceiveThread(socket));
                }
            }
        } catch (IOException e) {
            log.error("------------socket服务启动异常:{}------------", e.getMessage());
            throw new DataIntegrationException("------------socket服务启动异常------------", e);
        } catch (Exception e) {
            log.error("------------其他异常:{}------------", e.getMessage());
            throw new DataIntegrationException("------------其他异常------------", e);
        }
    }

    /**
     * socket客户端数据采集
     *
     * @param tcpProtocolConf
     * @return
     * @throws DataIntegrationException
     */
    public Map<String, String> socketClientCollectData(TcpProtocolConf tcpProtocolConf) throws DataIntegrationException {
        Socket socket = socketHashMap.get(tcpProtocolConf.getHostIp().concat(StrUtil.COLON) + tcpProtocolConf.getHostPort());
        Map<String, String> map = Maps.newConcurrentMap();
        try {
            if (Objects.isNull(socket)) {
                socket = new Socket(tcpProtocolConf.getHostIp(), tcpProtocolConf.getHostPort());
            }
            if (Objects.nonNull(socket)) {
                socketHashMap.put(tcpProtocolConf.getHostIp().concat(StrUtil.COLON) + tcpProtocolConf.getHostPort(), socket);
                final OutputStream outputStream = socket.getOutputStream();
                final InputStream inputStream = socket.getInputStream();
                map = getMultipleReturnMap(tcpProtocolConf, inputStream, outputStream);
            }
        } catch (Exception e) {
            throw new DataIntegrationException("socket客户端数据采集失败", e);
        }
        return map;
    }

    /**
     * 批量下发查询指令
     *
     * @param tcpProtocolConf
     * @param inputStream
     * @param outputStream
     * @return
     */
    @NotNull
    public Map<String, String> getMultipleReturnMap(TcpProtocolConf tcpProtocolConf, InputStream inputStream,
                                                    OutputStream outputStream) throws DataIntegrationException {
        JSONArray cmdList = tcpProtocolConf.getHexadecimals();
        Map<String, String> map = new ConcurrentHashMap<>(20);
        if (CollectionUtils.isEmpty(cmdList)) {
            return map;
        }
        for (Object jsonObject : cmdList) {
            Map<String, Object> paramMap = (Map<String, Object>) JSONUtil.parse(jsonObject);
            String cmd = paramMap.get("cmd").toString();
            String data = getReturnBytesByCmd(cmd, inputStream, outputStream);
            map.put(cmd, data);
        }
        return map;
    }

    /**
     * 单个指令下发
     *
     * @param cmd
     * @param inputStream
     * @param outputStream
     * @return
     * @throws IOException
     */
    public String getReturnBytesByCmd(String cmd, InputStream inputStream, OutputStream outputStream) throws DataIntegrationException {
        byte[] returnBytes;
        byte[] data;
        try {
            returnBytes = hexStrToByteArray(cmd);
            log.info("------------设备开始下发指令:{}------------", cmd);
            outputStream.write(returnBytes);
            outputStream.flush();
            byte[] buf = new byte[1024];
            int readLen = inputStream.read(buf);
            data = new byte[readLen];
            System.arraycopy(buf, 0, data, 0, readLen);
        } catch (Exception e) {
            log.error("------------下发指令有误，非十六进制指令：{}------------", e.getMessage());
            throw new DataIntegrationException("------------下发指令非十六进制指令异常------------", e);
        }
        return bytesToHexString(data);
    }

    /**
     * 数组转换成十六进制字符串
     *
     * @param bArray
     * @return HexString
     */
    public static final String bytesToHexString(byte[] bArray) {
        StringBuffer sb = new StringBuffer(bArray.length);
        String sTemp;
        for (int i = 0; i < bArray.length; i++) {
            sTemp = Integer.toHexString(0xFF & bArray[i]);
            if (sTemp.length() < 2) {
                sb.append(0);
            }
            sb.append(sTemp.toUpperCase());
        }
        return sb.toString();
    }

    /**
     * socket 服务端数据采集
     *
     * @param request
     * @return
     */
    public Map<String, String> socketServerCollectData(CollectRequest request, TcpProtocolConf tcpProtocolConf) {
        requestHashMap.put(tcpProtocolConf.getHostIp(), request);
        ServerReceiveThread thread = threadHashMap.get(tcpProtocolConf.getHostIp());
        if (Objects.nonNull(thread)) {
            thread.run();
        }
        Map<String, String> resultMap = tcpValueCache.get(request.getId());
        if (Objects.isNull(resultMap)) {
            return null;
        }
        log.info("------------设备下发指令后返回:{}------------", JSONUtil.toJsonStr(resultMap));
        return resultMap;
    }

    public BmsDataBody transform485Data(Map<String, String> map, String protocol, TcpProtocolConf tcpProtocolConf) {
        BmsDataBody dataBody = new BmsDataBody();
        for (String key : map.keySet()) {
            JSONArray jsonArray = tcpProtocolConf.getHexadecimals();
            if (CollectionUtils.isEmpty(jsonArray)) {
                break;
            }
            JSONObject jsonObject = JSONUtil.parseObj(jsonArray.get(0));
            if (!jsonObject.get("cmd").equals(key) || Objects.isNull(map.get(key))) {
                break;
            }
            byte[] buff = hexStrToByteArray(map.get(key));
            if (buff.length < 2) {
                break;
            }
            if (crcCheck(protocol, buff)) {
                BmsBody bmsBody = getBmsBody(buff);
                dataBody = getBmsDataBody(bmsBody.getDataBody());
                dataBody.setDischargeStatus(bmsBody.getDischargeStatus());
                dataBody.setDischargeDuration(bmsBody.getDischargeDuration());
            }
        }
        return dataBody;
    }

    public JSONArray transformBa4Data(Map<String, String> map, String protocol, TcpProtocolConf tcpProtocolConf) {
        List<Ba4Model> ba4ModelList = Lists.newArrayList();
        for (String key : map.keySet()) {
            JSONArray jsonArray = tcpProtocolConf.getHexadecimals();
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = JSONUtil.parseObj(jsonArray.get(i));
                if (!jsonObject.get("cmd").equals(key)) {
                    break;
                }
                byte[] buff = hexStrToByteArray(map.get(key));
                if (isLegal(protocol, buff)) {
                    Ba4Model ba4Model = new Ba4Model();
                    // 第三个字节值 长度
                    int length = buff[2];
                    BaDataBody dataBody = getBaDataBody(buff);
                    if (TcpConstant.THIRDLY_BYTE_VALUE_8.equals(String.valueOf(length))) {
                        // 电源本安输出4 路电流及工作状态
                        ba4Model = parserElectricity(dataBody.getData());
                    } else if (TcpConstant.THIRDLY_BYTE_VALUE_2.equals(String.valueOf(length))) {
                        // 电源状态信息；电源电池容量
                        ba4Model = parseStatusAndCapacity(dataBody.getData());
                    }
                    ba4ModelList.add(ba4Model);
                }
            }
        }
        if (CollectionUtils.isEmpty(ba4ModelList)) {
            return null;
        }
        return JSONUtil.parseArray(ba4ModelList);
    }

    /**
     * 校验返回数据是否合法
     *
     * @param buff
     * @return true-合法； false-不合法
     */
    private Boolean isLegal(String protocol, byte[] buff) {
        if (!crcCheck(protocol, buff)) {
            // crc校验不通过，不处理
            return false;
        }
        // 第一个字节值 地址
        int address = buff[0];
        if (address < 0 && address > 31) {
            // 超出地址范围，不做处理
            return false;
        }
        // 第二个字节值 固定值
        int fixed1 = 0x04;
        if (fixed1 != buff[1]) {
            // 第二个字节固定值 不是该值，不处理
            return false;
        }
        return true;
    }

    /**
     * 将十六进制的字符串转换成字节数组
     *
     * @param hexString
     * @return
     */
    public static byte[] hexStrToByteArray(String hexString) {
        if (StringUtils.isEmpty(hexString)) {
            return null;
        }

        hexString = hexString.replaceAll(" ", "");
        int len = hexString.length();
        int index = 0;

        byte[] bytes = new byte[len / 2];

        while (index < len) {
            String sub = hexString.substring(index, index + 2);
            bytes[index / 2] = (byte) Integer.parseInt(sub, 16);
            index += 2;
        }

        return bytes;
    }

    public class ServerReceiveThread implements Runnable {

        private Socket socket;

        public ServerReceiveThread(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            final CollectRequest request = requestHashMap.get(socket.getInetAddress().getHostAddress());
            if (Objects.isNull(request)) {
                return;
            }
            final TcpProtocolConf tcpProtocolConf = request.getTcpProtocolConf();
            try {
                //输入流接收数据
                InputStream inputStream = socket.getInputStream();
                //输出流发送数据
                OutputStream outputStream = socket.getOutputStream();
                Map<String, String> map = getMultipleReturnMap(tcpProtocolConf, inputStream, outputStream);
                tcpValueCache.put(request.getId(), map);
            } catch (Exception e) {
                log.error("------------接收数据异常:{}------------", e.getMessage());
            }
        }
    }

    /**
     * 从解析的数据中  抽取需要上报的数据
     *
     * @param dataBody
     * @return
     */
    public static JSONObject reportedJson(BmsDataBody dataBody) {
        JSONObject jsonObject = JSONUtil.parseObj(dataBody.toJsonStr());
        JSONObject newJson = new JSONObject();
        // 电源状态
        newJson.set("status1", jsonObject.get("status1"));
        // 放电状态
        newJson.set("dischargeStatus", jsonObject.get("dischargeStatus"));
        // 放电时长
        newJson.set("dischargeDuration", jsonObject.get("dischargeDuration"));
        // 剩余电量
        newJson.set("soc", jsonObject.get("soc"));
        // 电池电压
        newJson.set("vBat", jsonObject.get("vBat"));
        // 充电电压
        newJson.set("vdcIn", jsonObject.get("vdcIn"));
        // 充电电流
        newJson.set("ib", jsonObject.get("ib"));
        // 放电电流
        newJson.set("ia", jsonObject.get("ia"));
        // 电池温度
        newJson.set("temperature", Double.valueOf(jsonObject.get("temperature").toString()) / 2);
        int status2 = bytes2Int(dataBody.getStatus2());
        // 保护状态：位0:过充电压
        newJson.set("status2_0", getBitValue(status2, 0));
        // 保护状态：位1:过放电压
        newJson.set("status2_1", getBitValue(status2, 1));
        // 保护状态：位2:充电过流
        newJson.set("status2_2", getBitValue(status2, 2));
        // 保护状态：位3:放电过流
        newJson.set("status2_3", getBitValue(status2, 3));
        // 保护状态：位4:输出短路
        newJson.set("status2_4", getBitValue(status2, 4));
        // 保护状态：位5:电池组温度报警
        newJson.set("status2_5", getBitValue(status2, 5));
        // 保护状态：位6:环境温度(预留)
        newJson.set("status2_6", getBitValue(status2, 6));
        // 保护状态：位7:低电量警告
        newJson.set("status2_7", getBitValue(status2, 7));
        int status3 = bytes2Int(dataBody.getStatus2());
        // 保护失效状态故障报警：位0:过充电压保护失效
        newJson.set("status3_0", getBitValue(status3, 0));
        // 保护失效状态故障报警：位1:过放电压保护失效
        newJson.set("status3_1", getBitValue(status3, 1));
        // 保护失效状态故障报警：位2:充电过流保护失效
        newJson.set("status3_2", getBitValue(status3, 2));
        // 保护失效状态故障报警：位3:放电过流保护失效
        newJson.set("status3_3", getBitValue(status3, 3));
        // 保护失效状态故障报警：位4:输出短路保护失效
        newJson.set("status3_4", getBitValue(status3, 4));
        // 保护失效状态故障报警：位5:电池组温度报警
        newJson.set("status3_5", getBitValue(status3, 5));
        // 保护失效状态故障报警：位6:环境温度故障报警
        newJson.set("status3_6", getBitValue(status3, 6));
        // 保护失效状态故障报警：位7:采集信号失效故障
        newJson.set("status3_7", getBitValue(status3, 7));
        return newJson;
    }

    /**
     * 两字节的byte数组转int 高位在前，低位在后
     *
     * @param buf
     * @return
     */
    public static int bytes2Int(byte[] buf) {
        byte heightByte = buf[0];
        byte lowByte = buf[1];
        return (lowByte & 0xff) << 0 | (heightByte & 0xff) << 8;
    }

    /**
     * 低位在前
     * int 到字节数组的转换
     *
     * @param number
     * @return
     */
    public static byte[] intToByte(int number) {
        int temp = number;
        byte[] b = new byte[2];
        for (int i = 0; i < b.length; i++) {
            // 将最低位保存在最低位
            b[i] = Integer.valueOf(temp & 0xff).byteValue();
            // 向右移8位
            temp = temp >> 8;
        }
        return b;
    }

    /**
     * 一个字节 8位 取每一位的值
     *
     * @param num
     * @param bit
     * @return
     */
    public static Integer getBitValue(int num, int bit) {
        int i = 0;
        switch (bit) {
            case 0:
                i = num & TcpConstant.bit0;
                break;
            case 1:
                i = (num & TcpConstant.bit1) >> 1;
                break;
            case 2:
                i = (num & TcpConstant.bit2) >> 2;
                break;
            case 3:
                i = (num & TcpConstant.bit3) >> 3;
                break;
            case 4:
                i = (num & TcpConstant.bit4) >> 4;
                break;
            case 5:
                i = (num & TcpConstant.bit5) >> 5;
                break;
            case 6:
                i = (num & TcpConstant.bit6) >> 6;
                break;
            case 7:
                i = (num & TcpConstant.bit7) >> 7;
                break;
        }
        return i;
    }

    public static BaDataBody getBaDataBody(byte[] buff) {
        BaDataBody data = new BaDataBody();
        data.setAddress(buff[0]);
        data.setSecondFixed(buff[1]);
        data.setThirdlyFixed(buff[2]);
        // 数据
        byte[] body = new byte[buff[2]];
        System.arraycopy(buff, 3, body, 0, data.getThirdlyFixed());
        // crc
        byte[] crc = new byte[2];
        System.arraycopy(buff, buff.length - 2, crc, 0, 2);
        data.setData(body);
        data.setCrc(crc);
        return data;
    }

    /**
     * crc 校验
     *
     * @param protocol
     * @param req
     * @return
     */
    private Boolean crcCheck(String protocol, byte[] req) {
        byte[] crc = new byte[2];
        System.arraycopy(req, req.length - 2, crc, 0, 2);
        byte[] body = new byte[req.length - 2];
        System.arraycopy(req, 0, body, 0, req.length - 2);
        String bodyCrcStr = StrUtil.EMPTY;
        String crcStr = String.valueOf(bytes2Int(crc));
        if (CollectTypes.TCP_POLL.name().equalsIgnoreCase(protocol)) {
            bodyCrcStr = String.valueOf(crc16(body));
        } else if (CollectTypes.TCP_SUBSCRIBE.name().equalsIgnoreCase(protocol)) {
            bodyCrcStr = String.valueOf(bytes2Int(intToByte(crc16(body))));
        }
        log.info("body:{}  crc:{}", bodyCrcStr, crcStr);
        return bodyCrcStr.equals(crcStr);
    }

    /**
     * 485电源返回数据
     * 本机地址	功能码	数据包长度	返回数据	校验和
     * 1字节	    1字节	1个字节	    N字节	2字节（CRC校验）
     * <p>
     * 字节转无符号int
     * Byte.toUnsignedInt(req[i]);
     *
     * @param buff
     * @return
     */
    public static BmsBody getBmsBody(byte[] buff) {
        BmsBody bmsBody = new BmsBody();
        bmsBody.setAddress(buff[0]);
        bmsBody.setFunctionCode(buff[1]);
        bmsBody.setDataPackageLength(buff[2]);
        byte[] body = new byte[buff[2]];
        System.arraycopy(buff, 3, body, 0, bmsBody.getDataPackageLength());
        byte[] crc = new byte[2];
        System.arraycopy(buff, buff.length - 2, crc, 0, 2);
        bmsBody.setDataBody(body);
        bmsBody.setCrc(crc);
        //放电状态和放电时长
        bmsBody.setDischargeStatus(buff[17] / 64);
        bmsBody.setDischargeDuration((buff[17] & 0x63) * 256 + buff[18]);
        return bmsBody;
    }

    /**
     * 同时解析 电源状态信息和电源电池容量
     *
     * @param buff 两个字节内容
     * @return
     */
    public static Ba4Model parseStatusAndCapacity(byte[] buff) {
        int i = bytes2Int(buff);
        // 电源工作状态  0-正常工作；1-无电池
        int capacity = (i & TcpConstant.height2Bit) >> 14;

        // 电池容量百分比
        int percentageOfCapacity = i & TcpConstant.flag;

        // 交直流供电状态 0-电池供电；1-交流供电
        int batteryStatus = i & TcpConstant.low2Bit;

        // 远程维护充放电状态 0-正在维护放电；1-未维护放电
        int dischargeStatus = (i & TcpConstant.low23Bit) >> 2;

        Ba4Model ba4 = new Ba4Model();
        ba4.setBatteryStatus(batteryStatus);
        ba4.setDischargeStatus(dischargeStatus);
        ba4.setCapacity(capacity);
        ba4.setPercentageOfCapacity(percentageOfCapacity);
        DecimalFormat df = new DecimalFormat("0.00");
        ba4.setRemainingCapacity(Double.valueOf(df.format((double) (percentageOfCapacity / 100 * TcpConstant.AH_VALUE))));
        return ba4;
    }

    /**
     * 电源本安输出4 路电流及工作状态
     * 01 04 08 01 ED 01 DD 01 7D 01 7D 65 58
     * 0x01: 传感器地址
     * 0x04: 固定
     * 0x08: 固定
     * 0x01 0xED 一路
     * 0x01 0xDD 二路
     * 0x01 0x7D 三路
     * 0x01 0x7D 四路
     * <p>
     * 第一路输出电流及状态。高字节bit7-bit6为工作状态，00-工作正常，01-故障；
     * 高字节bit5-bit0，和低字节bit7-bit0转换为整数表示输出电流值，0x1ED转换为整数值表示493mA
     * <p>
     * 其他三路规则同上
     * 0x65 0x58: 校验位CRC16，低字节在前，高字节在后，根据数据进行校验
     *
     * @param buff 4路8字节内容
     * @return
     */
    public static Ba4Model parserElectricity(byte[] buff) {
        byte[] ba1B = new byte[2];
        System.arraycopy(buff, 0, ba1B, 0, 2);
        byte[] ba2B = new byte[2];
        System.arraycopy(buff, 2, ba2B, 0, 2);
        byte[] ba3B = new byte[2];
        System.arraycopy(buff, 4, ba3B, 0, 2);
        byte[] ba4B = new byte[2];
        System.arraycopy(buff, 6, ba4B, 0, 2);
        RoadStatus road1 = getRoadStatus(ba1B);
        RoadStatus road2 = getRoadStatus(ba2B);
        RoadStatus road3 = getRoadStatus(ba3B);
        RoadStatus road4 = getRoadStatus(ba4B);
        Ba4Model ba4 = new Ba4Model();
        ba4.setBa1Status(road1.getStatus());
        ba4.setBa1Electricity(road1.getElectricity());
        ba4.setBa2Status(road2.getStatus());
        ba4.setBa2Electricity(road2.getElectricity());
        ba4.setBa3Status(road3.getStatus());
        ba4.setBa3Electricity(road3.getElectricity());
        ba4.setBa4Status(road4.getStatus());
        ba4.setBa4Electricity(road4.getElectricity());
        return ba4;
    }

    /**
     * 根据路数值 转换
     *
     * @param road
     * @return
     */
    private static RoadStatus getRoadStatus(byte[] road) {
        int i = bytes2Int(road);
        // 高两位的状态值(0-工作正常；1-故障) 右移14位 转为10进制数
        int sta = (i & TcpConstant.height2Bit) >> 14;
        // 高两位外 右边14位 的电流值
        int cur = i & TcpConstant.height2OtherBit;
        return RoadStatus.builder().status(sta).electricity(cur).build();
    }

    /**
     * 485电源返回数据
     * bms 返回数据
     * <p>
     * 01 04 40 00 03 00 00 00 00 00 00 7B 73 05 07 02 55 00 00 00 00
     * 地址 功能码 长度 系统状态   保护状态  失效报警    放电电流  端口电压   剩余电量   充电电流     预留        预留
     * 36 B0 05 83 05 83 05 83 05 83 05 83 05 83 05 83 05 83 05 83 05 83 05 83
     * 额定容量   单体电压
     * 05 83 05 83 05 83 05 83 05 83 05 83 05 83 05 83 05 83 6E 43 00 2E E5 6C
     * 电池总电压  温度      CRC校验
     *
     * @param buff 数据包
     */
    public static BmsDataBody getBmsDataBody(byte[] buff) {
        BmsDataBody dataBody = new BmsDataBody();
        System.arraycopy(buff, 0, dataBody.getStatus1(), 0, 2);
        System.arraycopy(buff, 2, dataBody.getStatus2(), 0, 2);
        System.arraycopy(buff, 4, dataBody.getStatus3(), 0, 2);
        System.arraycopy(buff, 6, dataBody.getIa(), 0, 2);
        System.arraycopy(buff, 8, dataBody.getVdcIn(), 0, 2);
        System.arraycopy(buff, 10, dataBody.getSoc(), 0, 2);
        System.arraycopy(buff, 12, dataBody.getIb(), 0, 2);
        System.arraycopy(buff, 14, dataBody.getBalance1(), 0, 2);
        System.arraycopy(buff, 16, dataBody.getBalance2(), 0, 2);
        System.arraycopy(buff, 18, dataBody.getRatedCapacity(), 0, 2);
        System.arraycopy(buff, 20, dataBody.getVCell1(), 0, 2);
        System.arraycopy(buff, 22, dataBody.getVCell2(), 0, 2);
        System.arraycopy(buff, 24, dataBody.getVCell3(), 0, 2);
        System.arraycopy(buff, 26, dataBody.getVCell4(), 0, 2);
        System.arraycopy(buff, 28, dataBody.getVCell5(), 0, 2);
        System.arraycopy(buff, 30, dataBody.getVCell6(), 0, 2);
        System.arraycopy(buff, 32, dataBody.getVCell7(), 0, 2);
        System.arraycopy(buff, 34, dataBody.getVCell8(), 0, 2);
        System.arraycopy(buff, 36, dataBody.getVCell9(), 0, 2);
        System.arraycopy(buff, 38, dataBody.getVCell10(), 0, 2);
        System.arraycopy(buff, 40, dataBody.getVCell11(), 0, 2);
        System.arraycopy(buff, 42, dataBody.getVCell12(), 0, 2);
        System.arraycopy(buff, 44, dataBody.getVCell13(), 0, 2);
        System.arraycopy(buff, 46, dataBody.getVCell14(), 0, 2);
        System.arraycopy(buff, 48, dataBody.getVCell15(), 0, 2);
        System.arraycopy(buff, 50, dataBody.getVCell16(), 0, 2);
        System.arraycopy(buff, 52, dataBody.getVCell17(), 0, 2);
        System.arraycopy(buff, 54, dataBody.getVCell18(), 0, 2);
        System.arraycopy(buff, 56, dataBody.getVCell19(), 0, 2);
        System.arraycopy(buff, 58, dataBody.getVCell20(), 0, 2);

        System.arraycopy(buff, (buff.length - 4), dataBody.getVBat(), 0, 2);
        System.arraycopy(buff, (buff.length - 2), dataBody.getTemperature(), 0, 2);
        return dataBody;
    }

    /**
     * CRC16 编码  低字节在前 高字节在后
     *
     * @param bytes 编码内容
     * @return 编码结果
     */
    public static int crc16(byte[] bytes) {
        int res = TcpConstant.INITIAL_VALUE;
        for (byte data : bytes) {
            // 把byte转换成int后再计算
            res = res ^ (data & 0XFF);
            for (int i = 0; i < TcpConstant.BITS_OF_BYTE; i++) {
                res = (res & 0X0001) == 1 ? (res >> 1) ^ TcpConstant.POLYNOMIAL : res >> 1;
            }
        }
        return res;
    }
}