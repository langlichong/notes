package com.genew.iot.modular.device.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Setter
@Getter
public class DeviceCredentialParam {

    @ApiModelProperty(value = "TB侧设备ID")
    @NotBlank(message = "设备ID不能为空")
    private String tbDeviceId;

    @ApiModelProperty(value = "设备Token")
    @NotBlank(message = "Token值不能为空")
    private String tokenValue;
}
