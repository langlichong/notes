package com.genew.iot.core.util;

import cn.hutool.core.collection.CollUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 统计工具类
 *
 * @author js
 **/
@Slf4j
public class StatisticsUtils {
    /**
     * 判断一个字符串是不是全是数字的正则匹配规则
     */
    private static Pattern pattern = Pattern.compile("^-?\\d+(\\.\\d+)?$");

    /**
     * 日志记录对象
     */
    private StatisticsUtils() {

    }

    /**
     * 同比，环比均可用
     * <p>
     * 获取增长率,保留四位小数
     * <p>
     * 增长率=(本月数-上月数)/上月数×100%
     *
     * @param lastCount    上月的数据
     * @param currentCount 本月的数据
     * @return float
     */
    public static String getGrowthRate(double lastCount, double currentCount) {
        double growthRate;
        if (lastCount == 0) {
            growthRate = 1;
        } else {
            growthRate = (float) (currentCount - lastCount) / lastCount;
        }
        //保留4为小数
        return String.format("%.4f", growthRate);
    }

    /**
     * 获取占比
     *
     * @param molecular   分子
     * @param denominator 分母
     * @return 返回占比
     */
    public static String getProportion(double molecular, double denominator) {
        String proportion;
        if (denominator == 0) {
            proportion = "";
        } else {
            double pro = molecular / denominator;
            proportion = String.format("%.4f", pro);
        }
        return proportion;
    }

    /**
     * 把对象转换成双精度数据
     *
     * @param object object
     * @return 双精度数据
     */

    public static double getObjectToDouble(Object object) {
        String str = String.valueOf(object).trim();
        if (StringUtils.isEmpty(str)) {
            return 0;
        }
        if (!isNumber(str)) {
            throw new NumberFormatException("字符串里面不全是数字，不能转换");
        }
        return Double.parseDouble(str);
    }

    /**
     * 把对象转换成字符串
     *
     * @param object object
     * @return String
     */

    public static String getObjectToString(Object object) {
        if (object == null) {
            return "";
        }
        return String.valueOf(object).trim();
    }

    /**
     * 判断一个字符串是不是全是数字
     *
     * @param string 判断是不是全数字的字符串
     * @return 布尔值
     */
    private static boolean isNumber(String string) {
        if (StringUtils.isEmpty(string)) {
            return false;
        }
        return pattern.matcher(string).matches();
    }

    /**
     * 获取昨年和今年同比的数据
     *
     * @param thisYearList 今年的数据
     * @param lastYearList 昨年的数据
     * @return 同比数据集合
     */
    public static List getYearOnYearList(List thisYearList, List lastYearList) {
        //住院总费用同比增长集合
        List yearOnYearZngeList = new ArrayList<>();
        for (int i = 0; i < thisYearList.size(); i++) {
            //获取今年每月对应的收入map
            Map thisYearMap = (Map) thisYearList.get(i);
            //获取去年每月对应的收入map
            Map lastYearMap = (Map) lastYearList.get(i);
            Object thisYearCost = thisYearMap.get("thisYearCost");
            Object lastYearCost = lastYearMap.get("lastYearCost");
            double thisYearCount = StatisticsUtils.getObjectToDouble(thisYearCost);
            double lastYearCount = StatisticsUtils.getObjectToDouble(lastYearCost);
            //根据去年和今年的总收入算出对应的增长率
            String growthRate = StatisticsUtils.getGrowthRate(lastYearCount, thisYearCount);
            //时间横坐标 1月、 2月……
            String dateAbscissa = (String) thisYearMap.get("dateAbscissa");
            //每次计算得出的增长率map
            Map yearOnYearMap = new HashMap<>(16);
            //吧每月对应的增长率放入map
            yearOnYearMap.put("dateAbscissa", dateAbscissa);
            yearOnYearMap.put("thisYearCount", thisYearCount);
            yearOnYearMap.put("lastYearCount", lastYearCount);
            yearOnYearMap.put("growthRate", growthRate);
            yearOnYearZngeList.add(yearOnYearMap);
        }
        return yearOnYearZngeList;
    }

    /**
     * 获取双精度数据的后几位数据
     *
     * @param d     双精度数据
     * @param digit 需要保留小数点后几位
     * @return 返回处理后的字符串对象
     */
    public static String getNumberFormatByDecimalPlaces(double d, int digit) {
        NumberFormat numberInstance = NumberFormat.getNumberInstance();
        numberInstance.setMaximumFractionDigits(digit);
        return numberInstance.format(d);
    }

    /**
     * 获取上月环比日期
     *
     * @param date          本月日期
     * @param formatPattern 日期的匹配格式
     * @return 获取上月环比日期
     */
    private static String getLastMouthDate(String date, String formatPattern) {
        Date lastMouth = new Date();
        try {
            SimpleDateFormat format = new SimpleDateFormat(formatPattern);
            Date currentDate = format.parse(date);
            Calendar c = Calendar.getInstance();
            c.setTime(currentDate);
            c.add(Calendar.MONTH, -1);
            lastMouth = c.getTime();
        } catch (ParseException e) {
            log.error("获取环比日期异常", e);
        }
        return format(lastMouth, formatPattern);

    }

    /**
     * 获取去年同比日期
     *
     * @param date          今年对应的日期
     * @param formatPattern 日期的匹配格式
     * @return 获取去年同比日期
     */
    public static String getLastYearDate(String date, String formatPattern) {
        Date lastYear = new Date();
        try {
            SimpleDateFormat format = new SimpleDateFormat(formatPattern);
            Date currentDate = format.parse(date);
            Calendar c = Calendar.getInstance();
            c.setTime(currentDate);
            c.add(Calendar.YEAR, -1);
            lastYear = c.getTime();
        } catch (ParseException e) {
            log.error("获取同比日期异常", e);
        }
        return format(lastYear, formatPattern);
    }

    /**
     * 格式化时间成字符串
     *
     * @param time          需要格式化的时间
     * @param formatPattern 日期的匹配格式
     * @return 返回对应格式的时间字符串
     */

    private static String format(Date time, String formatPattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(formatPattern);
        return sdf.format(time);
    }

    /**
     * 分组统计数据
     *
     * @param collection 列表
     * @param key        分类值
     * @param value      计算值
     * @param function   计算过程
     * @param <T>
     * @param <K>
     * @param <V>
     * @return
     */
    public static <T, K, V> Map<K, V> sumByKeyAndValue(Collection<T> collection,
                                                       Function<T, K> key,
                                                       Function<T, V> value,
                                                       BiFunction<V, V, V> function) {
        if (CollUtil.isEmpty(collection)) {
            return Collections.emptyMap();
        }
        Map<K, V> result = new HashMap<>();
        Map<K, List<T>> collect = collection.stream().collect(Collectors.groupingBy(key, Collectors.toList()));
        for (Map.Entry<K, List<T>> item : collect.entrySet()) {
            V reduce = item.getValue().stream().map(value).reduce((x, y) -> function.apply(x, y)).get();
            result.put(item.getKey(), reduce);
        }
        return result;
    }

    /**
     * 分组统计数据
     *
     * @param collection 列表
     * @param key        分类值
     * @param <T>
     * @param <K>
     * @return
     */
    public static <T, K> Map<K, Integer> countByKeyAndValue(Collection<T> collection, Function<T, K> key) {
        if (CollUtil.isEmpty(collection)) {
            return Collections.emptyMap();
        }
        Map<K, Integer> result = new HashMap<>();
        Map<K, List<T>> collect = collection.stream()
                .collect(Collectors.groupingBy(key, Collectors.toList()));
        for (Map.Entry<K, List<T>> item : collect.entrySet()) {
            result.put(item.getKey(), item.getValue().size());
        }
        return result;
    }

    /**
     * 求和
     *
     * @param arr
     * @return
     */
    public static double getSum(double[] arr) {
        double sum = 0;
        for (double num : arr) {
            sum += num;
        }
        return sum;
    }

    /**
     * 求均值
     *
     * @param arr
     * @return
     */
    public static double getMean(double[] arr) {
        return getSum(arr) / arr.length;
    }

    /**
     * 求众数
     *
     * @param arr
     * @return
     */
    public static double getMode(double[] arr) {
        Map<Double, Integer> map = new HashMap<>();
        for (int i = 0; i < arr.length; i++) {
            if (map.containsKey(arr[i])) {
                map.put(arr[i], map.get(arr[i]) + 1);
            } else {
                map.put(arr[i], 1);
            }
        }
        int maxCount = 0;
        double mode = -1;
        Iterator<Double> iter = map.keySet().iterator();
        while (iter.hasNext()) {
            double num = iter.next();
            int count = map.get(num);
            if (count > maxCount) {
                maxCount = count;
                mode = num;
            }
        }
        return mode;
    }

    /**
     * 求中位数
     *
     * @param arr
     * @return
     */
    public static double getMedian(double[] arr) {
        double[] tempArr = Arrays.copyOf(arr, arr.length);
        Arrays.sort(tempArr);
        if (tempArr.length % 2 == 0) {
            return (tempArr[tempArr.length >> 1] + tempArr[(tempArr.length >> 1) - 1]) / 2;
        } else {
            return tempArr[(tempArr.length >> 1)];
        }
    }


    /**
     * 求中列数
     *
     * @param arr
     * @return
     */
    public static double getMidrange(double[] arr) {
        double max = arr[0], min = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        return (min + max) / 2;
    }

    /**
     * 求四分位数
     *
     * @param arr
     * @return 存放三个四分位数的数组
     */
    public static double[] getQuartiles(double[] arr) {
        double[] tempArr = Arrays.copyOf(arr, arr.length);
        Arrays.sort(tempArr);
        double[] quartiles = new double[3];
        // 第二四分位数（中位数）
        quartiles[1] = getMedian(tempArr);
        // 求另外两个四分位数
        if (tempArr.length % 2 == 0) {
            quartiles[0] = getMedian(Arrays.copyOfRange(tempArr, 0, tempArr.length / 2));
            quartiles[2] = getMedian(Arrays.copyOfRange(tempArr, tempArr.length / 2, tempArr.length));
        } else {
            quartiles[0] = getMedian(Arrays.copyOfRange(tempArr, 0, tempArr.length / 2));
            quartiles[2] = getMedian(Arrays.copyOfRange(tempArr, tempArr.length / 2 + 1, tempArr.length));
        }
        return quartiles;
    }

    /**
     * 求极差
     *
     * @param arr
     * @return
     */
    public static double getRange(double[] arr) {
        double max = arr[0], min = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        return max - min;
    }

    /**
     * 求四分位数极差
     *
     * @param arr
     * @return
     */
    public static double getQuartilesRange(double[] arr) {
        return getRange(getQuartiles(arr));
    }

    /**
     * 求截断均值
     *
     * @param arr 求值数组
     * @param p   截断量p，例如p的值为20，则截断20%（高10%，低10%）
     * @return
     */
    public static double getTrimmedMean(double[] arr, int p) {
        int tmp = arr.length * p / 100;
        double[] tempArr = Arrays.copyOfRange(arr, tmp, arr.length + 1 - tmp);
        return getMean(tempArr);
    }

    /**
     * 求方差
     *
     * @param arr
     * @return
     */
    public static double getVariance(double[] arr) {
        double variance = 0;
        double sum = 0, sum2 = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
            sum2 += arr[i] * arr[i];
        }
        variance = sum2 / arr.length - (sum / arr.length) * (sum / arr.length);
        return variance;
    }

    /**
     * 求绝对平均偏差(AAD)
     *
     * @param arr
     * @return
     */
    public static double getAbsoluteAverageDeviation(double[] arr) {
        double sum = 0;
        double mean = getMean(arr);
        for (int i = 0; i < arr.length; i++) {
            sum += Math.abs(arr[i] - mean);
        }
        return sum / arr.length;
    }

    /**
     * 求中位数绝对偏差(MAD)
     *
     * @param arr
     * @return
     */
    public static double getMedianAbsoluteDeviation(double[] arr) {
        double[] tempArr = new double[arr.length];
        double median = getMedian(arr);
        for (int i = 0; i < arr.length; i++) {
            tempArr[i] = Math.abs(arr[i] - median);
        }
        return getMedian(tempArr);
    }

    /**
     * 求标准差
     *
     * @param arr
     * @return
     */
    public static double getStandardDevition(double[] arr) {
        double sum = 0;
        double mean = getMean(arr);
        for (int i = 0; i < arr.length; i++) {
            sum += Math.sqrt((arr[i] - mean) * (arr[i] - mean));
        }
        return (sum / (arr.length - 1));
    }

    /**
     * * @描述: 加法 <br/>
     * * @方法名: add <br/>
     * * @param v1 <br/>
     * * @param v2 <br/>
     * * @return <br/>
     * * @返回类型 double <br/>
     * * @since <br/>
     * * @throws
     */
    public static double add(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.add(b2).doubleValue();
    }

    /**
     * * @描述: 减法 <br/>
     * * @方法名: subtract <br/>
     * * @param v1 <br/>
     * * @param v2 <br/>
     * * @return <br/>
     * * @返回类型 double <br/>
     * * @since <br/>
     * * @throws
     */
    public static double subtract(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.subtract(b2).doubleValue();
    }

    /**
     * * @描述: 乘法 <br/>
     * * @方法名: mul <br/>
     * * @param d1 <br/>
     * * @param d2 <br/>
     * * @return <br/>
     * * @返回类型 double <br/>
     * * @since <br/>
     * * @throws
     */
    public static double multiply(double d1, double d2) {// 进行乘法运算
        BigDecimal b1 = new BigDecimal(d1);
        BigDecimal b2 = new BigDecimal(d2);
        return b1.multiply(b2).doubleValue();
    }

    /**
     * * @描述: 除法 ，四舍五入<br/>
     * * @方法名: div <br/>
     * * @param d1 <br/>
     * * @param d2 <br/>
     * * @param len ，保留的小数位数<br/>
     * * @return <br/>
     * * @返回类型 double <br/>
     * * @since <br/>
     * * @throws
     */
    public static double divide(double d1, double d2, int len) {// 进行除法运算
        BigDecimal b1 = new BigDecimal(d1);
        BigDecimal b2 = new BigDecimal(d2);

        return b1.divide(b2, len, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    /**
     * @param d1 <br/>
     * @param d2 <br/>
     * @return <br/>
     * @throws <br/>
     * @描述: 除法，四舍五入取整数 ,例如：5/2=3(2.5四舍五入); 5/3=2(1.6四舍五入);<br/>
     * @方法名: div   <br/>
     * @返回类型 double  <br/>
     * @since <br/>
     */
    public static double divide(double d1, double d2) {// 进行除法运算
        BigDecimal b1 = new BigDecimal(d1);
        BigDecimal b2 = new BigDecimal(d2);
        return b1.divide(b2, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    /**
     * * @描述: 四舍五入 <br/>
     * * @方法名: round  * @param d <br/>
     * * @param len <br/>
     * * @return <br/>
     * * @返回类型 double <br/>
     * * @throws <br/>
     */
    public static double round(double d, int len) {
        BigDecimal b1 = new BigDecimal(d);
        BigDecimal b2 = new BigDecimal(1);
        // 任何一个数字除以1都是原数字
        // ROUND_HALF_UP是BigDecimal的一个常量，表示进行四舍五入的操作
        return b1.divide(b2, len, BigDecimal.ROUND_HALF_UP).doubleValue();
    }
}