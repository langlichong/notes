package com.genew.iot.modular.device.service.impl;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.genew.common.exception.CommonException;
import com.genew.common.util.CommonDownloadUtil;
import com.genew.dev.api.DevDictApi;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.excel.DeviceImportModel;
import com.genew.iot.modular.device.excel.ExcelDicHandler;
import com.genew.iot.modular.device.param.DeviceExportParam;
import com.genew.iot.modular.device.service.DeviceImportExportService;
import com.genew.iot.modular.device.service.DeviceService;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.dromara.trans.service.impl.TransService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


@Slf4j
@Service
public class DeviceImportExportServiceImpl implements DeviceImportExportService {

    @Resource
    private DevDictApi devDictApi;

    @Resource
    private DeviceService deviceService;

    @Resource
    private TransService transService;

    @Override
    public void downloadImportTemplate(HttpServletResponse response) {


        // 查询【设备属主】字典项下拉框（DEVICE_OWNER）预配置所有值：
        final List<JSONObject> ownerFieldDropdownData = devDictApi.selectDictByCode("DEVICE_OWNER");

        ExportParams exportParams = new ExportParams("设备台账_导入模板","设备台账模板");
        exportParams.setDictHandler(new ExcelDicHandler(ownerFieldDropdownData));

        List<DeviceImportModel> data = new ArrayList<>();
        final Workbook wb = ExcelExportUtil.exportExcel(exportParams, DeviceImportModel.class, data);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            wb.write(bos);
            wb.close();
            final byte[] contents = bos.toByteArray();
            CommonDownloadUtil.download("设备批量导入模板.xls", contents, response);
        } catch (IOException e) {
           log.error("设备导入模板下载异常: ",e);
        }

    }

    @Override
    public void exportDevices(DeviceExportParam exportParam, HttpServletResponse response) {

        final LambdaQueryWrapper<Device> queryWrapper = Wrappers.lambdaQuery(Device.class);
        if(ObjectUtil.isNotEmpty(exportParam.getCode())) {
            queryWrapper.like(Device::getCode, exportParam.getCode());
        }
        if(ObjectUtil.isNotEmpty(exportParam.getName())) {
            queryWrapper.like(Device::getName, exportParam.getName());
        }
        if(ObjectUtil.isNotEmpty(exportParam.getOwner())) {
            queryWrapper.like(Device::getOwner, exportParam.getOwner());
        }
        if(ObjectUtil.isNotEmpty(exportParam.getDeviceIds())){
            queryWrapper.in(Device::getId,exportParam.getDeviceIds().split(","));
        }

        final List<Device> devices = this.deviceService.list(queryWrapper);

        if(ObjectUtil.isNotEmpty(devices)){
            transService.transBatch(devices);
        }

        final List<DeviceImportModel> exportDevices = devices.stream().map(d -> {

            DeviceImportModel model = new DeviceImportModel();
            BeanUtil.copyProperties(d, model);
            return model;
        }).collect(Collectors.toList());

        ExportParams exportParams = new ExportParams("设备台账列表", "台账");
        exportParams.setDictHandler(new ExcelDicHandler());
        exportParams.setCreateHeadRows(true);

        Workbook wb = ExcelExportUtil.exportExcel(exportParams, DeviceImportModel.class, exportDevices);

        ByteArrayOutputStream bos = new ByteArrayOutputStream(1024);
        try {
            wb.write(bos);
            wb.write(bos);
            wb.close();
            final byte[] contents = bos.toByteArray();
            CommonDownloadUtil.download("设备台账.xls", contents, response);
        } catch (IOException e) {
           log.error("设备台账导出失败：",e);
           throw new CommonException("设备台账导出失败: ".concat(e.getMessage()));
        }
    }


    @Override
    public JSONObject importDevices(MultipartFile file) {

        try {
            int successCount = 0;
            int errorCount = 0;

            JSONArray errorDetail = JSONUtil.createArray();
            // 读取excel
            List<DeviceImportModel> deviceList =
                    EasyExcel.read(file.getInputStream())
                            .head(DeviceImportModel.class)
                            .sheet()
                            .headRowNumber(2)
                            .doReadSync();

            if(deviceList == null || deviceList.isEmpty()){

                final JSONObject err = JSONUtil.createObj().set("msg", "请检查文件内容是否为空");
                errorDetail.add(err);

                return JSONUtil.createObj()
                        .set("totalCount", deviceList.size())
                        .set("successCount", successCount)
                        .set("errorCount", deviceList.size())
                        .set("errorDetail", errorDetail);

            }

            final Set<String> importCodeSet = CollStreamUtil.toSet(deviceList, DeviceImportModel::getCode);

            if(importCodeSet.size() != deviceList.size()){

                final JSONObject err = JSONUtil.createObj().set("msg", "文件中存在重复的设备编码");
                errorDetail.add(err);

                return JSONUtil.createObj()
                        .set("totalCount", deviceList.size())
                        .set("successCount", successCount)
                        .set("errorCount", deviceList.size())
                        .set("errorDetail", errorDetail);
            }

            final List<Device> allExistDevices = this.deviceService.list();
            final Set<String> dbCodeSet = CollStreamUtil.toSet(allExistDevices, Device::getCode);

            final List<JSONObject> ownerList = this.devDictApi.selectDictByCode("DEVICE_OWNER");
            final Map<String, String> ownerMap = CollStreamUtil.toMap(ownerList, o -> o.getStr("dictValue"), o -> o.getStr("dictLabel"));

            for (int i = 0; i < deviceList.size(); i++) {
                JSONObject jsonObject = this.doImport(dbCodeSet,ownerMap,deviceList.get(i), i);
                if(jsonObject.getBool("success")) {
                    successCount += 1;
                } else{
                    errorCount += 1;
                    errorDetail.add(jsonObject);
                }
            }
            return JSONUtil.createObj()
                    .set("totalCount", deviceList.size())
                    .set("successCount", successCount)
                    .set("errorCount", errorCount)
                    .set("errorDetail", errorDetail);
        } catch (Exception e) {
            log.error(">>>文件导入失败，原因{}", e);
            throw new CommonException("文件导入失败");
        }
    }


    public JSONObject doImport(Set<String> allExistDeviceCodes, Map<String, String> ownerMap, DeviceImportModel importModel, int i) {

        String code = importModel.getCode();
        String name = importModel.getName();
        String owner = importModel.getOwner();

        // 校验必填参数
        if(ObjectUtil.hasEmpty(code, name, owner)) {

            return JSONUtil.createObj().set("index", i + 1).set("success", false).set("msg", "设备名称、设备编码、设备属主 存在空值");

        }else if(allExistDeviceCodes.contains(code)){

            return JSONUtil.createObj().set("index", i + 1).set("success", false).set("msg", "设备编码已存在: ".concat(code));

        }else if(!ownerMap.values().contains(owner)){

            return JSONUtil.createObj().set("index", i + 1).set("success", false).set("msg", "【设备属主】字典中不存在: ".concat(owner));

        } else {
            try {

                Device device = new Device();

                // 字典翻译
                final String ownerValue = ownerMap.keySet().stream().filter(k -> owner.equals(ownerMap.get(k))).findFirst().get();
                importModel.setOwner(ownerValue);

                // 拷贝属性
                BeanUtil.copyProperties(importModel, device);

                this.deviceService.save(device);

                return JSONUtil.createObj().set("success", true);
            } catch (Exception e) {
                log.error(">>>数据导入异常，原因{}", e);
                return JSONUtil.createObj().set("success", false).set("index", i + 1).set("msg", "数据导入异常");
            }
        }
    }
}
