package com.genew.iot.core.constant;

import java.util.regex.Pattern;

/**
 * @author js
 * @version 1.0
 * @description: OPC常量类
 * @date 2022/11/21 17:34
 */
public class IotOpcUaConstant {
    /**
     * OPC线程池存活时间
     */
    public static final Integer OPC_THREAD_POOL_KEEP_ALIVE_TIME = 60;
    /**
     * OPC线程池队列容量
     */
    public static final Integer OPC_THREAD_POOL_BLOCKING_DEQUE_CAPACITY = 300;
    /**
     * OPC requestTimeout
     */
    public static final Integer OPC_REQUEST_TIMEOUT = 5000;
    /**
     * OPC服务器命名空间索引
     */
    public static final Integer OPC_SERVER_NAMESPACE_INDEX = 2;
    /**
     * OPC连接前缀
     */
    public static final String OPC_UA_END_POINT_PREFIX = "opc.tcp://";

    /**
     * NEGATIVE_ONE
     */
    public static final int NEGATIVE_ONE = -1;

    /**
     * ZERO
     */
    public static final int ZERO = 0;

    /**
     * ZERO_STRING
     */
    public static final String ZERO_STRING = "0";

    /**
     * requestedLifeTimeCount
     */
    public static final int REQUESTED_LIFE_TIME_COUNT = 2400;

    /**
     * requestedMaxKeepaliveCount
     */
    public static final int REQUESTED_MAX_KEEPALIVE_COUNT = 10;

    /**
     * maxNotificationsPerPublish
     */
    public static final int MAX_NOTIFICATIONS_PER_PUBLISH = 1;

    /**
     * 保留三位有效数字
     */
    public static final int RETAIN_THREE_SIGNIFICANT_DIGITS = 3;

    /**
     * 判断科学计数法
     */
    public static final Pattern VALUE_PATTERN = Pattern.compile("^[+-]?((\\d+\\.?\\d*)|(\\.\\d+))[Ee][+-]?\\d+$");

}
