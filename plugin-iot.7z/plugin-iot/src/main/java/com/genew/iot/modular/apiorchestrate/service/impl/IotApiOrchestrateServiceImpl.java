/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.apiorchestrate.service.impl;

import cn.dev33.satoken.exception.NotPermissionException;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.genew.common.exception.CommonException;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.core.param.IotThirdApiQueryParam;
import com.genew.iot.core.util.ScriptUtil;
import com.genew.iot.modular.apiorchestrate.entity.IotApiOrchestrate;
import com.genew.iot.modular.apiorchestrate.enums.IotApiOrchestrateReqEnum;
import com.genew.iot.modular.apiorchestrate.mapper.IotApiOrchestrateMapper;
import com.genew.iot.modular.apiorchestrate.param.*;
import com.genew.iot.modular.apiorchestrate.service.IotApiOrchestrateService;
import com.genew.iot.modular.thirdapi.enums.IotThirdApiExceptionEnum;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import com.genew.sys.api.SysRelationApi;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

/**
 * API编排Service接口实现类
 *
 * @author js
 * @date 2023/05/04 14:57
 **/
@Service
@Slf4j
public class IotApiOrchestrateServiceImpl extends ServiceImpl<IotApiOrchestrateMapper, IotApiOrchestrate> implements IotApiOrchestrateService {

    @Resource
    private IotThirdApiService iotThirdApiService;

    @Resource
    private ThreadPoolExecutor apiAsyncPool;

    @Resource
    private SysRelationApi sysRelationApi;

    @Override
    public Page<IotApiOrchestrate> page(IotApiOrchestratePageParam iotApiOrchestratePageParam) {
        QueryWrapper<IotApiOrchestrate> queryWrapper = new QueryWrapper<>();
        if (ObjectUtil.isNotEmpty(iotApiOrchestratePageParam.getName())) {
            queryWrapper.lambda().like(IotApiOrchestrate::getName, iotApiOrchestratePageParam.getName());
        }
        queryWrapper.lambda().select(IotApiOrchestrate::getId, IotApiOrchestrate::getApiPath,
                IotApiOrchestrate::getApiSign, IotApiOrchestrate::getName, IotApiOrchestrate::getRefApiId,
                IotApiOrchestrate::getSortCode, IotApiOrchestrate::getExecuteSort);
        queryWrapper.lambda().orderByDesc(IotApiOrchestrate::getUpdateTime, IotApiOrchestrate::getId,
                IotApiOrchestrate::getName,
                IotApiOrchestrate::getCreateTime);
        return this.page(CommonPageRequest.defaultPage(), queryWrapper);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(IotApiOrchestrateAddParam iotApiOrchestrateAddParam) {
        IotApiOrchestrate iotApiOrchestrate = BeanUtil.toBean(iotApiOrchestrateAddParam, IotApiOrchestrate.class);
        String encryptUrl = encryptApiSign(iotApiOrchestrate);
        iotApiOrchestrate.setApiSign(encryptUrl);
        this.save(iotApiOrchestrate);
    }

    private String encryptApiSign(IotApiOrchestrate iotApiOrchestrate) {
        String apiUrl = iotApiOrchestrate.getName().concat(iotApiOrchestrate.getApiPath());
        return SecureUtil.md5(apiUrl);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(IotApiOrchestrateEditParam iotApiOrchestrateEditParam) {
        IotApiOrchestrate iotApiOrchestrate = this.queryEntity(iotApiOrchestrateEditParam.getId());
        BeanUtil.copyProperties(iotApiOrchestrateEditParam, iotApiOrchestrate);
        iotApiOrchestrate.setApiSign(encryptApiSign(iotApiOrchestrate));
        this.updateById(iotApiOrchestrate);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<IotApiOrchestrateIdParam> iotApiOrchestrateIdParamList) {
        // 执行删除
        this.removeByIds(CollStreamUtil.toList(iotApiOrchestrateIdParamList, IotApiOrchestrateIdParam::getId));
    }

    @Override
    public IotApiOrchestrate detail(IotApiOrchestrateIdParam iotApiOrchestrateIdParam) {
        return this.queryEntity(iotApiOrchestrateIdParam.getId());
    }

    @Override
    public IotApiOrchestrate queryEntity(String id) {
        IotApiOrchestrate iotApiOrchestrate = this.getById(id);
        if (ObjectUtil.isEmpty(iotApiOrchestrate)) {
            log.warn("服务编排不存在，id值为：{}", id);
            throw new CommonException("服务编排不存在，id值为：{}", id);
        }
        return iotApiOrchestrate;
    }

    @Override
    public IotApiOrchestrate queryEntityByApiSign(String apiSign) {
        QueryWrapper<IotApiOrchestrate> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(IotApiOrchestrate::getApiSign, apiSign);
        IotApiOrchestrate iotApiOrchestrate = this.getOne(queryWrapper);
        if (ObjectUtil.isEmpty(iotApiOrchestrate)) {
            throw new CommonException("聚合接口不存在，apiSign值为：{}", apiSign);
        }
        return iotApiOrchestrate;
    }

    /**
     * 根据idParam查询聚合接口数据
     *
     * @param iotApiOrchestrateQueryParam
     * @return
     */
    @Override
    public Map<String, Object> queryThirdApiData(IotApiOrchestrateQueryParam iotApiOrchestrateQueryParam) {
        if (ObjectUtil.isEmpty(iotApiOrchestrateQueryParam.getApiSign())) {
            log.warn("聚合接口apiSign为空：{}", iotApiOrchestrateQueryParam);
            throw new CommonException("聚合接口apiSign为空:{}", iotApiOrchestrateQueryParam);
        }
        String executeSort;
        List<IotApiOrchestrateReqParam> reqParams;
        IotApiOrchestrate iotApiOrchestrate = this.queryEntityByApiSign(iotApiOrchestrateQueryParam.getApiSign());
        // 校验聚合接口权限
        boolean flag = sysRelationApi.checkPermissionListByTargetId(iotApiOrchestrate.getApiPath());
        if (!flag) {
            throw new NotPermissionException(IotThirdApiExceptionEnum.CONFIG_REQUEST_NOT_PERMISSION.getCode().toString(),
                    "admin");
        }
        //支持动态传参，如果传递动态参数，以传参为准，未传，按编排接口默认配置
        if (ObjectUtil.isEmpty(iotApiOrchestrateQueryParam.getReqParam()) || ObjectUtil.isEmpty(iotApiOrchestrateQueryParam.getExecuteSort())) {
            reqParams = JSONUtil.toList(iotApiOrchestrate.getReqParam(), IotApiOrchestrateReqParam.class);
            executeSort = iotApiOrchestrate.getExecuteSort();
        } else {
            reqParams = iotApiOrchestrateQueryParam.getReqParam();
            executeSort = iotApiOrchestrateQueryParam.getExecuteSort();
        }
        if (ObjectUtil.isEmpty(reqParams)) {
            log.warn("聚合接口不存在：{}", iotApiOrchestrateQueryParam);
            throw new CommonException("聚合接口不存在:{}", iotApiOrchestrateQueryParam);
        }
        List<String> apiIds = Lists.newArrayList();
        reqParams.forEach(reqParam -> {
            apiIds.add(reqParam.getApiParam().getApiSign());
        });
        // reqParams按接口标识id排序
        reqParams =
                reqParams.stream().sorted(Comparator.comparing(x -> x.getApiParam().getApiSign())).collect(Collectors.toList());
        // iotThirdApiList按接口标识id排序返回结果
        List<IotThirdApi> iotThirdApiList = iotThirdApiService.queryEntityByApiSigns(apiIds);
        if (ObjectUtil.isEmpty(iotThirdApiList)) {
            log.warn("查询接口管理列表数据为空：{}", apiIds);
            throw new CommonException("查询接口管理列表数据为空:{}", iotApiOrchestrateQueryParam);
        }
        if (Boolean.toString(Boolean.FALSE).equals(executeSort)) {
            // 顺序执行编排API
            IotApiOrchestrateTreeParam currentParam = getIotApiOrchestrateTreeParam(reqParams, iotThirdApiList);
            return queryApiDataByTreeParam(currentParam);
        } else if (Boolean.toString(Boolean.TRUE).equals(executeSort)) {
            // 并发执行编排API
            List<IotApiOrchestrateListParam> listParamList = getIotApiOrchestrateListParam(reqParams, iotThirdApiList);
            return queryApiDataByListParam(listParamList);
        }
        return new HashMap<>();
    }

    /**
     * 顺序执行编排API（递归）
     *
     * @param apiOrchestrateTreeParam
     * @return
     */
    private Map<String, Object> queryApiDataByTreeParam(IotApiOrchestrateTreeParam apiOrchestrateTreeParam) {
        Map<String, Object> resultMap = Maps.newHashMap();
        log.debug("顺序执行编排API请求入参:{}", apiOrchestrateTreeParam);
        Map<String, Object> map = iotThirdApiService.queryThirdApiData(apiOrchestrateTreeParam.getCurrentApi());
        String jsonObject = String.valueOf(map.get("data"));
        if (StringUtils.isBlank(jsonObject)) {
            log.error("查询接口返回数据为空:{}", map);
            throw new CommonException("查询接口返回数据为空:{}", map);
        }
        if (ObjectUtil.isNotEmpty(apiOrchestrateTreeParam.getResponseScript())) {
            Object jsonParam =
                    ScriptUtil.executeJsScripts(apiOrchestrateTreeParam.getResponseScript(), jsonObject).as(Object.class);
            IotThirdApiQueryParam thirdApiQueryParam = convertScriptDataToQueryParam(jsonParam, apiOrchestrateTreeParam);
            if (ObjectUtil.isNotEmpty(thirdApiQueryParam)) {
                IotApiOrchestrateTreeParam nextTreeParam = new IotApiOrchestrateTreeParam();
                nextTreeParam.setCurrentApi(thirdApiQueryParam);
                nextTreeParam.setResponseScript(apiOrchestrateTreeParam.getNextApi().getResponseScript());
                return queryApiDataByTreeParam(nextTreeParam);
            }
        }
        if (ObjectUtil.isNotEmpty(jsonObject)) {
            resultMap.put("code", 200);
            resultMap.put("message", "查询聚合接口成功！");
            resultMap.put("data", JSONUtil.parse(jsonObject));
        } else {
            resultMap.put("code", 500);
            resultMap.put("message", "查询聚合接口失败！");
            resultMap.put("data", null);
        }
        log.debug("聚合接口返回结果:{}", resultMap);
        return resultMap;
    }

    /**
     * 并发执行编排API（CompletableFuture）
     *
     * @param listParamList
     * @return
     */
    private Map<String, Object> queryApiDataByListParam(List<IotApiOrchestrateListParam> listParamList) {
        log.debug("并发执行编排API请求入参:{}", listParamList);
        List<CompletableFuture<Object>> futures = new ArrayList<>();
        for (int i = 0; i < listParamList.size(); i++) {
            int finalI = i;
            CompletableFuture<Object> future = CompletableFuture.supplyAsync(() -> {
                //任务
                Map<String, Object> resultMap =
                        iotThirdApiService.queryThirdApiData(listParamList.get(finalI).getCurrentApi());
                String jsonObject = String.valueOf(resultMap.get("data"));
                if (StringUtils.isBlank(jsonObject)) {
                    log.error("查询接口返回数据为空：{}", resultMap);
                    throw new CommonException("查询接口返回数据为空:{}", resultMap);
                }
                if (ObjectUtil.isNotEmpty(listParamList.get(finalI).getResponseScript())) {
                    return ScriptUtil.executeJsScripts(listParamList.get(finalI).getResponseScript(), jsonObject).as(Object.class);
                }
                return JSONUtil.toBean(jsonObject, Object.class);
            }, apiAsyncPool);
            futures.add(future);
        }
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()])).join();
        List<Object> mapList = Lists.newArrayList();
        // 使用allOf方法来表示所有的并行任务
        for (CompletableFuture<Object> future : futures) {
            Object result = future.join();
            mapList.add(result);
        }
        Map<String, Object> resultMap = Maps.newHashMap();
        if (ObjectUtil.isNotEmpty(mapList)) {
            resultMap.put("code", 200);
            resultMap.put("message", "查询聚合接口成功！");
            resultMap.put("data", mapList);
        } else {
            resultMap.put("code", 200);
            resultMap.put("message", "查询聚合接口失败！");
            resultMap.put("data", null);
        }
        log.debug("聚合接口返回结果:{}", resultMap);
        return resultMap;
    }

    /**
     * 组装并发编排接口查询参数
     *
     * @param reqParams
     * @param iotThirdApiList
     * @return
     */
    private List<IotApiOrchestrateListParam> getIotApiOrchestrateListParam(List<IotApiOrchestrateReqParam> reqParams, List<IotThirdApi> iotThirdApiList) {
        List<IotApiOrchestrateListParam> list = Lists.newArrayList();
        for (int i = 0; i < reqParams.size(); i++) {
            IotApiOrchestrateListParam orchestrateListParam = new IotApiOrchestrateListParam();
            orchestrateListParam.setCurrentApi(convertToCurrentApi(iotThirdApiList.get(i), reqParams.get(i)));
            orchestrateListParam.setResponseScript(reqParams.get(i).getApiScript());
            list.add(orchestrateListParam);
        }
        return list;
    }

    /**
     * 组装顺序编排接口查询参数
     *
     * @param reqParams
     * @param iotThirdApiList
     * @return
     */
    @NotNull
    private IotApiOrchestrateTreeParam getIotApiOrchestrateTreeParam(List<IotApiOrchestrateReqParam> reqParams, List<IotThirdApi> iotThirdApiList) {
        IotApiOrchestrateTreeParam currentParam = new IotApiOrchestrateTreeParam();
        for (int i = 0; i < reqParams.size(); i++) {
            IotApiOrchestrateTreeParam nextParam = new IotApiOrchestrateTreeParam();
            if (iotThirdApiList.get(i).getApiSign().equals(reqParams.get(i).getApiParam().getApiSign())) {
                currentParam.setCurrentApi(convertToCurrentApi(iotThirdApiList.get(i), reqParams.get(i)));
                if (i == reqParams.size() - 1) {
                    break;
                }
                currentParam.setResponseScript(reqParams.get(i).getApiScript());
                nextParam.setCurrentApi(convertToCurrentApi(iotThirdApiList.get(i + 1), reqParams.get(i + 1)));
                nextParam.setResponseScript(reqParams.get(i + 1).getApiScript());
                currentParam.setNextApi(nextParam);
                break;
            }
        }
        return currentParam;
    }

    /**
     * convert 接口编排请求参数 to 接口查询参数
     *
     * @param thirdApi
     * @param param
     * @return
     */
    private IotThirdApiQueryParam convertToCurrentApi(IotThirdApi thirdApi, IotApiOrchestrateReqParam param) {
        IotThirdApiQueryParam apiQueryParam = new IotThirdApiQueryParam();
        if (ObjectUtil.isNotEmpty(param.getApiParam())) {
            // 如果接口编排填写入参，直接使用
            apiQueryParam = param.getApiParam();
        } else {
            apiQueryParam.setApiSign(thirdApi.getApiSign());
            // 如果接口编排未填写入参，默认接口管理配置参数
            if (ObjectUtil.isNotEmpty(thirdApi.getAuthParam())) {
                apiQueryParam.setAuthParam(JSONUtil.parseObj(thirdApi.getAuthParam()));
            }
            if (ObjectUtil.isNotEmpty(thirdApi.getPathParam())) {
                apiQueryParam.setPathParam(JSONUtil.parseObj(thirdApi.getPathParam()));
            }
            if (ObjectUtil.isNotEmpty(thirdApi.getBodyParam())) {
                apiQueryParam.setBodyParam(JSONUtil.parseObj(thirdApi.getBodyParam()));
            }
            if (ObjectUtil.isNotEmpty(thirdApi.getHeaderParam())) {
                apiQueryParam.setHeaderParam(JSONUtil.parseObj(thirdApi.getHeaderParam()));
            }
            if (ObjectUtil.isNotEmpty(thirdApi.getQueryParam())) {
                apiQueryParam.setQueryParam(JSONUtil.parseObj(thirdApi.getQueryParam()));
            }
        }
        return apiQueryParam;
    }

    /**
     * convert 脚本返回结果 TO 接口查询参数
     *
     * @param jsonParam
     * @param apiOrchestrateTreeParam
     * @return
     */
    private IotThirdApiQueryParam convertScriptDataToQueryParam(Object jsonParam,
                                                                IotApiOrchestrateTreeParam apiOrchestrateTreeParam) {
        IotThirdApiQueryParam iotThirdApiQueryParam = new IotThirdApiQueryParam();
        iotThirdApiQueryParam.setApiSign(apiOrchestrateTreeParam.getNextApi().getCurrentApi().getApiSign());
        JSONObject jsonObject = JSONUtil.parseObj(jsonParam);
        Set<String> list = jsonObject.keySet();
        if (ObjectUtil.isNotEmpty(list)) {
            if (list.contains(IotApiOrchestrateReqEnum.PATH_PARAM.getValue())) {
                JSONArray jsonArray = JSONUtil.parseArray(jsonObject.get("pathParam"));
                iotThirdApiQueryParam.setPathParam(jsonArrayToMapByJSONObject(jsonArray));
            }
            if (list.contains(IotApiOrchestrateReqEnum.AUTH_PARAM.getValue())) {
                iotThirdApiQueryParam.setAuthParam((Map<String, Object>) jsonObject.get("authParam"));
            }
            if (list.contains(IotApiOrchestrateReqEnum.HEAD_PARAM.getValue())) {
                JSONArray jsonArray = JSONUtil.parseArray(jsonObject.get("headParam"));
                iotThirdApiQueryParam.setHeaderParam(jsonArrayToMapByJSONObject(jsonArray));
            }
            if (list.contains(IotApiOrchestrateReqEnum.QUERY_PARAM.getValue())) {
                JSONArray jsonArray = JSONUtil.parseArray(jsonObject.get("queryParam"));
                iotThirdApiQueryParam.setQueryParam(jsonArrayToMapByJSONObject(jsonArray));
            }
            if (list.contains(IotApiOrchestrateReqEnum.BODY_PARAM.getValue())) {
                iotThirdApiQueryParam.setBodyParam((Map<String, Object>) jsonObject.get("bodyParam"));
            }
        }
        return iotThirdApiQueryParam;
    }

    public Map<String, Object> jsonArrayToMapByJSONObject(JSONArray jsonArray) {
        Map<String, Object> map = new HashMap<>(16);
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            for (String key : jsonObject.keySet()) {
                map.put(key, jsonObject.get(key));
            }
        }
        return map;
    }
}
