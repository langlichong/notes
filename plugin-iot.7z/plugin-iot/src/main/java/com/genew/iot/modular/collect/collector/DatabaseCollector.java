package com.genew.iot.modular.collect.collector;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.dbs.api.DataSourceApi;
import com.genew.dbs.core.entity.DsSource;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.modular.collect.core.*;
import com.genew.iot.modular.metric.dto.protocol.DatabaseProtocolConf;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Nullable;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.Map;
import java.util.StringJoiner;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 数据库直连查询
 */
@Slf4j
@Component
public class DatabaseCollector extends AbstractCollector<JSONObject, String> {

    @Resource
    private DataSourceApi dataSourceApi;

    private static ConcurrentHashMap<String, DataSource> dsCache = new ConcurrentHashMap<>();

    @Override
    @ExceptionLog(value = "数据库直连", type = LogTypes.collectData)
    protected CollectResponse<JSONObject, String> collectData() throws DataIntegrationException {

        final CollectRequest request = CollectContext.getRequest();
        final DatabaseProtocolConf protocolConf = request.getDatabaseProtocolConf();

        final JSONObject valueObject = JSONUtil.createObj()
                .set("ts", System.currentTimeMillis() + "")
                .set("unit", request.getDataUnit());

        //推送格式： {"指标名称": "指标值对象"}
        final JSONObject dataPoint = JSONUtil.createObj()
                .set(request.getName(), valueObject);

        final DsSource ds = dataSourceApi.getDbConfigById(protocolConf.getDataSource());
        final DataSource cachedDs = getDataSource(ds);

        final String sqlContent = protocolConf.getSqlContent();

        final JdbcTemplate jdbcTemplate = new JdbcTemplate(cachedDs);

        final Map<String, Object> results = jdbcTemplate.queryForMap(sqlContent);

        final String metricValue = JSONUtil.toJsonStr(results);

        valueObject.set("value", metricValue);

        final CollectResponse response = CollectResponse.builder()
                .originRequest(request)
                .collectResult(dataPoint)
                .collectResultType(ProcessResultType.JSON)
                .build();

        return response;
    }

    @Nullable
    private static DataSource getDataSource(DsSource ds) throws DataIntegrationException {
        final String dbDriver = ds.getDsDriver();
        final String dbUrl = ds.getDsUrl();
        final String dbUser = ds.getDsUser();
        final String dbPwd = ds.getDsPwd();

        StringJoiner sj = new StringJoiner("@");
        sj.add(dbDriver).add(dbUrl).add(dbUser).add(dbPwd);
        DataSource cachedDs = dsCache.get(sj.toString());
        try {
            if (cachedDs == null) {
                cachedDs = DataSourceBuilder.create()
                        .driverClassName(ds.getDsDriver())
                        .url(ds.getDsUrl())
                        .username(ds.getDsUser())
                        .password(ds.getDsPwd())
                        .build();
                dsCache.put(sj.toString(), cachedDs);
            }
        } catch (Exception e) {
            throw new DataIntegrationException("数据库直连采集异常", e);
        }

        return cachedDs;
    }


    @Override
    protected boolean support(CollectRequest request) {

        if (request.getProtocol().equalsIgnoreCase(CollectTypes.DATABASE_QUERY.name())) {
            return true;
        }
        return false;
    }

}
