/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.sensor.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.genew.iot.modular.sensor.entity.Sensor;
import com.genew.iot.modular.sensor.param.SensorAddParam;
import com.genew.iot.modular.sensor.param.SensorEditParam;
import com.genew.iot.modular.sensor.param.SensorIdParam;
import com.genew.iot.modular.sensor.param.SensorPageParam;

import java.util.List;

/**
 * 传感器Service接口
 *
 * @author huhu
 * @date  2023/04/11 14:57
 **/
public interface SensorService extends IService<Sensor> {

    /**
     * 获取传感器分页
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    Page<Sensor> page(SensorPageParam sensorPageParam);

    /**
     * 添加传感器
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    void add(SensorAddParam sensorAddParam);

    /**
     * 编辑传感器
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    void edit(SensorEditParam sensorEditParam);

    /**
     * 删除传感器
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    void delete(List<SensorIdParam> sensorIdParamList);

    /**
     * 获取传感器详情
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    Sensor detail(SensorIdParam sensorIdParam);

    /**
     * 获取传感器详情
     *
     * @author huhu
     * @date  2023/04/11 14:57
     **/
    Sensor queryEntity(String id);
}
