/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.productmetric.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.genew.iot.modular.productmetric.entity.ProductMetric;
import com.genew.iot.modular.productmetric.param.ProductMetricAddParam;
import com.genew.iot.modular.productmetric.param.ProductMetricEditParam;
import com.genew.iot.modular.productmetric.param.ProductMetricIdParam;
import com.genew.iot.modular.productmetric.param.ProductMetricPageParam;

import java.util.List;

/**
 * 产品指标Service接口
 *
 * @author huhu
 * @date  2023/07/03 15:08
 **/
public interface ProductMetricService extends IService<ProductMetric> {

    /**
     * 获取产品指标分页
     *
     * @author huhu
     * @date  2023/07/03 15:08
     */
    Page<ProductMetric> page(ProductMetricPageParam productMetricPageParam);

    /**
     * 添加产品指标
     *
     * @author huhu
     * @date  2023/07/03 15:08
     */
    void add(ProductMetricAddParam productMetricAddParam);

    /**
     * 编辑产品指标
     *
     * @author huhu
     * @date  2023/07/03 15:08
     */
    void edit(ProductMetricEditParam productMetricEditParam);

    /**
     * 删除产品指标
     *
     * @author huhu
     * @date  2023/07/03 15:08
     */
    void delete(List<ProductMetricIdParam> productMetricIdParamList);

    /**
     * 获取产品指标详情
     *
     * @author huhu
     * @date  2023/07/03 15:08
     */
    ProductMetric detail(ProductMetricIdParam productMetricIdParam);

    /**
     * 获取产品指标详情
     *
     * @author huhu
     * @date  2023/07/03 15:08
     **/
    ProductMetric queryEntity(String id);
}
