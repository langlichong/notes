package com.genew.iot.modular.collect.controller;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.iot.modular.collect.core.AbstractCollectResponseProcessor;
import com.genew.iot.modular.collect.service.CollecttingService;
import com.genew.iot.modular.metric.param.MetricIdParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Api(tags = "指标采集控制器")
@ApiSupport(author = "genew", order = 1)
@RestController
public class CollecttingController {

    @Resource
    private CollecttingService collecttingService;

    @Resource
    private ApplicationContext applicationContext;

    @ApiOperationSupport(order = 1)
    @ApiOperation("启动或停止采集（单个指标）")
    @CommonLog("启动或停止采集（单个指标）")
    @PostMapping("/iot/metric/start-stop")
    public CommonResult<String> stopOrStartCollectting(@RequestBody MetricIdParam param) {

        collecttingService.stopOrStartCollecttingOnSingle(param);

        return CommonResult.ok();

    }

    @ApiOperationSupport(order = 2)
    @ApiOperation("批量启动采集")
    @CommonLog("批量启动采集")
    @PostMapping("/iot/metric/batch-start")
    public CommonResult<String> startBatchCollectting(@RequestBody List<String> ids) {

        collecttingService.startBatchCollectting(ids);

        return CommonResult.ok();

    }

    @ApiOperationSupport(order = 3)
    @ApiOperation("批量停止采集")
    @CommonLog("批量停止采集")
    @PostMapping("/iot/metric/batch-stop")
    public CommonResult<String> stopBatchCollectting(@RequestBody List<String> ids) {

        collecttingService.stopBatchCollectting(ids);

        return CommonResult.ok();

    }

    @ApiOperationSupport(order = 4)
    @ApiOperation("获取系统中所有采集结果处理器")
    @GetMapping("/iot/metric/processors")
    public CommonResult<Object> getSysMetricProcessors() {

        List<JSONObject> processorList = new ArrayList<>();
        final Map<String, AbstractCollectResponseProcessor> processors = applicationContext.getBeansOfType(AbstractCollectResponseProcessor.class);

        processors.forEach((k,v) -> {
            final JSONObject processor = JSONUtil.createObj().set("id", v.id()).set("name", v.name());
            processorList.add(processor);
        });

        return CommonResult.data(processorList);

    }
}
