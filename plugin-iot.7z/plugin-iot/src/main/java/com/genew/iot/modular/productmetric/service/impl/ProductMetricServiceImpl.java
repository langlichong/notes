/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.productmetric.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.genew.common.enums.CommonSortOrderEnum;
import com.genew.common.exception.CommonException;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.modular.productmetric.entity.ProductMetric;
import com.genew.iot.modular.productmetric.mapper.ProductMetricMapper;
import com.genew.iot.modular.productmetric.param.ProductMetricAddParam;
import com.genew.iot.modular.productmetric.param.ProductMetricEditParam;
import com.genew.iot.modular.productmetric.param.ProductMetricIdParam;
import com.genew.iot.modular.productmetric.param.ProductMetricPageParam;
import com.genew.iot.modular.productmetric.service.ProductMetricService;

import java.util.List;

/**
 * 产品指标Service接口实现类
 *
 * @author huhu
 * @date  2023/07/03 15:08
 **/
@Service
public class ProductMetricServiceImpl extends ServiceImpl<ProductMetricMapper, ProductMetric> implements ProductMetricService {

    @Override
    public Page<ProductMetric> page(ProductMetricPageParam productMetricPageParam) {
        QueryWrapper<ProductMetric> queryWrapper = new QueryWrapper<>();
        if(ObjectUtil.isNotEmpty(productMetricPageParam.getProductId())) {
            queryWrapper.lambda().eq(ProductMetric::getProductId, productMetricPageParam.getProductId());
        }
        if(ObjectUtil.isNotEmpty(productMetricPageParam.getMetricId())) {
            queryWrapper.lambda().eq(ProductMetric::getMetricId, productMetricPageParam.getMetricId());
        }
        if(ObjectUtil.isAllNotEmpty(productMetricPageParam.getSortField(), productMetricPageParam.getSortOrder())) {
            CommonSortOrderEnum.validate(productMetricPageParam.getSortOrder());
            queryWrapper.orderBy(true, productMetricPageParam.getSortOrder().equals(CommonSortOrderEnum.ASC.getValue()),
                    StrUtil.toUnderlineCase(productMetricPageParam.getSortField()));
        } else {
            queryWrapper.lambda().orderByAsc(ProductMetric::getId);
        }
        return this.page(CommonPageRequest.defaultPage(), queryWrapper);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(ProductMetricAddParam productMetricAddParam) {
        ProductMetric productMetric = BeanUtil.toBean(productMetricAddParam, ProductMetric.class);
        this.save(productMetric);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(ProductMetricEditParam productMetricEditParam) {
        ProductMetric productMetric = this.queryEntity(productMetricEditParam.getId());
        BeanUtil.copyProperties(productMetricEditParam, productMetric);
        this.updateById(productMetric);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<ProductMetricIdParam> productMetricIdParamList) {
        // 执行删除
        this.removeByIds(CollStreamUtil.toList(productMetricIdParamList, ProductMetricIdParam::getId));
    }

    @Override
    public ProductMetric detail(ProductMetricIdParam productMetricIdParam) {
        return this.queryEntity(productMetricIdParam.getId());
    }

    @Override
    public ProductMetric queryEntity(String id) {
        ProductMetric productMetric = this.getById(id);
        if(ObjectUtil.isEmpty(productMetric)) {
            throw new CommonException("产品指标不存在，id值为：{}", id);
        }
        return productMetric;
    }
}
