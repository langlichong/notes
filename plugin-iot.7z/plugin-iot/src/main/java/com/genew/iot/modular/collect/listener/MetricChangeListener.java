package com.genew.iot.modular.collect.listener;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.genew.common.listener.CommonDataChangeListener;
import com.genew.iot.core.enums.IotDataTypeEnum;
import com.genew.iot.modular.collect.core.CollectManager;
import com.genew.iot.modular.collect.core.CollectRequest;
import com.genew.iot.modular.collect.core.TaskId;
import com.genew.iot.modular.device.entity.Device;
import com.genew.iot.modular.device.service.DeviceService;
import com.genew.iot.modular.sensor.service.SensorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class MetricChangeListener implements CommonDataChangeListener {

    @Resource
    private CollectManager collectManager;

    @Resource
    private SensorService sensorService;

    @Resource
    private DeviceService deviceService;

    @Override
    public void doAddWithDataList(String dataType, JSONArray jsonArray) {
        if(dataType.equals(IotDataTypeEnum.MEASUREMENT.getValue())) {
            // todo 装配数据采集任务
            final CollectRequest request = buildDataCollectRequest(jsonArray);
            collectManager.submitCollectingRequest(request);
        }
    }

    @Override
    public void doUpdateWithDataList(String dataType, JSONArray jsonArray) {
        if(dataType.equals(IotDataTypeEnum.MEASUREMENT.getValue())) {
            //todo 更新时候，需要移除已经在运行的版本
            final CollectRequest collectRequest = buildDataCollectRequest(jsonArray);
            collectManager.cancelTask(TaskId.fromString(collectRequest.getId()));

            collectManager.submitCollectingRequest(collectRequest);
        }
    }

    @Override
    public void doDeleteWithDataIdList(String dataType, List<String> dataIdList) {
        if(dataType.equals(IotDataTypeEnum.MEASUREMENT.getValue())) {
            for (String id : dataIdList) {
                collectManager.cancelTask(TaskId.fromString(id));
            }
        }
    }

    @Override
    public void doAddWithDataIdList(String dataType, List<String> dataIdList) {

    }

    @Override
    public void doUpdateWithDataIdList(String dataType, List<String> dataIdList) {

    }

    private CollectRequest buildDataCollectRequest(JSONArray jsonArray) {

        final ListIterator<Object> iterator = jsonArray.listIterator();
        final Object next = iterator.next();
        JSONObject json = (JSONObject) next;
        final CollectRequest request = BeanUtil.toBean(json, CollectRequest.class);

        final String ownerType = request.getOwnerType();
        if("PRODUCT".equalsIgnoreCase(ownerType)){
            final List<Device> devices = deviceService.list(Wrappers.lambdaQuery(Device.class).isNotNull(Device::getProduct));
            final Set<String> tbIds = devices.stream().map(Device::getTbDevId).collect(Collectors.toSet());
            request.setPushTargetDevIds(new ArrayList<>(tbIds));
        }else if("DEVICE".equalsIgnoreCase(ownerType)){
            final String tbDevId = deviceService.getById(request.getOwnerId()).getTbDevId();
            request.setPushTargetDevIds(Arrays.asList(tbDevId));
        }

        return request;
    }
}
