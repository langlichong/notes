package com.genew.iot.modular.collect.core;

import com.genew.iot.modular.collect.processors.EmptyProcessor;
import com.genew.iot.modular.collect.processors.Push2TbProcessor;
import com.genew.iot.modular.collect.processors.ScriptProcessor;
import com.genew.iot.modular.collect.processors.SsePusherProcessor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;

/**
 * 指标响应处理器链 构建器
 */
@Data
@Slf4j
@Component
public class CollectResponseProcessorChainBuilder {

    @Resource
    private Map<String, AbstractCollectResponseProcessor> processorMap;

    @Resource
    private ApplicationContext applicationContext;

    /**
     * 根据指标构建该指标的值处理器
     * @param request: 当一个指标未明确配置采集结果处理器时，该参数应该传递为 null
     * @return
     */
    public AbstractCollectResponseProcessor buildProcessorChainByMetric(CollectRequest request){

        initProcessorMap();

        String udfProcessors = request.getResponseProcessors();
        if(StringUtils.isBlank(udfProcessors)){
            udfProcessors = "";
        }
        AbstractCollectResponseProcessor processorChain = new EmptyProcessor();

        if(StringUtils.isNotBlank(udfProcessors)){

            AbstractCollectResponseProcessor lastOne = processorChain;
            final String[] processors = udfProcessors.split(",");
            for (String responseProcessorId : processors) {
                final AbstractCollectResponseProcessor processor = processorMap.get(responseProcessorId);
                if(processor == null){
                    log.warn("系统内已注册的所有指标处理器: {}",processorMap.keySet());
                    log.error("无法找到指标【{}】配置的响应处理器 【{}】, 当前指标处理器链构建失败",request.getName(),responseProcessorId);
                    throw new RuntimeException("指标【"+ request.getName() +" 】：采集结果处理器链构建失败");
                }
                lastOne.setNextProcessor(processor);
                lastOne = processor;
            }
        }

        return processorChain;
    }

    private AbstractCollectResponseProcessor getLast(AbstractCollectResponseProcessor chain){

        if(chain == null){
            return null;
        }
        if(chain.nextProcessor == null) {
            return chain;
        }
        return getLast(chain.nextProcessor);
    }


    private AbstractCollectResponseProcessor getDefaultProcessorChain(){

        // 默认行为链： 先脚本处理，然后推送TB ，接着推送前端 , 再接着执行其他用户选择的处理器
        final ScriptProcessor firstProcessor = new ScriptProcessor();
        final Push2TbProcessor push2TbProcessor = new Push2TbProcessor();
        final SsePusherProcessor ssePusherProcessor = new SsePusherProcessor();

        AbstractCollectResponseProcessor processorChain = firstProcessor;
        processorChain.setNextProcessor(push2TbProcessor);
        push2TbProcessor.setNextProcessor(ssePusherProcessor);

        return processorChain;
    }

    private void initProcessorMap() {

        if(processorMap == null){
            final Map<String, AbstractCollectResponseProcessor> processorsMap = applicationContext.getBeansOfType(AbstractCollectResponseProcessor.class);
            this.processorMap = processorMap;
        }
    }
}
