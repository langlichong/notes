/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.metric.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.dromara.core.trans.vo.TransPojo;

import java.util.Date;

/**
 * 指标/点位
 *
 * @author huhu
 * @date  2023/04/12 15:27
 **/
@Getter
@Setter
@TableName(value = "iot_metric",autoResultMap = true)
public class Metric implements TransPojo {

    /** 主键 */
    @TableId
    @ApiModelProperty(value = "主键", position = 1)
    private String id;

    /** 指标名称 */
    @ApiModelProperty(value = "指标名称", position = 2)
    private String name;

    /** 属主类型: 指标会绑定到产品或者设备 */
    @ApiModelProperty(value = "属主类型", position = 3)
    private String ownerType = "DEVICE";

    /** 属主ID */
    @ApiModelProperty(value = "属主标识", position = 3)
    private String ownerId;

    /** 数据类型 */
    @ApiModelProperty(value = "数据类型", position = 5)
    private String dataType;

    /** 数据单位 */
    @ApiModelProperty(value = "数据单位", position = 6)
    private String dataUnit;

    /** 采集协议 */
    @ApiModelProperty(value = "协议", position = 7)
    private String protocol;

    /** 采集时间间隔(秒) */
    @ApiModelProperty(value = "采集时间间隔(秒)", position = 13)
    private Long intervalTime;

    /**
     *  是否在配置好后立即开始采集
     *  1：立即启动
     *  0：人工控制开始采集
     * */
    @ApiModelProperty(value = "是否自动启动采集", position = 14)
    private String autoStart;

    /**
     * 采集状态：标识指标任务是否已经在运行
     * running: （正在）采集
     * stopped: 停止
     * */
    @ApiModelProperty(value = "采集状态", position = 17)
    private String collectStatus;

    @ApiModelProperty(value = "推送前数据处理脚本", position = 18)
    private String beforeScripts;

    @ApiModelProperty(value = "扩展信息", position = 21)
    private String extJson;

    @ApiModelProperty(value = "协议配置", position = 21)
    private String protocolConf;

    @ApiModelProperty(value = "脚本返回值", position = 21)
    private String scriptRtType;

    @ApiModelProperty(value = "采集结果处理器", position = 22)
    private String responseProcessors;

    /** 传感器名称 */
    @TableField(exist = false)
    @ApiModelProperty(value = "属主名称", position = 24)
    private String ownerName;

    /** CREATE_TIME */
    @ApiModelProperty(value = "CREATE_TIME", position = 25)
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /** CREATE_USER */
    @ApiModelProperty(value = "CREATE_USER", position = 26)
    @TableField(fill = FieldFill.INSERT)
    private String createUser;

    /** UPDATE_TIME */
    @ApiModelProperty(value = "UPDATE_TIME", position = 27)
    @TableField(fill = FieldFill.UPDATE)
    private Date updateTime;

    /** UPDATE_USER */
    @ApiModelProperty(value = "UPDATE_USER", position = 28)
    @TableField(fill = FieldFill.UPDATE)
    private String updateUser;
}
