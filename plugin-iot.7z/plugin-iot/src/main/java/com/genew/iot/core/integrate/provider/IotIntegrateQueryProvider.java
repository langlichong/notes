/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.core.integrate.provider;

import cn.hutool.core.util.ObjectUtil;
import com.genew.iot.api.IotIntegrateQueryApi;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.core.integrate.enums.IotApiIntegrateEnum;
import com.genew.iot.modular.apiorchestrate.entity.IotApiOrchestrate;
import com.genew.iot.modular.apiorchestrate.service.IotApiOrchestrateService;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 接口管理API接口提供者
 *
 * @author js
 * @date 2023/03/28 10:09
 **/
@Service
@Slf4j
public class IotIntegrateQueryProvider implements IotIntegrateQueryApi {


    @Resource
    private IotThirdApiService iotThirdApiService;

    @Resource
    private IotApiOrchestrateService iotApiOrchestrateService;

    @Override
    public List<Map<String, Object>> queryAllApiList() {
        List<Map<String, Object>> list = Lists.newArrayList();
        List<IotThirdApi> iotThirdApis = iotThirdApiService.list();
        Collections.sort(iotThirdApis, Comparator.comparing(IotThirdApi::getCreateTime));
        List<IotApiOrchestrate> apiOrchestrates = iotApiOrchestrateService.list();
        Collections.sort(apiOrchestrates, Comparator.comparing(IotApiOrchestrate::getCreateTime));
        if (ObjectUtil.isNotEmpty(iotThirdApis)) {
            list.addAll(iotThirdApis.stream().map(iotThirdApi -> {
                Map<String, Object> resultMap = Maps.newHashMap();
                resultMap.put("apiName", iotThirdApi.getApiAlias());
                resultMap.put("apiSign", iotThirdApi.getApiSign());
                resultMap.put("apiPath", iotThirdApi.getApiPath());
                resultMap.put("apiType", IotApiIntegrateEnum.THIRD_API.getValue());
                return resultMap;
            }).collect(Collectors.toList()));
        }
        if (ObjectUtil.isNotEmpty(iotThirdApis)) {
            list.addAll(apiOrchestrates.stream().map(iotApiOrchestrate -> {
                Map<String, Object> resultMap = Maps.newHashMap();
                resultMap.put("apiName", iotApiOrchestrate.getName());
                resultMap.put("apiSign", iotApiOrchestrate.getApiSign());
                resultMap.put("apiPath", iotApiOrchestrate.getApiPath());
                resultMap.put("apiType", IotApiIntegrateEnum.ORCHESTRATE_API.getValue());
                return resultMap;
            }).collect(Collectors.toList()));
        }
        return list;
    }
}
