package com.genew.iot.modular.collect.customized.dy485;

import com.genew.iot.core.util.TcpUtil;
import lombok.Data;


/**
 * @author : renqiang
 * @date : 2022-12-14 18:00
 * @description : 数据 返回数据
 */
@Data
public class BmsDataBody {

    /**
     * 系统状态
     * 0：初始化
     * 1：放电
     * 2：预充
     * 3：恒流
     * 4：充满
     * 5：涓流
     * 6：维护
     * 7：故障
     */
    private byte[] status1 = new byte[2];

    /**
     * 保护状态
     * 位0:过充电压
     * 位1:过放电压
     * 位2:充电过流
     * 位3:放电过流
     * 位4:输出短路
     * 位5:电池组温度报警
     * 位6:环境温度(预留)
     * 位7:低电量警告
     */
    private byte[] status2 = new byte[2];

    /**
     * 保护失效状态故障报警(失效报警)
     * 位0:过充电压保护失效
     * 位1:过放电压保护失效
     * 位2:充电过流保护失效
     * 位3:放电过流保护失效
     * 位4:输出短路保护失效
     * 位5:电池组温度报警
     * 位6:环境温度故障报警
     * 位7:采集信号失效故障
     */
    private byte[] status3 = new byte[2];

    /**
     * 放电电流
     */
    private byte[] ia = new byte[2];

    /**
     * 端口电压(充电输入)
     */
    private byte[] vdcIn = new byte[2];

    /**
     * 剩余电量
     */
    private byte[] soc = new byte[2];

    /**
     * 充电电流
     */
    private byte[] ib = new byte[2];

    /**
     * 预留1(JH1)
     */
    private byte[] balance1 = new byte[2];

    /**
     * 预留2(JH2)
     */
    private byte[] balance2 = new byte[2];

    /**
     * 额定容量
     */
    private byte[] ratedCapacity = new byte[2];

    /**
     * 单体电压 1-20
     */
    private byte[] vCell1 = new byte[2];
    private byte[] vCell2 = new byte[2];
    private byte[] vCell3 = new byte[2];
    private byte[] vCell4 = new byte[2];
    private byte[] vCell5 = new byte[2];
    private byte[] vCell6 = new byte[2];
    private byte[] vCell7 = new byte[2];
    private byte[] vCell8 = new byte[2];
    private byte[] vCell9 = new byte[2];
    private byte[] vCell10 = new byte[2];
    private byte[] vCell11 = new byte[2];
    private byte[] vCell12 = new byte[2];
    private byte[] vCell13 = new byte[2];
    private byte[] vCell14 = new byte[2];
    private byte[] vCell15 = new byte[2];
    private byte[] vCell16 = new byte[2];
    private byte[] vCell17 = new byte[2];
    private byte[] vCell18 = new byte[2];
    private byte[] vCell19 = new byte[2];
    private byte[] vCell20 = new byte[2];

    /**
     * 电池组电压(电池总电压)
     */
    private byte[] vBat = new byte[2];

    /**
     * 电池组温度(温度)
     */
    private byte[] temperature = new byte[2];

    /**
     * 放电状态
     */
    private Integer dischargeStatus;

    /**
     * 放电时长
     */
    private Integer dischargeDuration;

    @Override
    public String toString() {
        return "BmsDataBody{" +
                "status1=" + TcpUtil.bytes2Int(status1) +
                ", status2=" + TcpUtil.bytes2Int(status2) +
                ", status3=" + TcpUtil.bytes2Int(status3) +
                ", ia=" + TcpUtil.bytes2Int(ia) +
                ", vdcIn=" + TcpUtil.bytes2Int(vdcIn) +
                ", soc=" + TcpUtil.bytes2Int(soc) +
                ", ib=" + TcpUtil.bytes2Int(ib) +
                ", balance1=" + TcpUtil.bytes2Int(balance1) +
                ", balance2=" + TcpUtil.bytes2Int(balance2) +
                ", ratedCapacity=" + TcpUtil.bytes2Int(ratedCapacity) +
                ", vCell1=" + TcpUtil.bytes2Int(vCell1) +
                ", vCell2=" + TcpUtil.bytes2Int(vCell2) +
                ", vCell3=" + TcpUtil.bytes2Int(vCell3) +
                ", vCell4=" + TcpUtil.bytes2Int(vCell4) +
                ", vCell5=" + TcpUtil.bytes2Int(vCell5) +
                ", vCell6=" + TcpUtil.bytes2Int(vCell6) +
                ", vCell7=" + TcpUtil.bytes2Int(vCell7) +
                ", vCell8=" + TcpUtil.bytes2Int(vCell8) +
                ", vCell9=" + TcpUtil.bytes2Int(vCell9) +
                ", vCell10=" + TcpUtil.bytes2Int(vCell10) +
                ", vCell11=" + TcpUtil.bytes2Int(vCell11) +
                ", vCell12=" + TcpUtil.bytes2Int(vCell12) +
                ", vCell13=" + TcpUtil.bytes2Int(vCell13) +
                ", vCell14=" + TcpUtil.bytes2Int(vCell14) +
                ", vCell15=" + TcpUtil.bytes2Int(vCell15) +
                ", vCell16=" + TcpUtil.bytes2Int(vCell16) +
                ", vCell17=" + TcpUtil.bytes2Int(vCell17) +
                ", vCell18=" + TcpUtil.bytes2Int(vCell18) +
                ", vCell19=" + TcpUtil.bytes2Int(vCell19) +
                ", vCell20=" + TcpUtil.bytes2Int(vCell20) +
                ", vBat=" + TcpUtil.bytes2Int(vBat) +
                ", temperature=" + TcpUtil.bytes2Int(temperature) +
                ", dischargeStatus=" + dischargeStatus +
                ", dischargeDuration=" + dischargeDuration +
                '}';
    }

    public String toJsonStr() {
        return "{" +
                "\"status1\":" + TcpUtil.bytes2Int(status1) +
                ", \"status2\":" + TcpUtil.bytes2Int(status2) +
                ", \"status3\":" + TcpUtil.bytes2Int(status3) +
                ", \"ia\":" + TcpUtil.bytes2Int(ia) +
                ", \"vdcIn\":" + TcpUtil.bytes2Int(vdcIn) +
                ", \"soc\":" + TcpUtil.bytes2Int(soc) +
                ", \"ib\":" + TcpUtil.bytes2Int(ib) +
                ", \"balance1\":" + TcpUtil.bytes2Int(balance1) +
                ", \"balance2\":" + TcpUtil.bytes2Int(balance2) +
                ", \"ratedCapacity\":" + TcpUtil.bytes2Int(ratedCapacity) +
                ", \"vCell1\":" + TcpUtil.bytes2Int(vCell1) +
                ", \"vCell2\":" + TcpUtil.bytes2Int(vCell2) +
                ", \"vCell3\":" + TcpUtil.bytes2Int(vCell3) +
                ", \"vCell4\":" + TcpUtil.bytes2Int(vCell4) +
                ", \"vCell5\":" + TcpUtil.bytes2Int(vCell5) +
                ", \"vCell6\":" + TcpUtil.bytes2Int(vCell6) +
                ", \"vCell7\":" + TcpUtil.bytes2Int(vCell7) +
                ", \"vCell8\":" + TcpUtil.bytes2Int(vCell8) +
                ", \"vCell9\":" + TcpUtil.bytes2Int(vCell9) +
                ", \"vCell10\":" + TcpUtil.bytes2Int(vCell10) +
                ", \"vCell11\":" + TcpUtil.bytes2Int(vCell11) +
                ", \"vCell12\":" + TcpUtil.bytes2Int(vCell12) +
                ", \"vCell13\":" + TcpUtil.bytes2Int(vCell13) +
                ", \"vCell14\":" + TcpUtil.bytes2Int(vCell14) +
                ", \"vCell15\":" + TcpUtil.bytes2Int(vCell15) +
                ", \"vCell16\":" + TcpUtil.bytes2Int(vCell16) +
                ", \"vCell17\":" + TcpUtil.bytes2Int(vCell17) +
                ", \"vCell18\":" + TcpUtil.bytes2Int(vCell18) +
                ", \"vCell19\":" + TcpUtil.bytes2Int(vCell19) +
                ", \"vCell20\":" + TcpUtil.bytes2Int(vCell20) +
                ", \"vBat\":" + TcpUtil.bytes2Int(vBat) +
                ", \"temperature\":" + TcpUtil.bytes2Int(temperature) +
                ", \"dischargeStatus\":" + dischargeStatus +
                ", \"dischargeDuration\":" + dischargeDuration +
                "}";
    }
}
