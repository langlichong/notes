package com.genew.iot.modular.device.enums;

public enum TbAttributeScopes {


    SHARED_SCOPE,

    SERVER_SCOPE,

    CLIENT_SCOPE

}
