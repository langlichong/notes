package com.genew.iot.modular.collect.core;

/**
 * 指标采集任务运行状态
 */
public enum MetricStatus {

    RUNNING("running"),
    STOPPED("stopped");

    private String status;

    MetricStatus(String status){
        this.status = status;
    }

}
