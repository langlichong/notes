package com.genew.iot.modular.collect.customized.ba4;

import lombok.Builder;
import lombok.Data;

/**
 * @author : renqiang
 * @date : 2023-03-21 11:13
 * @description : 本安输出路数 及状态
 */
@Data
@Builder
public class RoadStatus {

    /**
     * 状态
     */
    private Integer status;

    /**
     * 电流值
     */
    private Integer electricity;

}
