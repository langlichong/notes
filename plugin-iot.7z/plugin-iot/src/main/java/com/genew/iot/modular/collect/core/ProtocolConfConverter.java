package com.genew.iot.modular.collect.core;

import cn.hutool.json.JSONUtil;
import com.alibaba.excel.util.StringUtils;
import com.genew.iot.modular.metric.dto.protocol.*;

public class ProtocolConfConverter {


    public static void convert2BeanByCollectType(CollectRequest request){

        final String protocol = request.getProtocol();
        final String protocolConf = request.getProtocolConf();
        if(StringUtils.isBlank(protocolConf)){
            throw new RuntimeException(request.getName().concat(" 没有配置采集协议相关信息,不能采集"));
        }

        if (CollectTypes.MODBUS_TCPIP.name().equalsIgnoreCase(protocol)){

            request.setModbusTcpProtocolConf(JSONUtil.toBean(protocolConf, ModbusTcpProtocolConf.class));

        }else if(CollectTypes.HTTP_API.name().equalsIgnoreCase(protocol)){

            request.setHttpProtocolConf(JSONUtil.toBean(protocolConf, HttpProtocolConf.class));

        }else if(CollectTypes.DATABASE_QUERY.name().equalsIgnoreCase(protocol)){

            request.setDatabaseProtocolConf(JSONUtil.toBean(protocolConf, DatabaseProtocolConf.class));

        }else if(CollectTypes.FILE_READING.name().equalsIgnoreCase(protocol)){

            request.setFileProtocolConf(JSONUtil.toBean(protocolConf, FileProtocolConf.class));

        }else if(CollectTypes.MQTT_PUBLISH.name().equalsIgnoreCase(protocol) || CollectTypes.MQTT_SUBSCRIBE.name().equalsIgnoreCase(protocol)){
            request.setMqttProtocolConf(JSONUtil.toBean(protocolConf, MqttProtocolConf.class));
        }else if(CollectTypes.OPC_UA_SUBSCRIBE.name().equalsIgnoreCase(protocol) || CollectTypes.OPC_UA_POLL.name().equalsIgnoreCase(protocol)){
            request.setOpcUaConf(JSONUtil.toBean(protocolConf, OpcUaProtocolConf.class));
        }else if(CollectTypes.TCP_POLL.name().equalsIgnoreCase(protocol) || CollectTypes.TCP_SUBSCRIBE.name().equalsIgnoreCase(protocol)){
            request.setTcpProtocolConf(JSONUtil.toBean(protocolConf, TcpProtocolConf.class));
        }
    }
}
