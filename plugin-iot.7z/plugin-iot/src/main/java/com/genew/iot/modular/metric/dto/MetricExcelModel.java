package com.genew.iot.modular.metric.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import cn.afterturn.easypoi.handler.inter.IExcelDataModel;
import cn.afterturn.easypoi.handler.inter.IExcelModel;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Objects;

@Data
public class MetricExcelModel implements Serializable, IExcelModel, IExcelDataModel{

    @NotEmpty
    @Excel(name = "名称", width = 20,  orderNum = "1")
    private String name;

    @NotEmpty
    @Excel(name = "数据类型" ,dict = "dataType",addressList = true, width = 20, orderNum = "2")
    private String dataType;

    @Excel(name = "数据单位", width = 20, orderNum = "3")
    private String dataUnit;

    @NotEmpty
    @Excel(name = "设备",dict = "device",addressList = true, width = 20, orderNum = "4")
    private String device;

    @NotEmpty
    @Excel(name = "采集协议",width = 20 , orderNum = "5",dict = "protocol", addressList = true)
    private String protocol;


    @Excel(name = "协议配置JSON",width = 20, orderNum = "6")
    private String protocolConf;

    @Excel(name = "采集间隔",width = 20, orderNum = "11")
    private Long intervalTime;

    @Excel(name = "采集结果处理JS脚本",width = 20, orderNum = "22")
    private String scriptContent;

    @Excel(name = "脚本返回值类型",width = 20, orderNum = "22",addressList = true, dict = "scriptRtType")
    private String scriptRtType;

    private String errorMsg;
    private Integer rowNum;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MetricExcelModel that = (MetricExcelModel) o;
        return Objects.equals(name, that.name) && Objects.equals(device, that.device);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, device);
    }
}
