package com.genew.iot.modular.collect.collector;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.util.StringUtils;
import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.modular.collect.core.*;
import com.genew.iot.modular.collect.pool.ConnectionHolder;
import com.genew.iot.modular.collect.pool.ModbusTcpMasterPoolFactory;
import com.genew.iot.modular.metric.dto.protocol.ModbusTcpProtocolConf;
import com.ghgande.j2mod.modbus.facade.ModbusTCPMaster;
import com.ghgande.j2mod.modbus.procimg.InputRegister;
import com.ghgande.j2mod.modbus.procimg.Register;
import com.ghgande.j2mod.modbus.util.BitVector;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class ModbusTcpCollector extends AbstractCollector<JSONObject,String> {

    public static final int COILS_BASE_ADDR_FUNC_1 = 1;
    public static final int INPUT_COILS_BASE_ADDR_FUNC_2 = 10001;
    public static final int HOLD_REGISTER_BASE_ADDR_FUNC_3 = 40001;
    public static final int INPUT_REGISTER_BASE_ADDR_FUNC_4 = 30001;

    public static final int MODBUS_CONN_TIMEOUT = 1000 * 10;

    private static ConcurrentHashMap<String,ModbusTCPMaster> masterCache = new ConcurrentHashMap<>();

    @Override
    protected boolean support(CollectRequest request) {

        if(CollectTypes.MODBUS_TCPIP.name().equalsIgnoreCase(request.getProtocol())){
            return true;
        }
        return false;
    }

    @Override
    @ExceptionLog(value = "Modbus Tcp采集", type = LogTypes.collectData)
    protected CollectResponse<JSONObject,String> collectData() throws DataIntegrationException {

        final CollectRequest request = CollectContext.getRequest();

        final ModbusTcpProtocolConf protocolConf = request.getModbusTcpProtocolConf();

        String hostIp = protocolConf.getHostIp();
        int port = protocolConf.getHostPort();
        Integer slaveId = protocolConf.getSlaveUnitId();

        // 相同 host与port 的ModbusTcpMetaInfo 共享同一个连接池
        GenericObjectPool<ModbusTCPMaster> connPool = ConnectionHolder.get(protocolConf);
        if(connPool == null){
            log.info("------Create Modbus pool with IP={},PORT={}",protocolConf.getHostIp(),protocolConf.getHostPort());
            ModbusTcpMasterPoolFactory factory = new ModbusTcpMasterPoolFactory(protocolConf.getHostIp(),protocolConf.getHostPort());
            connPool = factory.createPool();

            ConnectionHolder.add(protocolConf, connPool);
        }
        log.info(" --- connection pool size = {}", ConnectionHolder.size());
        log.info(" --- Current active connections = {}",connPool.getNumActive());
        log.info(" --- Current idle connections = {}",connPool.getNumIdle());
        log.info(" --- CreatedCount = {}",connPool.getCreatedCount());

        String tagValue = "";
        ModbusTCPMaster client = null ;
        try {
            log.info(">>> borrow connection from modbus pool , ip = {}, port = {}",protocolConf.getHostIp(),protocolConf.getHostPort());
            client = connPool.borrowObject();
            // 读 Modbus 寄存器数据
            tagValue = readModbusRegister(request, client);
            if(StringUtils.isBlank(tagValue)){
                return null;
            }
        } catch (Exception e) {
            String tips = "modbus 连接获取异常";
            throw new DataIntegrationException(tips,e);
        }finally {
            if(client !=null && client.isConnected()){
                connPool.returnObject(client);
            }
        }

        // 封装采集结果
        final CollectResponse response = buildCollectResponse(request, tagValue);
        return response;
    }


    private static CollectResponse buildCollectResponse(CollectRequest request, String tagValue) {

        /*final JSONObject valuePart = JSONUtil.createObj()
                .set("ts",System.currentTimeMillis()+"")
                .set("unit", request.getDataUnit())
                .set("value", tagValue);*/

        //推送格式： {"指标名称": "指标值对象"}
        //final JSONObject dataPoint = JSONUtil.createObj().set(request.getName(), valuePart);

        final CollectResponse response = CollectResponse.builder()
                .originRequest(request)
                .collectResult(tagValue)
                .collectResultType(ProcessResultType.PRIMITIVE)
                .build();
        return response;
    }

    private int calOffset(String startAddr,ModbusTcpProtocolConf protocolConf){

        if(StringUtils.isBlank(startAddr)){
            throw new RuntimeException("Modbus指标起始地址为空");
        }

        final String addressType = protocolConf.getAddressType();

        if("plc".equalsIgnoreCase(addressType)){ // PLC地址: base 1

            String partOne = startAddr.substring(0, startAddr.length()-1);
            String baseZero = partOne + "1";
            return Integer.valueOf(startAddr) - Integer.valueOf(baseZero);
        }

        return Integer.valueOf(startAddr);

    }

    private String readModbusRegister(CollectRequest request, ModbusTCPMaster client) {

        final ModbusTcpProtocolConf protocolConf = request.getModbusTcpProtocolConf();

        final String dataAddr = protocolConf.getAddresStart().trim();
        final Integer slaveId = request.getModbusTcpProtocolConf().getSlaveUnitId();

        final String dataType = request.getDataType();

        // todo 站地址、偏移量、默认大小端存储
        String tagValue = "";
        final int count = calReadCount(dataType);
        try {
            if(!client.isConnected()){
                client.connect();
            }
            final Integer funcCode = protocolConf.getFuncCode();
            int offset = calOffset(dataAddr,protocolConf);
            if( funcCode == 1 ){// read coils 01功能码

                final BitVector bitVector = client.readCoils(slaveId,offset, count);
                tagValue = bitVector.toString();

            }else if( funcCode == 2 ){// read discrete inputs

                final BitVector bitVector = client.readInputDiscretes(slaveId, offset, count);
                tagValue = bitVector.toString();

            }else if( funcCode == 3 ){// read holding registers

                final Register[] registers = client.readMultipleRegisters(slaveId, offset, count);
                tagValue = calRegisterValues(registers,dataType);

            }else if( funcCode == 4 ){// read input registers

                final InputRegister[] inputRegisters = client.readInputRegisters(slaveId, offset, count);
                tagValue = calRegisterValues(inputRegisters,dataType);
            }else{

                log.warn("不支持的Modbus 采集请求: {}", JSONUtil.toJsonStr(request));
            }

        }catch(Exception e){
            log.error("Modbus 指标采集异常: ",e);
        }
        return tagValue;
    }

    /**
     * 计算从站地址
     * @param host
     * @return
     */
    private String[] calSlaveUnitId(String host) {
        final int i = host.lastIndexOf(".");
        final String hostIp = host.substring(0, i);
        final String slaveUnit = host.substring(i + 1);

        return new String[]{hostIp,slaveUnit};
    }

    /**
     * 按大端存储方式计算
     */
    private static String calRegisterValues(InputRegister[] registers,String dataType) {

        if(registers == null || registers.length == 0){
            return StringUtils.EMPTY;
        }

        // todo 多个寄存器默认按大端存储
        int value = registers[0].getValue();
        log.debug("registers[0] = {}",value);
        if(registers.length == 2){
            final int r2 = registers[1].getValue();
            log.debug("registers[1] = {}",r2);

            // 多个寄存器时候，计算出寄存器组合后的实际十进制值
            value = value<<16 | r2;
        }
        String res = value +"";
        switch (dataType.trim()){
            case "BYTE":
            case "BOOLEAN":
                if(value != 0){
                    res = "true";
                }else{
                    res = "false";
                }
                break;
            case "WORD":
                break;
            case "INT":
                break;
            case "DWORD":
            case "FLOAT":
                // 取高位寄存器 及 低位寄存器值 并转换为float
                if(registers.length != 2){
                    log.warn("Float类型转换：寄存器个数不是2 ，不满足IEEE 754 32位浮点转换规则");
                }else{
                    int val = registers[0].getValue() << 16 | registers[1].getValue()  ;
                    final float float32 = Float.intBitsToFloat(val);
                    res = float32 + "";
                }
                break;
            case "DOUBLE":
                if(registers.length != 4){
                    log.warn("Double类型转换：寄存器个数不匹配 4 ，不满足IEEE 754 64位双精度转换规则");
                }else{
                    long long64 = ((long)registers[0].getValue() << 48) | ((long)registers[1].getValue() << 32) | ((long)registers[2].getValue() << 16) | ((long)registers[3].getValue());
                    double double64 = Double.longBitsToDouble(long64);
                    res = double64 + "";
                }

                break;
        }

        return res ;
    }


   private int calReadCount(String dataType){

        int readCount = -1;
        switch (dataType.trim()){
            case "BYTE":
            case "BOOLEAN":
                readCount =  1;
                break;
            case "WORD":
            case "INT":
                readCount = 1;
                break;
            case "FLOAT":
            case "DWORD":
                readCount = 2;
                break;
            case "DOUBLE":
                readCount = 4;
                break;
            default:
                readCount = 1;
        }

        return readCount;
   }
}
