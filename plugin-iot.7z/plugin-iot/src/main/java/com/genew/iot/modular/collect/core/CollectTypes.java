package com.genew.iot.modular.collect.core;

public enum CollectTypes {

    /**
     * opc ua 订阅
     */
    OPC_UA_SUBSCRIBE,

    /**
     * opc ua 轮训
     */
    OPC_UA_POLL,

    /**
     * modbus tcp/ip
     */
    MODBUS_TCPIP,

    /**
     *  Http API调用
     */
    HTTP_API,

    /**
     * 数据库直连
     */
    DATABASE_QUERY,

    /**
     * 读文件
     */
    FILE_READING,
    /**
     * mqtt订阅
     */
    MQTT_SUBSCRIBE,

    /**
     * mqtt发布
     */
    MQTT_PUBLISH,
    /**
     * tcp订阅
     */
    TCP_SUBSCRIBE,
    /**
     * tcp轮询
     */
    TCP_POLL
}
