package com.genew.iot.modular.collect.processors;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.genew.iot.core.util.TbHelper;
import com.genew.iot.modular.collect.core.AbstractCollectResponseProcessor;
import com.genew.iot.modular.collect.core.CollectResponse;
import com.genew.iot.modular.collect.core.ProcessResultType;
import com.genew.iot.modular.collect.core.ProcessorResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * 推送到 Thingsboard 平台
 */
@Slf4j
@Component
public class Push2TbProcessor extends AbstractCollectResponseProcessor {

    @Resource
    private TbHelper tbHelper;

    @Override
    public String id() {
        return "push2TbProcessor";
    }

    @Override
    public String name() {
        return "推送TB";
    }


    @Override
    public boolean support(CollectResponse response) {
        return true;
    }

    /**
     * 推送到 Thingsboard 平台： 推送的内容依赖 ScriptProcessor 的处理结果（如果一个指标未配置脚本，则推送内容就是采集器直接返回的结果）
     * @param response 原始采集结果
     * @param previousResult
     * @return
     */
    @Override
    public ProcessorResult doProcess(CollectResponse response, ProcessorResult previousResult) {

        log.info("---Push2TbProcessor start----");

        if(support(response)){

            final List<String> pushTargetDevIds = response.getOriginRequest().getPushTargetDevIds();
            final Object metricValue = previousResult.getResult();
            if (Objects.isNull(metricValue)) {
                return previousResult;
            }
            final ProcessResultType resultType = previousResult.getResultType();
            final String metricName = response.getOriginRequest().getName();
            switch (resultType){
                case PRIMITIVE:

                    //标量需要构造成 json 格式以适配TB API参数要求
                    final JSONObject telemetry = JSONUtil.createObj().set(metricName, metricValue.toString());
                    log.info("TB push primitive  = {}",telemetry);
                    tbHelper.push2Thingsboard(telemetry, pushTargetDevIds);
                    break;
                case JSON:
                case JSON_STRING:
                    log.info("TB push json or jsonstring  = {}",metricValue);
                    tbHelper.push2Thingsboard(metricValue.toString() , pushTargetDevIds);
                    break;
                case JSONARRY:
                case JSONARRY_STRING:
                    JSONArray arrayValue = JSONUtil.parseArray(metricValue.toString());
                    log.info("TB push jsonarray  = {}",arrayValue);
                    for (int i = 0; i < arrayValue.size(); i++) {
                        final JSONObject telemetries = arrayValue.getJSONObject(i);
                        tbHelper.push2Thingsboard(telemetries, pushTargetDevIds);
                    }
                    break;
            }
        }

        return previousResult;
    }

    @Override
    public int getOrder() {
        return 1;
    }
}
