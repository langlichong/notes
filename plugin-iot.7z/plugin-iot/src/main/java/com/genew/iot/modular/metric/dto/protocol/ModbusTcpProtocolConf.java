package com.genew.iot.modular.metric.dto.protocol;

import lombok.Data;

import java.util.Objects;

@Data
public class ModbusTcpProtocolConf extends Common{

    /**
     * 协议名称
     */
    protected String protocol;

    /**
     * 主机地址
     */
    protected String hostIp;

    /**
     * 主机端口
     */
    protected Integer hostPort;

    /**
     * 从站编号
     */
    private Integer slaveUnitId;

    /**
     * 功能码
     */
    private Integer funcCode;

    /**
     * 协议地址类型：STANDARD , PLC
     */
    private String addressType;

    /**
     * 起始地址
     */
    private String  addresStart ;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModbusTcpProtocolConf that = (ModbusTcpProtocolConf) o;
        return Objects.equals(hostIp, that.hostIp) && Objects.equals(hostPort, that.hostPort);
    }

    @Override
    public int hashCode() {
        return Objects.hash(hostIp, hostPort);
    }
}
