package com.genew.iot.modular.device.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class DeviceSyncParam {

    @ApiModelProperty(value = "需同步的设备ID列表,若为空参数，则默认同步所有台账")
    private String deviceIds;
}
