package com.genew.iot.core.util;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.genew.common.exception.CommonException;
import com.genew.iot.core.constant.IotOpcUaConstant;
import com.genew.iot.modular.collect.core.CollectRequest;
import com.genew.iot.modular.collect.core.CollectResponse;
import com.genew.iot.modular.metric.dto.protocol.OpcUaProtocolConf;
import com.google.common.collect.Maps;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.milo.opcua.sdk.client.OpcUaClient;
import org.eclipse.milo.opcua.sdk.client.api.identity.AnonymousProvider;
import org.eclipse.milo.opcua.sdk.client.api.subscriptions.UaMonitoredItem;
import org.eclipse.milo.opcua.sdk.client.api.subscriptions.UaSubscription;
import org.eclipse.milo.opcua.sdk.client.api.subscriptions.UaSubscriptionManager;
import org.eclipse.milo.opcua.stack.core.AttributeId;
import org.eclipse.milo.opcua.stack.core.UaException;
import org.eclipse.milo.opcua.stack.core.security.SecurityPolicy;
import org.eclipse.milo.opcua.stack.core.types.builtin.*;
import org.eclipse.milo.opcua.stack.core.types.builtin.unsigned.UInteger;
import org.eclipse.milo.opcua.stack.core.types.enumerated.MonitoringMode;
import org.eclipse.milo.opcua.stack.core.types.enumerated.TimestampsToReturn;
import org.eclipse.milo.opcua.stack.core.types.structured.MonitoredItemCreateRequest;
import org.eclipse.milo.opcua.stack.core.types.structured.MonitoringParameters;
import org.eclipse.milo.opcua.stack.core.types.structured.ReadValueId;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.function.Supplier;

import static org.eclipse.milo.opcua.stack.core.types.builtin.unsigned.Unsigned.uint;

/**
 * OPC-UA数据采集工具类
 *
 * @author js
 * @date 2023/03/27 14:22
 */
@Slf4j
@Component
public class OpcUaUtil {

    public static final Map<String, String> opcUaSubCache = Maps.newConcurrentMap();

    public final ConcurrentHashMap<String, OpcUaClient> opcUaClientCache = new ConcurrentHashMap<>();

    /**
     * 创建opc-ua连接
     *
     * @param request
     * @param opcUaProtocolConf
     * @return
     */
    public OpcUaClient connect(CollectRequest request, OpcUaProtocolConf opcUaProtocolConf) {
        if (StringUtils.isBlank(opcUaProtocolConf.getHostIp()) || Objects.isNull(opcUaProtocolConf.getHostPort())) {
            throw new CommonException("OPC-UA参数错误:{}", opcUaProtocolConf);
        }
        OpcUaClient client;
        try {
            client = createOpcClient(opcUaProtocolConf);
            client.connect().get();
        } catch (InterruptedException | ExecutionException | UaException e) {
            log.error("OPC-UA connect error:{}", e.getMessage());
            throw new CommonException("OPC-UA connect error:{}", e.getMessage());
        }
        if (Objects.nonNull(client)) {
            // 缓存client
            opcUaClientCache.put(request.getId(), client);
        }
        return client;
    }

    /**
     * 创建订阅subscription
     *
     * @param request
     * @param identifier
     * @param client
     * @param supplier
     */
    public void subscribe(CollectRequest request, String identifier, OpcUaClient client,
                          Supplier<CollectResponse> supplier) {
        UaSubscription subscription;
        Long intervalTime = request.getIntervalTime() * 1000;
        try {
            if (CollectionUtil.isNotEmpty(client.getSubscriptionManager().getSubscriptions())) {
                subscription = client.getSubscriptionManager().getSubscriptions().get(0);
            } else {
                //创建订阅
                subscription = client.getSubscriptionManager().createSubscription(intervalTime).get();
                client.getSubscriptionManager().addSubscriptionListener(new CustomSubscriptionListener(supplier));
            }
            NodeId nodeId = new NodeId(IotOpcUaConstant.OPC_SERVER_NAMESPACE_INDEX, identifier);
            ReadValueId readValueId = new ReadValueId(
                    nodeId,
                    AttributeId.Value.uid(), null, QualifiedName.NULL_VALUE
            );
            List<MonitoredItemCreateRequest> monitoredItemCreateRequests = new ArrayList<>();
            MonitoringParameters parameters = new MonitoringParameters(
                    subscription.nextClientHandle(),
                    // sampling interval
                    intervalTime.doubleValue(),
                    // filter, null means use default
                    null,
                    // queue size
                    uint(IotOpcUaConstant.OPC_THREAD_POOL_BLOCKING_DEQUE_CAPACITY),
                    // discard oldest
                    Boolean.TRUE
            );
            MonitoredItemCreateRequest itemCreateRequest = new MonitoredItemCreateRequest(
                    readValueId,
                    MonitoringMode.Reporting,
                    parameters
            );
            monitoredItemCreateRequests.add(itemCreateRequest);
            //创建监控项，并且注册变量值改变时候的回调函数。
            UaSubscription.ItemCreationCallback onItemCreated =
                    (subscriptionItem, id) -> subscriptionItem.setValueConsumer(this::onSubscriptionValue);
            subscription.createMonitoredItems(
                    TimestampsToReturn.Both,
                    monitoredItemCreateRequests,
                    onItemCreated
            ).get();
        } catch (InterruptedException | ExecutionException e) {
            log.error("OPC-UA opcUaSubscribeCollect data error:{}", e.getMessage());
        }
    }

    /**
     * 自定义订阅监听
     */
    public class CustomSubscriptionListener implements UaSubscriptionManager.SubscriptionListener {
        private Supplier<CollectResponse> supplier;

        public CustomSubscriptionListener(Supplier<CollectResponse> supplier) {
            this.supplier = supplier;
        }

        @Override
        public void onKeepAlive(UaSubscription subscription, DateTime publishTime) {
            log.debug("onKeepAlive");
        }

        @Override
        public void onStatusChanged(UaSubscription subscription, StatusCode status) {
            log.debug("onStatusChanged");
        }

        @Override
        public void onPublishFailure(UaException exception) {
            log.debug("onPublishFailure");
        }

        @Override
        public void onNotificationDataLost(UaSubscription subscription) {
            log.debug("onNotificationDataLost");
        }

        /**
         * 重连时 尝试恢复之前的订阅失败时 会调用此方法
         *
         * @param uaSubscription 订阅
         * @param statusCode     状态
         */
        @SneakyThrows
        @Override
        public void onSubscriptionTransferFailed(UaSubscription uaSubscription, StatusCode statusCode) {
            log.warn("start onSubscriptionTransferFailed:{}", statusCode);
            if (!statusCode.isGood()) {
                //在回调方法中重新订阅
                supplier.get();
            }
        }
    }

    /**
     * 订阅回调函数
     *
     * @param item
     * @param value
     */
    private void onSubscriptionValue(UaMonitoredItem item, DataValue value) {
        if (!value.getStatusCode().isGood()) {
            return;
        }
        Object collectValue = opcUaSubCache.get(item.getReadValueId().getNodeId().getIdentifier().toString());
        //判断key与lists对象是否相同
        Boolean existSame = judgeSameValue(value.getValue().getValue(), collectValue);
        if (!existSame) {
            String attributeValue = judgeScientific(value.getValue().getValue().toString());
            opcUaSubCache.put(item.getReadValueId().getNodeId().getIdentifier().toString(), attributeValue);
        }
    }

    public OpcUaClient createOpcClient(OpcUaProtocolConf opcUaProtocolConf) throws UaException {
        String endPointUrl = IotOpcUaConstant.OPC_UA_END_POINT_PREFIX + opcUaProtocolConf.getHostIp() + StrUtil.COLON + opcUaProtocolConf.getHostPort();
        log.info("OPC-Ua 服务地址：{}", endPointUrl);
        OpcUaClient client = OpcUaClient.create(endPointUrl,
                endpoints ->
                        endpoints.stream()
                                .filter(e -> e.getSecurityPolicyUri().equals(SecurityPolicy.None.getUri()))
                                .findFirst(),
                configBuilder ->
                        configBuilder
                                .setApplicationName(LocalizedText.english("eclipse milo opc-ua client"))
                                .setApplicationUri("urn:eclipse:milo:iot:client")
                                //访问方式
                                .setIdentityProvider(new AnonymousProvider())
                                .setRequestTimeout(UInteger.valueOf(IotOpcUaConstant.OPC_REQUEST_TIMEOUT))
                                .build()
        );
        return client;
    }

    /**
     * 判断采集数据是否为科学计数，若是(大于0转正常数字输出，小于0返回0)，若否，返回原内容
     *
     * @param str
     * @return
     */
    public String judgeScientific(String str) {
        boolean isMatch = IotOpcUaConstant.VALUE_PATTERN.matcher(str.trim()).find();
        if (isMatch) {
            BigDecimal bigDecimal = new BigDecimal(str);
            int i = bigDecimal.compareTo(BigDecimal.ZERO);
            if (i == IotOpcUaConstant.NEGATIVE_ONE || i == IotOpcUaConstant.ZERO) {
                return IotOpcUaConstant.ZERO_STRING;
            }
            String attributeValue = bigDecimal.setScale(IotOpcUaConstant.RETAIN_THREE_SIGNIFICANT_DIGITS, RoundingMode.HALF_UP).toPlainString();
            return attributeValue;
        }
        return str;
    }

    /**
     * 关闭OPC-UA 连接
     *
     * @param client
     */
    public void closeOpcUaConnect(OpcUaClient client) {
        if (Objects.isNull(client)) {
            return;
        }
        try {
            if (Objects.nonNull(client)) {
                client.disconnect().get();
            }
        } catch (InterruptedException | ExecutionException e) {
            log.error("OPC-UA disconnect Exception:{}", e.getMessage());
        }
    }

    /**
     * 比较采集数值是否相同
     *
     * @param newCollectValue
     * @param collectValue
     * @return
     */
    public Boolean judgeSameValue(Object newCollectValue, Object collectValue) {
        if (Objects.equals(newCollectValue, collectValue)) {
            return true;
        }
        return false;
    }

}
