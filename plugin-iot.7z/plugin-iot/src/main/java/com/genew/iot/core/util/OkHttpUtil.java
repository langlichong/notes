package com.genew.iot.core.util;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.genew.common.exception.CommonException;
import com.genew.dev.api.DevConfigApi;
import com.genew.iot.core.constant.IotThirdApiConstant;
import com.genew.iot.modular.thirdapi.enums.IotThirdApiExceptionEnum;
import com.genew.iot.modular.thirdapi.enums.IotThirdApiMediaTypeEnum;
import com.genew.iot.modular.thirdapi.interceptor.RetryInterceptor;
import com.google.common.collect.Maps;
import com.jayway.jsonpath.JsonPath;
import com.squareup.okhttp.*;
import lombok.extern.slf4j.Slf4j;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * OkHttp工具类
 *
 * @author js
 * @date 2023/03/28 10:09
 */
@Slf4j
public class OkHttpUtil {

    private static volatile OkHttpClient okHttpClient = null;
    private static volatile Semaphore semaphore = null;
    private Map<String, String> headerMap;
    private Map<String, Object> paramMap;
    private String url;
    private Request.Builder request;

    /**
     * 初始化okHttpClient，并且允许https访问
     */
    public OkHttpUtil() {
        DevConfigApi devConfigApi = SpringUtil.getBean(DevConfigApi.class);
        if (okHttpClient == null) {
            synchronized (OkHttpUtil.class) {
                TrustManager[] trustManagers = buildTrustManagers();
                String connectTimeOut = devConfigApi.getValueByKey(IotThirdApiConstant.RETRY_CONNECT_TIMEOUT);
                String writeTimeOut = devConfigApi.getValueByKey(IotThirdApiConstant.RETRY_WRITE_TIMEOUT);
                String readTimeOut = devConfigApi.getValueByKey(IotThirdApiConstant.RETRY_READ_TIMEOUT);
                String maxTimes = devConfigApi.getValueByKey(IotThirdApiConstant.RETRY_MAX_TIMES);
                String autoConnectFlag = devConfigApi.getValueByKey(IotThirdApiConstant.RETRY_AUTO_CONNECT);
                if (StrUtil.isBlank(connectTimeOut)) {
                    throw new CommonException("接口重试未正确配置：connectTimeOut为空");
                }
                if (StrUtil.isBlank(writeTimeOut)) {
                    throw new CommonException("接口重试未正确配置：writeTimeOut为空");
                }
                if (StrUtil.isBlank(readTimeOut)) {
                    throw new CommonException("接口重试未正确配置：readTimeOut为空");
                }
                if (StrUtil.isBlank(maxTimes)) {
                    throw new CommonException("接口重试未正确配置：maxTimes为空");
                }
                if (StrUtil.isBlank(autoConnectFlag)) {
                    throw new CommonException("接口重试未正确配置：autoConnectFlag为空");
                }
                okHttpClient = new OkHttpClient();
                okHttpClient.setConnectTimeout(Long.parseLong(connectTimeOut), TimeUnit.SECONDS);
                okHttpClient.setWriteTimeout(Long.parseLong(writeTimeOut), TimeUnit.SECONDS);
                okHttpClient.setReadTimeout(Long.parseLong(readTimeOut), TimeUnit.SECONDS);
                okHttpClient.setSslSocketFactory(createSSLSocketFactory(trustManagers));
                okHttpClient.setHostnameVerifier((hostName, session) -> true);
                okHttpClient.interceptors().add(new RetryInterceptor(maxTimes));
                okHttpClient.setRetryOnConnectionFailure(Boolean.parseBoolean(autoConnectFlag));
                request = new Request.Builder().addHeader("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X10_12_6) " +
                        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36").addHeader("Connection", "close");
            }
        }
    }

    /**
     * 用于异步请求时，控制访问线程数，返回结果
     *
     * @return
     */
    private static Semaphore getSemaphoreInstance() {
        //只能1个线程同时访问
        synchronized (OkHttpUtil.class) {
            if (ObjectUtil.isEmpty(semaphore)) {
                semaphore = new Semaphore(0);
            }
        }
        return semaphore;
    }

    /**
     * 创建OkHttpClientUtil
     *
     * @return
     */
    public OkHttpUtil builder() {
        return new OkHttpUtil();
    }

    /**
     * 添加url
     *
     * @param url
     * @return
     */
    public OkHttpUtil url(String url) {
        this.url = url;
        return this;
    }

    /**
     * 添加参数
     *
     * @param key   参数名
     * @param value 参数值
     * @return
     */
    public OkHttpUtil addParam(String key, String value) {
        if (ObjectUtil.isEmpty(paramMap)) {
            paramMap = new LinkedHashMap<>(16);
        }
        paramMap.put(key, value);
        return this;
    }

    /**
     * 添加多个参数
     *
     * @param map 参数
     * @return
     */
    public OkHttpUtil addParams(Map<String, Object> map) {
        if (ObjectUtil.isEmpty(paramMap)) {
            paramMap = new LinkedHashMap<>(16);
        }
        for (String key : map.keySet()) {
            paramMap.put(key, map.get(key));
        }
        return this;
    }

    /**
     * 添加请求头
     *
     * @param key   参数名
     * @param value 参数值
     * @return
     */
    public OkHttpUtil addHeader(String key, String value) {
        if (ObjectUtil.isEmpty(headerMap)) {
            headerMap = new LinkedHashMap<>(16);
        }
        headerMap.put(key, value);
        return this;
    }

    /**
     * 添加多个请求头
     *
     * @param map 参数
     * @return
     */
    public OkHttpUtil addHeaders(Map<String, Object> map) {
        if (ObjectUtil.isEmpty(headerMap)) {
            headerMap = new LinkedHashMap<>(16);
        }
        for (String key : map.keySet()) {
            headerMap.put(key, String.valueOf(map.get(key)));
        }
        return this;
    }

    /**
     * 初始化get方法
     *
     * @return
     */
    public OkHttpUtil get() {
        request = new Request.Builder().get();
        StringBuilder urlBuilder = new StringBuilder(url);
        if (ObjectUtil.isNotEmpty(paramMap)) {
            urlBuilder.append("?");
            try {
                for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
                    urlBuilder.append(URLEncoder.encode(entry.getKey(), "utf-8")).
                            append("=").
                            append(URLEncoder.encode(entry.getValue().toString(), "utf-8")).
                            append("&");
                }
            } catch (Exception e) {
                log.error("get请求接口异常:{},Exception:{}", e.getMessage(), e);
            }
            urlBuilder.deleteCharAt(urlBuilder.length() - 1);
        }
        request.url(urlBuilder.toString());
        return this;
    }

    /**
     * 初始化post方法
     *
     * @param isJsonPost true等于json的方式提交数据，类似postman里post方法的raw
     *                   false等于普通的表单提交
     * @return
     */
    public OkHttpUtil post(boolean isJsonPost) {
        RequestBody requestBody;
        if (isJsonPost) {
            String json = "";
            if (ObjectUtil.isNotEmpty(paramMap)) {
                json = JSON.toJSONString(paramMap);
            }
            requestBody = RequestBody.create(MediaType.parse(IotThirdApiMediaTypeEnum.APPLICATION_JSON.getValue()), json);
        } else {
            FormEncodingBuilder formEncodingBuilder = new FormEncodingBuilder();
            if (ObjectUtil.isNotEmpty(paramMap)) {
                paramMap.forEach((key, value) -> {
                    formEncodingBuilder.add(key, value.toString());
                });
            }
            requestBody = formEncodingBuilder.build();
        }
        request = new Request.Builder().post(requestBody).url(url);
        return this;
    }

    /**
     * 同步请求
     *
     * @return
     */
    public Map<String, Object> sync() throws IOException {
        setHeader(request);
        LinkedHashMap<String, Object> returnMap = Maps.newLinkedHashMap();
        ResponseBody body = null;
        try {
            final Response response = okHttpClient.newCall(request.build()).execute();
            if (response != null) {
                assert response.body() != null;
                body = response.body();
                returnMap.put("code", response.code());
                log.debug("第三方请求接口返回状态:{}", response.code());
                JSONObject jsonObject = JSONUtil.parseObj(response.body().string());
                //判断data是否存在
                if (jsonObject.isNull(IotThirdApiConstant.DATA)) {
                    returnMap.put("data", jsonObject);
                } else {
                    // 如果data存在且code也存在
                    if (!jsonObject.isNull(IotThirdApiConstant.CODE)) {
                        returnMap.put("data", jsonObject.get("data"));
                    } else {
                        returnMap.put("data", jsonObject);
                    }
                }
            }
        } catch (Exception e) {
            log.error("第三方请求接口异常:{},Exception:{}", e.getMessage(), e);
            returnMap.put("code", IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAILED.getCode());
            returnMap.put("message", IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAILED.getMessage());
            returnMap.put("data", null);
        } finally {
            if (ObjectUtil.isNotEmpty(body)) {
                body.close();
            }
        }
        return returnMap;
    }

    /**
     * 异步请求，有返回值
     */
    public String async() {
        StringBuilder buffer = new StringBuilder("");
        setHeader(request);
        okHttpClient.newCall(request.build()).enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {

            }

            @Override
            public void onResponse(Response response) throws IOException {
                assert response.body() != null;
                buffer.append(response.body().string());
                getSemaphoreInstance().release();
            }
        });
        try {
            getSemaphoreInstance().acquire();
        } catch (InterruptedException e) {
            log.error("异步请求接口异常:{},Exception:{}", e.getMessage(), e);
        }
        return buffer.toString();
    }

    /**
     * 异步请求，带有接口回调
     *
     * @param callBack
     */
    public void async(ICallBack callBack) {
        setHeader(request);
        okHttpClient.newCall(request.build()).enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {

            }

            @Override
            public void onResponse(Response response) throws IOException {

            }
        });
    }

    /**
     * 为request添加请求头
     *
     * @param request
     */
    private void setHeader(Request.Builder request) {
        if (ObjectUtil.isNotEmpty(headerMap)) {
            try {
                for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                    request.addHeader(entry.getKey(), entry.getValue());
                }
            } catch (Exception e) {
                log.error("请求头异常:{},Exception:{}", e.getMessage(), e);
            }
        }
    }


    /**
     * 生成安全套接字工厂，用于https请求的证书跳过
     *
     * @return
     */
    private static SSLSocketFactory createSSLSocketFactory(TrustManager[] trustAllCerts) {
        SSLSocketFactory ssfFactory = null;
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            ssfFactory = sc.getSocketFactory();
        } catch (Exception e) {
            log.error("生成安全套接字工厂异常:{},Exception:{}", e.getMessage(), e);
        }
        return ssfFactory;
    }

    private static TrustManager[] buildTrustManagers() {
        return new TrustManager[]{
                new X509TrustManager() {
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType) {
                    }

                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType) {
                    }

                    @Override
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[]{};
                    }
                }
        };
    }

    /**
     * 自定义一个接口回调
     */
    public interface ICallBack {

        void onSuccessful(Call call, String data);

        void onFailure(Call call, String errorMsg);

    }

    /**
     * JSONPATH解析json
     *
     * @param requestJson
     * @param jsonPath
     * @return
     */
    public static String readJsonPathOrElseNull(String requestJson, String jsonPath) {
        try {
            return JsonPath.read(requestJson, jsonPath);
        } catch (Exception pEx) {
            log.error("No {}", jsonPath, " was present in the request or returned null.");
            return null;
        }
    }

    public static void main(String[] args) {
        /*String json = "{\"token\":\"eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZW5hbnRAdGhpbmdzYm9hcmQub3JnIiwic2NvcGVzIjpbIlRFTkFOVF9BRE1JTiJdLCJ1c2VySWQiOiJhMjQ1MTM3MC1mMDNkLTExZWMtOTJjOS1iZjdmYjVmYzcyNTciLCJlbmFibGVkIjp0cnVlLCJpc1B1YmxpYyI6ZmFsc2UsInRlbmFudElkIjoiYTBmMWRmODAtZjAzZC0xMWVjLTkyYzktYmY3ZmI1ZmM3MjU3IiwiY3VzdG9tZXJJZCI6IjEzODE0MDAwLTFkZDItMTFiMi04MDgwLTgwODA4MDgwODA4MCIsImlzcyI6InRoaW5nc2JvYXJkLmlvIiwiaWF0IjoxNjYyMDg4MjMwLCJleHAiOjE2NjIwOTcyMzB9.n4FOnD6_YIw0mlIGXcxdYZT1kCM_fjQ50kFxX8cJKFR5hTnXpUBFp9r93DtqyehW8xsPi239GBdQInUBbAPRdA\",\"refreshToken\":\"eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZW5hbnRAdGhpbmdzYm9hcmQub3JnIiwic2NvcGVzIjpbIlJFRlJFU0hfVE9LRU4iXSwidXNlcklkIjoiYTI0NTEzNzAtZjAzZC0xMWVjLTkyYzktYmY3ZmI1ZmM3MjU3IiwiaXNQdWJsaWMiOmZhbHNlLCJpc3MiOiJ0aGluZ3Nib2FyZC5pbyIsImp0aSI6IjVkYjM2YjZhLWU5ZmQtNGJhMS1hYzRhLTE1YWU5NzM5ZDBhYSIsImlhdCI6MTY2MjA4ODIzMCwiZXhwIjoxNjYyNjkzMDMwfQ.BCuB0qvIKr6k0S98QNhCjmu8z41Ej5oJ3hEg98vgSrxL_ZBY-BsKjyCT_T2kTAJw_M4TL6nd6tPh0rfUUGXhlA\"}";
        String token = JsonPath.read(json, "$.token");
        String refreshToken = JsonPath.read(json, "$.refreshToken");
        System.out.println("token：" + token);
        System.out.println("refreshToken：" + refreshToken);*/
    }

}
