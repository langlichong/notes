/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.metric.controller;

import cn.dev33.satoken.annotation.SaCheckPermission;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.common.pojo.CommonValidList;
import com.genew.iot.modular.collect.core.MetricStatus;
import com.genew.iot.modular.metric.entity.Metric;
import com.genew.iot.modular.metric.param.*;
import com.genew.iot.modular.metric.service.MetricService;
import com.genew.iot.modular.metric.tree.DeviceSensorNode;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 设备传感器指标控制器
 *
 * @author huhu
 * @date  2023/04/12 15:27
 */
@Api(tags = "设备传感器指标控制器")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
public class MetricController {

    @Resource
    private MetricService metricService;

    /**
     * 获取设备传感器指标分页
     *
     * @author huhu
     * @date  2023/04/12 15:27
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取设备传感器指标分页")
    @SaCheckPermission("/iot/metric/page")
    @GetMapping("/iot/metric/page")
    public CommonResult<Page<Metric>> page(MetricPageParam metricPageParam) {
        return CommonResult.data(metricService.page(metricPageParam));
    }

    /**
     * 获取已配置的指标列表
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取已配置的指标列表")
    @SaCheckPermission("/iot/metric/list")
    @GetMapping("/iot/metric/list")
    public CommonResult<List<Metric>> list() {

        final LambdaQueryWrapper<Metric> condition = Wrappers.lambdaQuery(Metric.class)
                .select(Metric::getId, Metric::getName)
                .orderByDesc(Metric::getCreateTime);
        return CommonResult.data(metricService.list(condition));
    }


    /**
     * 添加设备传感器指标
     *
     * @author huhu
     * @date  2023/04/12 15:27
     */
    @ApiOperationSupport(order = 2)
    @ApiOperation("添加设备传感器指标")
    @CommonLog("添加设备传感器指标")
    @SaCheckPermission("/iot/metric/add")
    @PostMapping("/iot/metric/add")
    public CommonResult<String> add(@RequestBody @Valid MetricAddParam metricAddParam) {
        if("false".equalsIgnoreCase(metricAddParam.getAutoStart())){
            metricAddParam.setCollectStatus(MetricStatus.STOPPED.name());
        }
        metricService.add(metricAddParam);
        return CommonResult.ok();
    }


    /**
     * 编辑设备传感器指标
     *
     * @author huhu
     * @date  2023/04/12 15:27
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("编辑设备传感器指标")
    @CommonLog("编辑设备传感器指标")
    @SaCheckPermission("/iot/metric/edit")
    @PostMapping("/iot/metric/edit")
    public CommonResult<String> edit(@RequestBody @Valid MetricEditParam metricEditParam) {
        if("false".equalsIgnoreCase(metricEditParam.getAutoStart())){
            metricEditParam.setCollectStatus(MetricStatus.STOPPED.name());
        }
        metricService.edit(metricEditParam);
        return CommonResult.ok();
    }

    /**
     * 删除设备传感器指标
     *
     * @author huhu
     * @date  2023/04/12 15:27
     */
    @ApiOperationSupport(order = 4)
    @ApiOperation("删除设备传感器指标")
    @CommonLog("删除设备传感器指标")
    @SaCheckPermission("/iot/metric/delete")
    @PostMapping("/iot/metric/delete")
    public CommonResult<String> delete(@RequestBody @Valid @NotEmpty(message = "集合不能为空")
                                                   CommonValidList<MetricIdParam> metricIdParamList) {
        metricService.delete(metricIdParamList);
        return CommonResult.ok();
    }

    /**
     * 获取设备传感器指标详情
     *
     * @author huhu
     * @date  2023/04/12 15:27
     */
    @ApiOperationSupport(order = 5)
    @ApiOperation("获取设备传感器指标详情")
    @SaCheckPermission("/iot/metric/detail")
    @GetMapping("/iot/metric/detail")
    public CommonResult<Metric> detail(@Valid MetricIdParam metricIdParam) {
        return CommonResult.data(metricService.detail(metricIdParam));
    }

    @ApiOperationSupport(order = 6)
    @ApiOperation("获取设备传感器指标树")
    @GetMapping("/iot/metric/tree")
    public CommonResult<List<DeviceSensorNode>> tree() {
        return CommonResult.data(metricService.tree());
    }

    @ApiOperationSupport(order = 7)
    @ApiOperation("获取指标信息（包含所属传感器、所属的设备信息）")
    @PostMapping("/iot/metric/full-detail")
    public CommonResult<Object> getMeasurementsDetailByIds(@RequestBody List<String> ids) {
        return CommonResult.data(metricService.getMeasurementsDetailByIds(ids));
    }

    @ApiOperationSupport(order = 8)
    @ApiOperation("获取指标最新采集的值")
    @GetMapping("/iot/metric/latest")
    public CommonResult<Object> getLatestValue(@RequestParam String id) {
        return CommonResult.data(metricService.getLatestValue(id));
    }


    /**
     * 复制指标
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("克隆设备传感器指标")
    @CommonLog("克隆设备传感器指标")
    @SaCheckPermission("/iot/metric/clone")
    @PostMapping("/iot/metric/clone")
    public CommonResult<String> copy(@RequestBody @Valid MetricIdParam idParam) {
        metricService.clone(idParam);
        return CommonResult.ok();
    }

}
