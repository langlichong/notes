package com.genew.iot.modular.collect.core;

import lombok.Builder;
import lombok.Data;

/**
 * 封装数据采集结果
 * @param <D> 数据
 * @param <X> 除数据外，其他参数，如可以使用改参数确认需要推送的服务器、设备等(在推送阶段需要的额外参数)
 */
@Data
@Builder
public class CollectResponse<D,X> {

    @Deprecated
    private D data ;

    @Deprecated
    private X extraParam;

    /**
     * 原始采集请求
     */
    private CollectRequest originRequest;

    /**
     * 采集结果
     */
    private Object collectResult;

    /**
     * 采集结果类型
     *
     * 约束指标采集器返回类型
     * 强烈建议: 所有采集器返回 json 格式，其中json的 key 为指标的名称
     * 采集器采集到的指标值：可能为单指标，也可能为多个指标（如 http 采集到一个 json（多个指标） ，同时业务中确实也需要采集多个指标）
     * 格式示例： 单指标{ "A指标": "A指标的值" } 或 多指标 { "A指标": "A指标的值", "B指标": "B指标的值"}
     * 对于文件采集而言，可能同一个文件中包含了多种指，甚至同一行中就包含多种指标
     *
     */
    private ProcessResultType collectResultType;


}
