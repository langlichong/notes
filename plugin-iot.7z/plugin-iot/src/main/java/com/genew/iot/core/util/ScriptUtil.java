package com.genew.iot.core.util;

import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.graalvm.polyglot.Context;
import org.graalvm.polyglot.Value;

import java.util.Map;
import java.util.Objects;

/**
 * Description:
 *
 * @author js
 * @date Create on 2023/5/8
 */
@Slf4j
public class ScriptUtil {

    protected static final Map<String, Object> jsMap = Maps.newConcurrentMap();

    /**
     * 调用 Graalvm js 执行 js函数
     *
     * @param function JS 函数body内容，由用户在前端自定义
     * @param data     传递给用户自定义JS的参数，一般是直接采集到的原始数据
     * @return 用户自定义脚本执行结果
     */
    public static Value executeJsScripts(String function, String data) {
        log.debug("-- 接口执行脚本处理开始,function:{},data:{}---", function, data);
        Context ctx = (Context) jsMap.get("ctx");
        if (Objects.isNull(ctx)) {
            ctx = Context.newBuilder("js").option("engine.WarnInterpreterOnly", "false").allowAllAccess(true).build();
            // 缓存Context
            jsMap.put("ctx", ctx);
        }
        ctx.eval("js", "function preExtract(param){" + function + " }");
        final Value preExtractFunction = ctx.getBindings("js").getMember("preExtract");
        final Value res = preExtractFunction.execute(data);
        log.debug("-- 接口执行脚本处理结束:{}---", res);
        return res;
    }
}
