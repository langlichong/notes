/*
Copyright [2020] [https://www.xiaonuo.vip]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：

1.请不要删除和修改根目录下的LICENSE文件。
2.请不要删除和修改Snowy源码头部的版权声明。
3.请保留源码和相关描述文件的项目出处，作者声明等。
4.分发源码时候，请注明软件出处 https://gitee.com/xiaonuobase/snowy
5.在修改包名，模块名称，项目代码等时，请注明软件出处 https://gitee.com/xiaonuobase/snowy
6.若您的项目无法满足以上几点，可申请商业授权，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.thirdapi.enums;

import lombok.Getter;

/**
 * 接口管理异常枚举类
 *
 * @author js
 * @date 2023/03/28 10:09
 */
@Getter
public enum IotThirdApiExceptionEnum {
    /**
     * 配置接口返回状态成功
     */
    CONFIG_RESP_STATUS_FAILED(20001, "第三方接口请求失败！"),
    /**
     * 其他异常（除401-token过期异常外），抛出暂不处理
     */
    CONFIG_RESP_STATUS_FAIL_OTHER_EXCEPTION(20002, "非状态为401的第三方接口其他异常！"),
    /**
     * 配置接口返回状态失败：token过期
     */
    CONFIG_RESP_STATUS_FAIL_STATIC_TOKEN_EXPIRED_EXCEPTION(20003, "第三方接口token已过期，请确认静态输入token是否正确！"),
    /**
     * 配置接口返回状态失败：token过期
     */
    CONFIG_RESP_STATUS_FAIL_DYNAMIC_TOKEN_EXPIRED_EXCEPTION(20004, "第三方接口token已过期，请确认JsonPath解析是否正确！"),
    /**
     * 数据不存在
     */
    CONFIG_REQUEST_NOT_PERMISSION(20005, "接口请求无权限！");

    private final Integer code;

    private final String message;

    IotThirdApiExceptionEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

}
