package com.genew.iot.modular.collect.core;

import cn.hutool.extra.spring.SpringUtil;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.modular.collect.processors.Push2TbProcessor;
import com.genew.iot.modular.collect.processors.ScriptProcessor;
import com.genew.iot.modular.collect.processors.SsePusherProcessor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledFuture;
import java.util.function.Consumer;

@Data
@Slf4j
@Component
@NoArgsConstructor
public abstract class AbstractCollector<D,X> {

    /**
     * 采集数据
     * @return
     */
    protected abstract CollectResponse<D,X> collectData() throws DataIntegrationException;


    /**
     * 终止采集
     * @param taskId
     * @return
     */
    protected boolean  abortCollect(TaskId taskId){
        return abortCollectTask(taskId);
    }

    public Boolean abortCollectTask(TaskId taskId) {
        CollectManager collectManager = SpringUtil.getBean(CollectManager.class);
        final Map<TaskId, ScheduledFuture> taskCache = collectManager.getTaskCache();
        if(taskCache.containsKey(taskId)){
            log.info("终止采集指标,指标 id= {}",taskId);
            final ScheduledFuture scheduledFuture = taskCache.remove(taskId);
            final boolean cancelRes = scheduledFuture.cancel(true);
            return cancelRes;
        }
        return true;
    }


    /**
     * 推送数据后: 发送通知或者写入到其他存储空间
     */
    protected  Consumer<CollectResponse<D,X>> afterPush(){
        return r -> {};
    };

    /**
     * 本采集器是否支持 该类型的采集请求
     */
    protected abstract boolean support(CollectRequest request);


    @SneakyThrows
    public final void doCollect()  {
        Push2TbProcessor push2TbProcessor = SpringUtil.getBean(Push2TbProcessor.class);
        SsePusherProcessor ssePusherProcessor = SpringUtil.getBean(SsePusherProcessor.class);
        ScriptProcessor scriptProcessor = SpringUtil.getBean(ScriptProcessor.class);
        CollectResponseProcessorChainBuilder processorChainBuilder = SpringUtil.getBean(CollectResponseProcessorChainBuilder.class);

        final CollectRequest request = CollectContext.getRequest();

        log.debug("协议配置: {}",request.getProtocolConf());

        final CollectResponse response = collectData();

        String udfProcessors = request.getResponseProcessors();

        //1. 指标未配置任何采集结果处理器，则走默认的: 脚本处理器、推送TB处理器、推送到前端SSE的处理器
        if(StringUtils.isBlank(udfProcessors)){
            log.warn("exe default processor chain ");

            final CompletableFuture<ProcessorResult> scriptTask = CompletableFuture.supplyAsync(() -> scriptProcessor
                    .process(response, new ProcessorResult(response.getCollectResult(), response.getCollectResultType())));

            final CompletableFuture<ProcessorResult> tbPusher = scriptTask.thenApplyAsync(result -> push2TbProcessor.process(response, result));
            final CompletableFuture<ProcessorResult> ssePusher = scriptTask.thenApplyAsync(result -> ssePusherProcessor.process(response, result));

        }else{
            // 执行用户选择的所有的处理器
            final AbstractCollectResponseProcessor udfProcessorChain = processorChainBuilder.buildProcessorChainByMetric(request);
            System.out.println("----getCollectResult------" + response.getCollectResult());
            System.out.println("---- response.getCollectResultType()------" + response.getCollectResultType());
            udfProcessorChain.process(
                    response,
                    new ProcessorResult(
                            response.getCollectResult(),
                            response.getCollectResultType()
                    )
            );

            //CompletableFuture.runAsync(() -> );
        }

    }

}
