/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.thirdapi.provider;

import cn.dev33.satoken.exception.NotPermissionException;
import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpStatus;
import cn.hutool.json.JSON;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.genew.common.cache.CommonCacheOperator;
import com.genew.common.pojo.CommonResult;
import com.genew.dev.api.DevDictApi;
import com.genew.form.api.GenFormInterfaceExecuteApi;
import com.genew.iot.api.IotThirdDataQueryApi;
import com.genew.iot.core.constant.IotThirdApiConstant;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.core.param.IotThirdApiQueryParam;
import com.genew.iot.core.util.OkHttpUtil;
import com.genew.iot.core.util.ScriptUtil;
import com.genew.iot.modular.thirdapi.enums.IotThirdApiExceptionEnum;
import com.genew.iot.modular.thirdapi.enums.IotThirdApiMediaTypeEnum;
import com.genew.iot.modular.thirdapi.enums.IotThirdApiSystemEnum;
import com.genew.iot.modular.thirdapi.param.IotThirdApiRequestParam;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import com.genew.sys.api.SysRelationApi;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 接口管理API接口提供者
 *
 * @author js
 * @date 2023/03/28 10:09
 **/
@Service
@Slf4j
public class IotThirdDataQueryProvider implements IotThirdDataQueryApi {

    @Resource
    private IotThirdApiService iotThirdApiService;

    @Resource
    private CommonCacheOperator commonCacheOperator;

    @Resource
    private DevDictApi devDictApi;

    @Resource
    private SysRelationApi sysRelationApi;

    @Resource
    private GenFormInterfaceExecuteApi executeApi;

    protected static final Map<String, Object> tokenMap = Maps.newConcurrentMap();

    private static final Pattern PATH_PATTERN = Pattern.compile("(\\{\\w+\\})");

    /**
     * 查询接口标识主方法
     *
     * @param iotThirdApiQueryParam
     * @return
     */
    @Override
    public Map<String, Object> queryThirdApiData(IotThirdApiQueryParam iotThirdApiQueryParam) {
        String iotThirdApiSign = String.valueOf(iotThirdApiQueryParam.getApiSign());
        IotThirdApi iotThirdApi = iotThirdApiService.queryEntityByApiSign(iotThirdApiSign);
        // 校验三方接口权限
        boolean flag = sysRelationApi.checkPermissionListByTargetId(iotThirdApi.getApiPath());
        if (!flag) {
            throw new NotPermissionException(IotThirdApiExceptionEnum.CONFIG_REQUEST_NOT_PERMISSION.getCode().toString(),
                    "admin");
        }
        iotThirdApi = setIotThirdApiParamData(iotThirdApiQueryParam, iotThirdApi);
        if (ObjectUtil.isNotEmpty(iotThirdApi.getBeforeScripts())) {
            Map map =
                    ScriptUtil.executeJsScripts(iotThirdApi.getBeforeScripts(), JSONUtil.toJsonStr(iotThirdApi)).as(Map.class);
            iotThirdApi = JSONUtil.toBean(JSONUtil.parseObj(map), IotThirdApi.class);
        }
        Map resultMap;
        if (IotThirdApiSystemEnum.SYS_DYNAMIC_SQL.getValue().equals(iotThirdApi.getSystemId())) {
            CommonResult commonResult = (CommonResult) executeApi.genFormInterfaceExecute(iotThirdApi.getApiPath(),
                    iotThirdApiQueryParam.getQueryParam(), iotThirdApiQueryParam.getPathParam(), iotThirdApiQueryParam.getBodyParam());
            return JSONUtil.toBean(JSONUtil.parseObj(commonResult), Map.class);
        } else {
            resultMap = queryThirdApiReturnData(iotThirdApi);
        }
        return resultMap;
    }

    private IotThirdApi setIotThirdApiParamData(IotThirdApiQueryParam iotThirdApiQueryParam, IotThirdApi iotThirdApi) {
        log.info("iotThirdApiQueryParam:{}", iotThirdApiQueryParam);
        if (ObjectUtil.isNotEmpty(iotThirdApiQueryParam.getQueryParam())) {
            Set<String> keys = iotThirdApiQueryParam.getQueryParam().keySet();
            if (!keys.contains("key")) {
                List list =
                        iotThirdApiQueryParam.getQueryParam().entrySet().stream().map(c -> {
                            Map resultMap = Maps.newHashMap();
                            resultMap.put("key", c.getKey());
                            resultMap.put("value", c.getValue());
                            resultMap.put("sign", "REQUIRED");
                            return resultMap;
                        }).collect(Collectors.toList());
                iotThirdApi.setQueryParam(JSONUtil.parseArray(list));
            } else {
                iotThirdApi.setQueryParam(mapToJSONArrayByJSONObject(iotThirdApiQueryParam.getQueryParam()));
            }
        }
        if (ObjectUtil.isNotEmpty(iotThirdApiQueryParam.getAuthParam())) {
            iotThirdApi.setAuthParam(JSONUtil.parseObj(iotThirdApiQueryParam.getAuthParam()));
        }
        if (ObjectUtil.isNotEmpty(iotThirdApiQueryParam.getPathParam())) {
            Set<String> keys = iotThirdApiQueryParam.getPathParam().keySet();
            if (!keys.contains("key")) {
                List list =
                        iotThirdApiQueryParam.getPathParam().entrySet().stream().map(c -> {
                            Map resultMap = Maps.newHashMap();
                            resultMap.put("key", c.getKey());
                            resultMap.put("value", c.getValue());
                            resultMap.put("sign", "REQUIRED");
                            return resultMap;
                        }).collect(Collectors.toList());
                iotThirdApi.setPathParam(JSONUtil.parseArray(list));
            } else {
                iotThirdApi.setPathParam(mapToJSONArrayByJSONObject(iotThirdApiQueryParam.getPathParam()));
            }
        }
        if (ObjectUtil.isNotEmpty(iotThirdApiQueryParam.getHeaderParam())) {
            Set<String> keys = iotThirdApiQueryParam.getHeaderParam().keySet();
            if (!keys.contains("key")) {
                List list =
                        iotThirdApiQueryParam.getHeaderParam().entrySet().stream().map(c -> {
                            Map resultMap = Maps.newHashMap();
                            resultMap.put("key", c.getKey());
                            resultMap.put("value", c.getValue());
                            resultMap.put("sign", "REQUIRED");
                            return resultMap;
                        }).collect(Collectors.toList());
                iotThirdApi.setHeaderParam(JSONUtil.parseArray(list));
            } else {
                iotThirdApi.setHeaderParam(mapToJSONArrayByJSONObject(iotThirdApiQueryParam.getHeaderParam()));
            }
        }
        if (ObjectUtil.isNotEmpty(iotThirdApiQueryParam.getBodyParam())) {
            iotThirdApi.setBodyParam(JSONUtil.parseObj(iotThirdApiQueryParam.getBodyParam()));
        }
        return iotThirdApi;
    }

    private JSONArray mapToJSONArrayByJSONObject(Map<String, Object> map) {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        List<String> keyList = new ArrayList<>(map.keySet());
        for (int i = 0; i < keyList.size(); i++) {
            jsonObject.set(keyList.get(i), map.get(keyList.get(i)));
        }
        jsonArray.add(jsonObject);
        return jsonArray;
    }

    /**
     * 获取接口数据
     *
     * @param iotThirdApi
     * @return
     */
    private Map<String, Object> queryThirdApiReturnData(IotThirdApi iotThirdApi) {
        Map<String, Object> paramMap = Maps.newHashMap();
        JSON queryParam = Optional.ofNullable(iotThirdApi.getQueryParam()).orElse(null);
        JSON headParam = Optional.ofNullable(iotThirdApi.getHeaderParam()).orElse(null);
        JSON pathParam = Optional.ofNullable(iotThirdApi.getPathParam()).orElse(null);
        JSON authParam = Optional.ofNullable(iotThirdApi.getAuthParam()).orElse(null);
        JSON bodyParam = Optional.ofNullable(iotThirdApi.getBodyParam()).orElse(null);
        String jsonPath = Optional.ofNullable(iotThirdApi.getJsonPath()).orElse("");
        List<IotThirdApiRequestParam> headParams = null;
        List<IotThirdApiRequestParam> pathParams = null;
        List<IotThirdApiRequestParam> queryParams = null;
        if (ObjectUtil.isNotEmpty(headParam)) {
            JSONArray jsonArray = JSONUtil.parseArray(JSONUtil.toJsonStr(headParam));
            headParams = jsonArray.toList(IotThirdApiRequestParam.class);
        }
        if (ObjectUtil.isNotEmpty(pathParam)) {
            JSONArray jsonArray = JSONUtil.parseArray(JSONUtil.toJsonStr(pathParam));
            pathParams = jsonArray.toList(IotThirdApiRequestParam.class);
        }
        if (ObjectUtil.isNotEmpty(queryParam)) {
            JSONArray jsonArray = JSONUtil.parseArray(JSONUtil.toJsonStr(queryParam));
            queryParams = jsonArray.toList(IotThirdApiRequestParam.class);
        }
        Map<String, Object> headerParamMap = Maps.newHashMap();
        Map<String, String> pathParamMap = Maps.newHashMap();
        Map<String, Object> queryParamMap = Maps.newHashMap();
        if (ObjectUtil.isNotEmpty(headParams)) {
            headerParamMap = headParams.stream().collect(Collectors.toMap(IotThirdApiRequestParam::getKey,
                    IotThirdApiRequestParam::getValue));
        }
        if (ObjectUtil.isNotEmpty(pathParams)) {
            pathParamMap = pathParams.stream().collect(Collectors.toMap(IotThirdApiRequestParam::getKey,
                    IotThirdApiRequestParam::getValue));
        }
        if (ObjectUtil.isNotEmpty(queryParams)) {
            queryParamMap = queryParams.stream().collect(Collectors.toMap(IotThirdApiRequestParam::getKey,
                    IotThirdApiRequestParam::getValue));
        }
        //构造url
        Map<String, Object> map = createUrl(iotThirdApi, headerParamMap, pathParamMap);
        String url = String.valueOf(map.get("url"));
        //构造请求方式
        String method = String.valueOf(map.get("method"));
        //请求头参数
        Map<String, Object> headerMap = (Map<String, Object>) map.get("headerMap");
        if (ObjectUtil.isNotEmpty(authParam)) {
            Map<String, Object> authParamMap = getToken(JSONUtil.parseObj(authParam));
            paramMap.put("authParamMap", authParamMap);
        }
        //构造请求体信息
        Map<String, Object> bodyParamMap = JSONUtil.parseObj(bodyParam);
        HttpMethod httpMethod = HttpMethod.resolve(method);
        paramMap.put("headerMap", headerMap);
        paramMap.put("queryParamMap", queryParamMap);
        paramMap.put("bodyParamMap", bodyParamMap);
        paramMap.put("jsonPath", jsonPath);
        log.info(">>>请求地址：{}", url);
        log.debug(">>>请求方式：{}", method);
        log.debug(">>>请求参数：{}", paramMap);
        return sendThirdApiHttpRequest(httpMethod, url, paramMap, iotThirdApi);
    }

    /**
     * 构建接口请求URL
     *
     * @param iotThirdApi
     * @param pathParamMap
     * @param headParamMap
     * @return
     */
    private Map<String, Object> createUrl(IotThirdApi iotThirdApi, Map<String, Object> headParamMap,
                                          Map<String, String> pathParamMap) {
        Map<String, Object> map = Maps.newHashMap();
        String apiUrl;
        String apiPath = "";
        if (StrUtil.isNotBlank(iotThirdApi.getApiPath())) {
            if (iotThirdApi.getApiPath().startsWith(StrUtil.SLASH)) {
                apiPath = iotThirdApi.getApiPath();
            } else {
                apiPath = StrUtil.SLASH + iotThirdApi.getApiPath();
            }
        }
        //路径参数
        if (ObjectUtil.isNotEmpty(pathParamMap)) {
            apiUrl = replacePathParams(iotThirdApi.getHost() + StrUtil.COLON + iotThirdApi.getPort() + apiPath, pathParamMap);
        } else {
            apiUrl = iotThirdApi.getHost() + StrUtil.COLON + iotThirdApi.getPort() + apiPath;
        }
        Map<String, List<Map>> dictDataMap = (Map<String, List<Map>>) commonCacheOperator.get("dictDataMap");
        if (Objects.isNull(dictDataMap)) {
            dictDataMap = devDictApi.selectDictData(IotThirdApiConstant.CONFIG_TYPE);
            // 缓存字典数据
            commonCacheOperator.put("dictDataMap", dictDataMap);
        }
        List<Map> schemeData = Lists.newArrayList();
        List<Map> methodData = Lists.newArrayList();
        if (dictDataMap.containsKey(IotThirdApiConstant.CONFIG_SCHEME_TYPE)) {
            schemeData = dictDataMap.get(IotThirdApiConstant.CONFIG_SCHEME_TYPE);
        }
        if (dictDataMap.containsKey(IotThirdApiConstant.CONFIG_REQUEST_MODE)) {
            methodData = dictDataMap.get(IotThirdApiConstant.CONFIG_REQUEST_MODE);
        }
        Map devDict = new ConcurrentHashMap();
        schemeData =
                schemeData.stream().filter(sysDict -> Objects.equals(sysDict.get("dictValue"),
                        iotThirdApi.getApiScheme())).collect(Collectors.toList());
        if (ObjectUtil.isNotEmpty(schemeData)) {
            devDict = schemeData.get(0);
        }
        StringJoiner stringJoiner = new StringJoiner("//", String.valueOf(devDict.get("dictValue")), "");
        stringJoiner.add(StrUtil.COLON).add(apiUrl);
        String method = createHttpMethod(iotThirdApi, methodData);
        Map<String, Object> headerMap = createHeader(headParamMap, iotThirdApi);
        map.put("url", stringJoiner.toString());
        map.put("method", method);
        map.put("headerMap", headerMap);
        return map;
    }

    /**
     * 构建接口请求Header
     *
     * @param headParamMap
     * @param iotThirdApi
     * @return
     */
    private Map<String, Object> createHeader(Map<String, Object> headParamMap, IotThirdApi iotThirdApi) {
        if (ObjectUtil.isEmpty(headParamMap)) {
            headParamMap.put("Content-Type", IotThirdApiMediaTypeEnum.APPLICATION_JSON.getValue());
        }
        // 内部接口赋值系统token
        if (IotThirdApiSystemEnum.SYS_BUILDIN.getValue().equals(iotThirdApi.getSystemId())) {
            headParamMap.put("token", StpUtil.getTokenInfo().tokenValue);
        }
        return headParamMap;
    }

    /**
     * 构建接口请求方法
     *
     * @param iotThirdApi
     * @param sysDictHttpMethodData
     * @return
     */
    private String createHttpMethod(IotThirdApi iotThirdApi, List<Map> sysDictHttpMethodData) {
        Map devDict = new ConcurrentHashMap();
        List<Map> methodData =
                sysDictHttpMethodData.stream().filter(sysDict -> Objects.equals(sysDict.get("dictValue"),
                        iotThirdApi.getRequestMode())).collect(Collectors.toList());
        if (ObjectUtil.isNotEmpty(methodData)) {
            devDict = methodData.get(0);
        }
        return (String) devDict.get("dictValue");
    }

    /**
     * 组装OkHttp请求
     *
     * @param httpMethod
     * @param url
     * @param paramMap
     * @param iotThirdApi
     * @return
     */
    private Map<String, Object> sendThirdApiHttpRequest(HttpMethod httpMethod, String url, Map<String, Object> paramMap, IotThirdApi iotThirdApi) {
        Map<String, Object> headerMap = (Map<String, Object>) paramMap.get("headerMap");
        Map<String, Object> queryParamMap = (Map<String, Object>) paramMap.get("queryParamMap");
        Map<String, Object> authParamMap = (Map<String, Object>) paramMap.get("authParamMap");
        Map<String, Object> bodyParamMap = (Map<String, Object>) paramMap.get("bodyParamMap");
        boolean flag = true;
        for (String key : headerMap.keySet()) {
            if (Objects.equals(IotThirdApiMediaTypeEnum.APPLICATION_FORM.getValue(), headerMap.get(key))) {
                flag = false;
                break;
            }
        }
        OkHttpUtil okHttpUtil = new OkHttpUtil();
        Map<String, Object> responseMap = Maps.newHashMap();
        try {
            // 枚举请求方式
            switch (httpMethod) {
                case GET:
                    responseMap = okHttpUtil.builder().url(url)
                            .addParams(queryParamMap == null ? Maps.newHashMap() : queryParamMap)
                            .addParams(bodyParamMap == null ? Maps.newHashMap() : bodyParamMap)
                            .addHeaders(authParamMap == null ? Maps.newHashMap() : authParamMap)
                            .addHeaders(headerMap)
                            .get()
                            // 可选择是同步请求还是异步请求
                            .sync();
                    break;
                case POST:
                    responseMap = okHttpUtil.builder().url(url)
                            .addParams(queryParamMap == null ? Maps.newHashMap() : queryParamMap)
                            .addParams(bodyParamMap == null ? Maps.newHashMap() : bodyParamMap)
                            .addHeaders(authParamMap == null ? Maps.newHashMap() : authParamMap)
                            .addHeaders(headerMap)
                            .post(flag)
                            // 可选择是同步请求还是异步请求
                            .sync();
                    break;
                case PUT:
                    //todo PUT方法
                    break;
                case DELETE:
                    //todo DELETE方法
                    break;
                case PATCH:
                    //todo PATCH方法
                    break;
                case HEAD:
                    //todo HEAD方法
                    break;
                default:
            }
        } catch (IOException e) {
            log.error("查询第三方接口数据异常:{}", e.getMessage());
        }

        return dealResponseResult(responseMap, httpMethod, url, paramMap, iotThirdApi);
    }

    /**
     * 处理三方接口返回数据
     *
     * @param responseMap
     * @param httpMethod
     * @param url
     * @param paramMap
     * @param iotThirdApi
     * @return
     */
    private Map<String, Object> dealResponseResult(Map<String, Object> responseMap, HttpMethod httpMethod, String url, Map<String, Object> paramMap, IotThirdApi iotThirdApi) {
        log.debug("第三方接口请求返回:{}", responseMap);
        if (Objects.isNull(responseMap.get(IotThirdApiConstant.CODE))) {
            return responseMap;
        }
        int status = Integer.parseInt(String.valueOf(responseMap.get(IotThirdApiConstant.CODE)));
        Object jsonObject = responseMap.get(IotThirdApiConstant.DATA);
        String jsonPath = String.valueOf(paramMap.get("jsonPath"));
        Map<String, Object> authParamMap = (Map<String, Object>) paramMap.get("authParamMap");
        if (IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAILED.getCode().equals(status)) {
            return responseMap;
        }
        // 返回正常
        if (HttpStatus.HTTP_OK == status) {
            if (ObjectUtil.isNotEmpty(iotThirdApi.getAfterScripts())) {
                jsonObject =
                        ScriptUtil.executeJsScripts(iotThirdApi.getAfterScripts(), JSONUtil.toJsonStr(jsonObject)).as(Object.class);
            }
            if (Objects.nonNull(iotThirdApi.getRespStatus())) {
                responseMap.put(IotThirdApiConstant.CODE, iotThirdApi.getRespStatus());
            } else {
                responseMap.put(IotThirdApiConstant.CODE, HttpStatus.HTTP_OK);
            }
            responseMap.put(IotThirdApiConstant.MESSAGE, "第三方接口请求成功！");
            String token;
            if (StrUtil.isNotBlank(jsonPath)) {
                //获取token接口返参
                token = getResponseToken(JSONUtil.toJsonStr(jsonObject), jsonPath);
                if (Objects.isNull(tokenMap.get(IotThirdApiConstant.CONFIG_CACHE_TOKEN_KEY + StrUtil.UNDERLINE + iotThirdApi.getSystemId())) && StrUtil.isNotBlank(token)) {
                    log.debug(">>>获取token:{}", token);
                    // 缓存认证参数authParamMap在内存中，便于其他接口无需获取直接使用
                    tokenMap.put(IotThirdApiConstant.CONFIG_CACHE_TOKEN_KEY + StrUtil.UNDERLINE + iotThirdApi.getSystemId(), token);
                }
                responseMap.put(IotThirdApiConstant.DATA, token);
            } else {
                responseMap.put(IotThirdApiConstant.DATA, JSONUtil.parse(jsonObject));
            }
            return responseMap;
        }
        if (HttpStatus.HTTP_OK != status
                && StringUtils.isNotBlank(iotThirdApi.getStaticRespJson())) {
            if (Objects.nonNull(iotThirdApi.getRespStatus())) {
                responseMap.put(IotThirdApiConstant.CODE, iotThirdApi.getRespStatus());
            } else {
                responseMap.put(IotThirdApiConstant.CODE, HttpStatus.HTTP_OK);
            }
            responseMap.put(IotThirdApiConstant.DATA, JSONUtil.parse(iotThirdApi.getStaticRespJson()));
            responseMap.put(IotThirdApiConstant.MESSAGE, "第三方接口请求成功！");
            return responseMap;
        }
        responseMap.put("data", JSONUtil.parse(jsonObject));
        // token过期返回处理
        if (HttpStatus.HTTP_UNAUTHORIZED == status) {
            if (Objects.nonNull(authParamMap) &&
                    IotThirdApiConstant.CONFIG_TOKEN_TYPE_DYNAMIC.equals(authParamMap.get("tokenType"))) {
                // token过期处理：调用刷新token接口获取token
                Map<String, Object> refreshTokenUrlMap = (Map<String, Object>) authParamMap.get("refreshTokenUrlMap");
                if (ObjectUtil.isNotEmpty(refreshTokenUrlMap)) {
                    paramMap = refreshToken(paramMap, refreshTokenUrlMap);
                    //请求重试
                    return sendThirdApiHttpRequest(httpMethod, url, paramMap, iotThirdApi);
                }
                responseMap.put(IotThirdApiConstant.CODE, IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAIL_DYNAMIC_TOKEN_EXPIRED_EXCEPTION.getCode());
                responseMap.put(IotThirdApiConstant.MESSAGE, IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAIL_DYNAMIC_TOKEN_EXPIRED_EXCEPTION.getMessage());
            } else {
                responseMap.put(IotThirdApiConstant.CODE, IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAIL_STATIC_TOKEN_EXPIRED_EXCEPTION.getCode());
                responseMap.put(IotThirdApiConstant.MESSAGE, IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAIL_STATIC_TOKEN_EXPIRED_EXCEPTION.getMessage());
            }
            return responseMap;
        }
        // 返回404,502,503
        if (HttpStatus.HTTP_NOT_FOUND == status || HttpStatus.HTTP_BAD_GATEWAY == status || HttpStatus.HTTP_UNAVAILABLE == status) {
            responseMap.put(IotThirdApiConstant.CODE, IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAILED.getCode());
            responseMap.put(IotThirdApiConstant.MESSAGE, IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAILED.getMessage());
            return responseMap;
        }
        // 返回其他异常
        responseMap.put(IotThirdApiConstant.CODE, IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAIL_OTHER_EXCEPTION.getCode());
        responseMap.put(IotThirdApiConstant.MESSAGE, IotThirdApiExceptionEnum.CONFIG_RESP_STATUS_FAIL_OTHER_EXCEPTION.getMessage());
        return responseMap;
    }

    /**
     * 处理返回token
     *
     * @param json
     * @param jsonPath
     * @return
     */
    private String getResponseToken(String json, String jsonPath) {
        String token = "";
        if (StrUtil.isBlank(jsonPath) || ObjectUtil.isEmpty(json)) {
            return StrUtil.EMPTY;
        }
        token = OkHttpUtil.readJsonPathOrElseNull(json, jsonPath);
        if (StrUtil.isBlank(token)) {
            return StrUtil.EMPTY;
        }
        return token;
    }

    /**
     * 封装动态获取参数
     *
     * @param authParamMap
     * @return
     */
    private Map<String, Object> dynamicQueryToken(Map<String, Object> authParamMap) {
        Map<String, Object> authMap = Maps.newHashMap();
        // 动态获取
        Map<String, Object> getTokenUrlMap = (Map<String, Object>) authParamMap.get("getTokenUrlMap");
        return getTokenMap(authParamMap, authMap, getTokenUrlMap);
    }

    /**
     * 认证参数处理
     *
     * @param authParamMap
     * @param authMap
     * @param tokenUrlMap
     * @return
     */
    private Map<String, Object> getTokenMap(Map<String, Object> authParamMap, Map<String, Object> authMap, Map<String, Object> tokenUrlMap) {
        String tokenKey = String.valueOf(authParamMap.get("tokenKey"));
        String tokenType = String.valueOf(authParamMap.get("tokenType"));
        IotThirdApiQueryParam iotThirdApiQueryParam = new IotThirdApiQueryParam();
        iotThirdApiQueryParam.setApiSign(String.valueOf(tokenUrlMap.get(IotThirdApiConstant.CODE)));
        IotThirdApi iotThirdApi = iotThirdApiService.queryEntityByApiSign(iotThirdApiQueryParam.getApiSign());
        Map<String, Object> responseMap;
        String responseJson;
        if (Objects.isNull(tokenMap.get(IotThirdApiConstant.CONFIG_CACHE_TOKEN_KEY + StrUtil.UNDERLINE + iotThirdApi.getSystemId()))) {
            responseMap = iotThirdApiService.queryThirdApiData(iotThirdApiQueryParam);
            responseJson = String.valueOf(responseMap.get(IotThirdApiConstant.DATA));
        } else {
            responseJson =
                    String.valueOf(tokenMap.get(IotThirdApiConstant.CONFIG_CACHE_TOKEN_KEY + StrUtil.UNDERLINE + iotThirdApi.getSystemId()));
        }
        String authMethodValue = String.valueOf(authParamMap.get("authMethodValue"));
        if (StringUtils.isBlank(iotThirdApi.getJsonPath())) {
            authMap.put("tokenType", tokenType);
        } else {
            //获取token接口封装认证参数
            authMap.put(tokenKey, authMethodValue + StrUtil.C_SPACE + responseJson);
        }
        return authMap;
    }

    /**
     * 刷新token
     *
     * @param authParamMap
     * @param tokenUrlMap
     * @return
     */
    private Map<String, Object> refreshToken(Map<String, Object> authParamMap, Map<String, Object> tokenUrlMap) {
        Map<String, Object> authMap = Maps.newHashMap();
        return getTokenMap(authParamMap, authMap, tokenUrlMap);
    }

    /**
     * 获取认证参数主方法
     *
     * @param authParamMap
     * @return
     */
    private Map<String, Object> getToken(Map<String, Object> authParamMap) {
        Map<String, Object> authMap = Maps.newHashMap();
        String tokenType = String.valueOf(authParamMap.get("tokenType"));
        if (IotThirdApiConstant.CONFIG_TOKEN_TYPE_STATIC.equals(tokenType)) {
            // 静态输入
            log.debug(">>>静态输入入参:{}", authParamMap);
            authMap = staticInputToken(authParamMap);
        } else if (IotThirdApiConstant.CONFIG_TOKEN_TYPE_DYNAMIC.equals(tokenType)) {
            // 动态获取
            log.debug(">>>动态获取入参:{}", authParamMap);
            authMap = dynamicQueryToken(authParamMap);
        }
        return authMap;
    }

    /**
     * 封装静态获取token参数
     *
     * @param authParamMap
     * @return
     */
    private Map<String, Object> staticInputToken(Map<String, Object> authParamMap) {
        Map<String, Object> authMap = Maps.newHashMap();
        String tokenType = String.valueOf(authParamMap.get("tokenType"));
        // 静态输入
        String authMethodValue = String.valueOf(authParamMap.get("authMethodValue"));
        if (Objects.nonNull(authParamMap) && StrUtil.isNotBlank(authMethodValue)) {
            for (Map.Entry<String, Object> entryValue : authParamMap.entrySet()) {
                for (Map.Entry<String, Object> entryKey : authParamMap.entrySet()) {
                    if (Objects.equals("tokenKey", entryKey.getKey())
                            && ObjectUtil.isNotEmpty(entryKey.getValue())
                            && Objects.equals("tokenValue", entryValue.getKey())
                            && ObjectUtil.isNotEmpty(entryValue.getValue())) {
                        authMap.put(String.valueOf(entryKey.getValue()), authMethodValue + StrUtil.C_SPACE + entryValue.getValue());
                    }
                }
            }
        } else {
            authMap.put("tokenType", tokenType);
        }
        return authMap;
    }

    /**
     * 请求url带PathVariable的处理
     *
     * @param url
     * @param pathParamMap
     * @return
     */
    private String replacePathParams(String url, Map<String, String> pathParamMap) {
        Matcher m = PATH_PATTERN.matcher(url);
        String apiUrl = url;
        while (m.find()) {
            String val1 = m.group().replace("{", "").replace("}", "");
            for (String pathParamKey : pathParamMap.keySet()) {
                if (pathParamKey.equals(val1)) {
                    apiUrl = url.replace(m.group(), pathParamMap.get(pathParamKey));
                }
            }
        }
        return apiUrl;
    }
}
