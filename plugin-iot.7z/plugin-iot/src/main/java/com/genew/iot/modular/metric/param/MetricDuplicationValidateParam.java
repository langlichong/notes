package com.genew.iot.modular.metric.param;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
@Builder
public class MetricDuplicationValidateParam implements Serializable {

    /**
     * 指标名称
     */
    @NotBlank(message = "指标名称不能为空")
    private String metricName;

    /**
     * 指标属主类型
     */
    private String ownerType;

    /**
     * 指标属主ID
     */
    private String ownerId;


}
