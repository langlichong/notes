package com.genew.iot.modular.thirdapi.listener;

import cn.hutool.json.JSONArray;
import com.genew.common.listener.CommonDataChangeListener;
import com.genew.iot.core.enums.IotDataTypeEnum;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 监听动态sql事件
 *
 * @author js
 */
@Slf4j
@Component
public class DynamicSqlChangeListener implements CommonDataChangeListener {

    @Resource
    private IotThirdApiService iotThirdApiService;

    @Override
    public void doAddWithDataList(String dataType, JSONArray jsonArray) {
    }

    @Override
    public void doUpdateWithDataList(String dataType, JSONArray jsonArray) {
        if (dataType.equals(IotDataTypeEnum.DYNAMIC_SQL.getValue())) {
            //todo 更新通用接口列表时，需要更新原有接口路径
        }
    }

    @Override
    public void doDeleteWithDataIdList(String dataType, List<String> dataIdList) {
        if (dataType.equals(IotDataTypeEnum.DYNAMIC_SQL.getValue())) {
            //todo 删除通用接口列表时，需要清空原有接口路径
        }
    }

    @Override
    public void doAddWithDataIdList(String dataType, List<String> dataIdList) {

    }

    @Override
    public void doUpdateWithDataIdList(String dataType, List<String> dataIdList) {

    }
}
