package com.genew.iot.modular.collect.processors;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.genew.dev.api.DevSseApi;
import com.genew.iot.modular.collect.core.*;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Objects;

/**
 * 通过 H5 SSE技术  推送到前端 UI
 */
@Slf4j
@Component
public class SsePusherProcessor extends AbstractCollectResponseProcessor {

    @Resource
    private DevSseApi devSseApi;

    @Override
    public String id() {
        return "ssePusherProcessor";
    }

    @Override
    public String name() {
        return "推送到SSE";
    }


    @Override
    public boolean support(CollectResponse response) {
        // 所有情况都支持
        return true;
    }

    @Override
    public ProcessorResult doProcess(CollectResponse response, ProcessorResult previousResult) {

        final Object metricValue = previousResult.getResult();
        if (Objects.isNull(metricValue)) {
            return previousResult;
        }
        final ProcessResultType resultType = previousResult.getResultType();
        // todo SSE推送的指标值应该来自同一个地方，如 一个指标值队列（要求指标裸值需要在采集完之后直接异步发送到队列）
        log.info("---SsePusherProcessor---");
        if (support(response)) {
            final CollectRequest originRequest = response.getOriginRequest();
            Map map = Maps.newConcurrentMap();
            switch (resultType) {
                case PRIMITIVE:
                case JSON:
                case JSON_STRING:
                    log.info(" --- 推送UI = {}", metricValue);
                    map.put("id", originRequest.getId());
                    map.put("value", metricValue);
                    //发送消息
                    devSseApi.sendMessageToAllClient(JSONUtil.toJsonStr(map));
                    break;
                case JSONARRY:
                case JSONARRY_STRING:
                    JSONArray arrayValue = JSONUtil.parseArray(metricValue);
                    for (int i = 0; i < arrayValue.size(); i++) {
                        final JSONObject telemetries = arrayValue.getJSONObject(i);
                        log.info(" --- 推送UI = {}", telemetries);
                        //发送消息
                        map.put("id", originRequest.getId());
                        map.put("value", telemetries);
                        devSseApi.sendMessageToAllClient(JSONUtil.toJsonStr(map));
                    }
                    break;
            }

        }

        return previousResult;
    }

    @Override
    public int getOrder() {
        return 1;
    }
}
