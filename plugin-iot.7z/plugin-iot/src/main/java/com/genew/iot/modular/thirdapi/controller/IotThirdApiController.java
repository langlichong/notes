/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.thirdapi.controller;

import cn.dev33.satoken.annotation.SaCheckPermission;
import cn.hutool.json.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.common.pojo.CommonValidList;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.core.param.IotThirdApiQueryParam;
import com.genew.iot.modular.thirdapi.param.*;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * 接口管理控制器
 *
 * @author js
 * @date 2023/03/27 14:22
 */
@Api(tags = "接口管理控制器")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
public class IotThirdApiController {

    @Resource
    private IotThirdApiService iotThirdApiService;

    /**
     * 获取接口管理分页
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取接口管理分页")
    @SaCheckPermission("/iot/thirdapi/page")
    @GetMapping("/iot/thirdapi/page")
    public CommonResult<Page<IotThirdApi>> page(IotThirdApiPageParam iotThirdApiPageParam) {
        return CommonResult.data(iotThirdApiService.page(iotThirdApiPageParam));
    }

    /**
     * 获取接口管理分页
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 2)
    @ApiOperation("获取接口管理列表")
    @SaCheckPermission("/iot/thirdapi/list")
    @GetMapping("/iot/thirdapi/list")
    public CommonResult<List<IotThirdApi>> list(IotThirdApiListParam iotThirdApiListParam) {
        return CommonResult.data(iotThirdApiService.list(iotThirdApiListParam));
    }

    /**
     * 添加接口管理
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("添加接口管理")
    @CommonLog("添加接口管理")
    @SaCheckPermission("/iot/thirdapi/add")
    @PostMapping("/iot/thirdapi/add")
    public CommonResult<String> add(@RequestBody @Valid IotThirdApiAddParam iotThirdApiAddParam) {
        iotThirdApiService.add(iotThirdApiAddParam);
        return CommonResult.ok();
    }

    /**
     * 复制接口
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 4)
    @ApiOperation("复制接口")
    @CommonLog("复制接口")
    @SaCheckPermission("/iot/thirdapi/copy")
    @PostMapping("/iot/thirdapi/copy")
    public CommonResult<String> copy(@RequestBody @Valid IotThirdApiAddParam iotThirdApiAddParam) {
        iotThirdApiService.copy(iotThirdApiAddParam);
        return CommonResult.ok();
    }

    /**
     * 编辑接口管理
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 5)
    @ApiOperation("编辑接口管理")
    @CommonLog("编辑接口管理")
    @SaCheckPermission("/iot/thirdapi/edit")
    @PostMapping("/iot/thirdapi/edit")
    public CommonResult<String> edit(@RequestBody @Valid IotThirdApiEditParam iotThirdApiEditParam) {
        iotThirdApiService.edit(iotThirdApiEditParam);
        return CommonResult.ok();
    }

    /**
     * 删除接口管理
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 6)
    @ApiOperation("删除接口管理")
    @CommonLog("删除接口管理")
    @SaCheckPermission("/iot/thirdapi/delete")
    @PostMapping("/iot/thirdapi/delete")
    public CommonResult<String> delete(@RequestBody @Valid @NotEmpty(message = "集合不能为空")
                                               CommonValidList<IotThirdApiIdParam> iotThirdApiIdParamList) {
        iotThirdApiService.delete(iotThirdApiIdParamList);
        return CommonResult.ok();
    }

    /**
     * 获取接口管理详情
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 7)
    @ApiOperation("获取接口管理详情")
    @SaCheckPermission("/iot/thirdapi/detail")
    @GetMapping("/iot/thirdapi/detail")
    public CommonResult<IotThirdApi> detail(@Valid IotThirdApiIdParam iotThirdApiIdParam) {
        return CommonResult.data(iotThirdApiService.detail(iotThirdApiIdParam));
    }

    /**
     * 获取三方接口数据
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 8)
    @ApiOperation("获取三方接口数据")
    @SaCheckPermission("/iot/thirdapi/queryThirdApiData")
    @PostMapping("/iot/thirdapi/queryThirdApiData")
    //@CommonNoRepeat
    public Map<String, Object> queryThirdApiData(@RequestBody @Valid IotThirdApiQueryParam iotThirdApiQueryParam) {
        return iotThirdApiService.queryThirdApiData(iotThirdApiQueryParam);
    }

    /**
     * 设备台账-导入模板下载
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 9)
    @ApiOperation("下载设备导入模板")
    @CommonLog("下载用户导入模板")
    @GetMapping(value = "/iot/thirdapi/template", produces = MediaType.APPLICATION_JSON_VALUE)
    public CommonResult<String> downloadImportTemplate(HttpServletResponse response) throws IOException {
        iotThirdApiService.downloadImportTemplate(response);
        return CommonResult.ok();
    }


    /**
     * 设备台账-批量导入
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 10)
    @ApiOperation("设备台账-批量导入")
    @CommonLog("设备台账-批量导入")
    @PostMapping("/iot/thirdapi/import")
    public CommonResult<JSONObject> importBatchIotThirdApi(@RequestPart("file") @ApiParam(value = "文件",
            required = true) MultipartFile file) {
        return CommonResult.data(iotThirdApiService.importBatchIotThirdApi(file));
    }

    /**
     * 设备导出
     *
     * @author js
     * @date 2023/03/27 14:22
     */
    @ApiOperationSupport(order = 11)
    @ApiOperation("设备信息导出")
    @CommonLog("设备信息导出")
    @GetMapping(value = "/iot/thirdapi/export", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public void exportBatchIotThirdApi(IotThirdApiListParam iotThirdApiListParam, HttpServletResponse response) throws IOException {
        iotThirdApiService.exportBatchIotThirdApi(iotThirdApiListParam, response);
    }

    /**
     * 停止接口管理定时任务
     *
     * @author js
     * @date 2023/03/27 14:22
     **/
    @ApiOperationSupport(order = 12)
    @ApiOperation("停止接口管理定时任务")
    @CommonLog("停止接口管理定时任务")
    @PostMapping("/iot/thirdapi/stopJob")
    public CommonResult<String> stopJob(@RequestBody IotThirdApi iotThirdApi) {
        iotThirdApiService.stopJob(iotThirdApi);
        return CommonResult.ok();
    }

    /**
     * 运行接口管理定时任务
     *
     * @author js
     * @date 2023/03/27 14:22
     **/
    @ApiOperationSupport(order = 13)
    @ApiOperation("运行接口管理定时任务")
    @CommonLog("运行接口管理定时任务")
    @PostMapping("/iot/thirdapi/runJob")
    public CommonResult<String> runJob(@RequestBody @Valid IotThirdApi iotThirdApi) {
        iotThirdApiService.runJob(iotThirdApi);
        return CommonResult.ok();
    }

    /**
     * 立即运行定时任务
     *
     * @author js
     * @date 2023/03/27 14:22
     **/
    @ApiOperationSupport(order = 14)
    @ApiOperation("立即运行定时任务")
    @CommonLog("立即运行定时任务")
    @PostMapping("/iot/thirdapi/runJobNow")
    public CommonResult<String> runJobNow(@RequestBody @Valid IotThirdApiSignParam iotThirdApiSignParam) {
        iotThirdApiService.runJobNow(iotThirdApiSignParam);
        return CommonResult.ok();
    }

}
