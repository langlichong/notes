package com.genew.iot.modular.collect.customized.ba4;

import lombok.Data;

import java.util.Arrays;

/**
 * @author : renqiang
 * @date : 2023-03-20 15:01
 * @description : 本安4 路 数据包
 */
@Data
public class BaDataBody {

    /**
     * 地址
     */
    private byte address;

    /**
     * 第一个固定位（第二个字节）
     */
    private byte secondFixed;

    /**
     * 第二个固定位（第三个字节）
     */
    private byte thirdlyFixed;

    /**
     * 数据内容
     */
    private byte[] data;

    /**
     * crc
     */
    private byte[] crc;


    @Override
    public String toString() {
        return "BaDataBody{" +
                "address=" + Byte.toUnsignedInt(address) +
                ", secondFixed=" + Byte.toUnsignedInt(secondFixed) +
                ", thirdlyFixed=" + Byte.toUnsignedInt(thirdlyFixed) +
                ", data=" + Arrays.toString(data) +
                ", crc=" + Arrays.toString(crc) +
                '}';
    }
}
