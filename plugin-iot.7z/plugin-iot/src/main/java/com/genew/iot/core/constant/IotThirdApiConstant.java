package com.genew.iot.core.constant;

/**
 * 接口管理常量类
 *
 * @author js
 * @date 2023/03/28 10:09
 */
public class IotThirdApiConstant {
    /**
     * 字典类型常量->记录字典类型以api_结尾
     */
    public static final String CONFIG_TYPE = "API_";
    /**
     * 字典类型常量->协议类型：HTTP、HTTPS、FTP
     */
    public static final String CONFIG_SCHEME_TYPE = "API_SCHEME_TYPE";
    /**
     * 字典类型常量->请求方式：GET、POST....
     */
    public static final String CONFIG_REQUEST_MODE = "API_REQUEST_MODE";
    /**
     * 常量->静态输入
     */
    public static final String CONFIG_TOKEN_TYPE_STATIC = "STATIC_INPUT";
    /**
     * 常量->动态获取
     */
    public static final String CONFIG_TOKEN_TYPE_DYNAMIC = "DYNAMIC_GET";
    /**
     * 假如设置为3次重试的话，则最大可能请求4次（默认1次+3次重试）
     */
    public static final int RETRY_NUM = 0;
    /**
     * 缓存tokenKey
     */
    public static final String CONFIG_CACHE_TOKEN_KEY = "accessToken";

    /**
     * 接口重试配置-连接超时
     */
    public static final String RETRY_CONNECT_TIMEOUT = "RETRY_CONNECT_TIMEOUT";

    /**
     * 接口重试配置-写入超时
     */
    public static final String RETRY_WRITE_TIMEOUT = "RETRY_WRITE_TIMEOUT";

    /**
     * 接口重试配置-读取超时
     */
    public static final String RETRY_READ_TIMEOUT = "RETRY_READ_TIMEOUT";

    /**
     * 接口重试配置-最大重试次数
     */
    public static final String RETRY_MAX_TIMES = "RETRY_MAX_TIMES";

    /**
     * 接口重试配置-是否自动重连
     */
    public static final String RETRY_AUTO_CONNECT = "RETRY_AUTO_CONNECT";
    /**
     * 接口添加异常返回
     */
    public static final String API_ADD_EXCEPTIONS = "already exists";

    /**
     * code
     */
    public static final String CODE = "code";

    /**
     * message
     */
    public static final String MESSAGE = "message";

    /**
     * message
     */
    public static final String DATA = "data";

}
