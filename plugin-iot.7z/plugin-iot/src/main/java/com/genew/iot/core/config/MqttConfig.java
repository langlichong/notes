package com.genew.iot.core.config;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * 功能描述: 配置类
 *
 * @Author js
 * @Date 2023/07/04
 */
@Getter
@Setter
@Builder
public class MqttConfig {

    /**
     * 服务器地址url
     */
    private String host;

    /**
     * 用户名
     */
    private String username;

    /**
     * 密码
     */
    private String password;

    /**
     * 超时时间
     */
    private Integer timeout;

    /**
     * 保活时间
     */
    private Integer interval;

    /**
     * 是否清除会话
     */
    private boolean clearSession;
    /**
     * 订阅主题
     */
    private String topic;
    /**
     * 消息质量数组
     */
    private int qos;
}
