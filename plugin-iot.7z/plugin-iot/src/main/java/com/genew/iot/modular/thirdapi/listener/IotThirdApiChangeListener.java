package com.genew.iot.modular.thirdapi.listener;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONArray;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.genew.common.listener.CommonDataChangeListener;
import com.genew.iot.core.entity.IotThirdApi;
import com.genew.iot.core.enums.IotDataTypeEnum;
import com.genew.iot.modular.thirdapi.service.IotThirdApiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 监听接口管理设备事件
 *
 * @author js
 */
@Slf4j
@Component
public class IotThirdApiChangeListener implements CommonDataChangeListener {

    @Resource
    private IotThirdApiService iotThirdApiService;

    @Override
    public void doAddWithDataIdList(String dataType, List<String> dataIdList) {

    }

    @Override
    public void doAddWithDataList(String dataType, JSONArray jsonArray) {

    }

    @Override
    public void doUpdateWithDataIdList(String dataType, List<String> dataIdList) {

    }

    @Override
    public void doUpdateWithDataList(String dataType, JSONArray jsonArray) {

    }

    /**
     * 如果检测到设备已删除，则清空接口管理设备id
     *
     * @param dataType   数据类型，如USER、ORG，自行定义
     * @param dataIdList 被删除的数据ID集合
     */
    @Override
    public void doDeleteWithDataIdList(String dataType, List<String> dataIdList) {
        // 监听设备删除事件，清空接口设备ID
        if (dataType.equals(IotDataTypeEnum.DEVICE.getValue())) {
            UpdateWrapper<IotThirdApi> updateWrapper = new UpdateWrapper<>();
            updateWrapper.lambda().in(IotThirdApi::getTimingEntityId, dataIdList);
            updateWrapper.lambda().set(IotThirdApi::getTimingEntityId, StrUtil.EMPTY);
            iotThirdApiService.update(updateWrapper);
        }
    }
}
