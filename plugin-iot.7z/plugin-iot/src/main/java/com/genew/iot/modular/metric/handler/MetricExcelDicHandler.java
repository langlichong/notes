package com.genew.iot.modular.metric.handler;

import cn.afterturn.easypoi.handler.inter.IExcelDictHandler;
import cn.hutool.json.JSONObject;
import com.genew.dbs.core.entity.DsSource;
import com.genew.iot.modular.collect.core.ProcessResultType;
import com.genew.iot.modular.device.entity.Device;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@NoArgsConstructor
public class MetricExcelDicHandler implements IExcelDictHandler {

    private List<JSONObject> dataTypes;

    private List<Device> devices ;

    private List<DsSource> dataSourceList ;

    private List<JSONObject> dataCollectionType ;

    public MetricExcelDicHandler(List<Device> devices, List<JSONObject> dataTypes, List<DsSource> dataSourceList, List<JSONObject> dataCollectionType){

        this.dataTypes = dataTypes;
        this.devices = devices;
        this.dataSourceList = dataSourceList;
        this.dataCollectionType = dataCollectionType;
    }

    @Override
    public List<Map> getList(String dict) {

        List<Map> list = new ArrayList<>();
       if("device".equalsIgnoreCase(dict)){
            this.devices.forEach( item -> {
                Map<String, String> dictMap = new HashMap<>();
                dictMap.put("dictKey", item.getId());
                dictMap.put("dictValue", item.getName());

                list.add(dictMap);
            });
        }else if("dataType".equalsIgnoreCase(dict)){
            this.dataTypes.forEach( item -> {
                Map<String, String> dictMap = new HashMap<>();
                dictMap.put("dictKey", item.getStr("dictValue"));
                dictMap.put("dictValue", item.getStr("dictLabel"));

                list.add(dictMap);
            });
        } else if ("protocol".equals(dict)) {
           this.dataCollectionType.forEach( item -> {
               Map<String, String> dictMap = new HashMap<>();
               dictMap.put("dictKey", item.getStr("dictValue"));
               dictMap.put("dictValue", item.getStr("dictLabel"));

               list.add(dictMap);
           });
       }else if ("ds".equals(dict)) {
           this.dataSourceList.forEach( item -> {
               Map<String, String> dictMap = new HashMap<>();
               dictMap.put("dictKey", item.getId());
               dictMap.put("dictValue", item.getDsName());

               list.add(dictMap);
           });
       }else if("scriptRtType".equals(dict)){
           final ProcessResultType[] values = ProcessResultType.values();
           for (ProcessResultType rtType : values) {
               Map<String,String> option = new HashMap<>();
               option.put("dictKey",rtType.getValue());
               option.put("dictValue", rtType.getName());
               list.add(option);
           }



       }

        return list;
    }

    // 导出用到
    @Override
    public String toName(String dict, Object obj, String name, Object value) {
        if ("owner".equals(dict)) {
            final String val = value.toString();
            switch (val) {
                case "BUILDIN":
                    return "内部";
                default:
                    return "";
            }
        }
        return null;
    }

    // 导入用到
    @Override
    public String toValue(String dict, Object obj, String name, Object value) {

        String valueStr = String.valueOf(value);
        if("device".equalsIgnoreCase(dict)){

            final Device target = this.devices.stream().filter(device -> valueStr.equals(device.getName())).findFirst().orElse(null);
            if(target != null) {
                return target.getId();
            }
        }else if("dataType".equalsIgnoreCase(dict)){

            final JSONObject target = this.dataTypes.stream().filter(json -> valueStr.equals(json.getStr("dictLabel"))).findFirst().orElse(null);

            if(target != null){
                return target.getStr("dictValue");
            }
        }else if("ds".equalsIgnoreCase(dict)){

            final DsSource target = this.dataSourceList.stream().filter(json -> valueStr.equals(json.getDsName())).findFirst().orElse(null);

            if(target != null){
                return target.getId();
            }
        }else if ("protocol".equals(dict)) {
            final JSONObject target = this.dataCollectionType.stream().filter(json -> valueStr.equals(json.getStr("dictLabel"))).findFirst().orElse(null);

            if(target != null){
                return target.getStr("dictValue");
            }
        }

        return null;
    }
}