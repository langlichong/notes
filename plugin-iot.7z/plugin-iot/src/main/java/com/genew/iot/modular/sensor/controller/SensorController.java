/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.sensor.controller;

import cn.dev33.satoken.annotation.SaCheckPermission;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.genew.common.annotation.CommonLog;
import com.genew.common.pojo.CommonResult;
import com.genew.common.pojo.CommonValidList;
import com.genew.iot.modular.sensor.entity.Sensor;
import com.genew.iot.modular.sensor.param.SensorAddParam;
import com.genew.iot.modular.sensor.param.SensorEditParam;
import com.genew.iot.modular.sensor.param.SensorIdParam;
import com.genew.iot.modular.sensor.param.SensorPageParam;
import com.genew.iot.modular.sensor.service.SensorService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.ApiSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 传感器控制器
 *
 * @author huhu
 * @date  2023/04/11 14:57
 */
@Api(tags = "传感器控制器")
@ApiSupport(author = "SNOWY_TEAM", order = 1)
@RestController
@Validated
public class SensorController {

    @Resource
    private SensorService sensorService;

    /**
     * 获取传感器分页
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    @ApiOperationSupport(order = 1)
    @ApiOperation("获取传感器分页")
    @SaCheckPermission("/iot/sensor/page")
    @GetMapping("/iot/sensor/page")
    public CommonResult<Page<Sensor>> page(SensorPageParam sensorPageParam) {
        return CommonResult.data(sensorService.page(sensorPageParam));
    }

    /**
     * 添加传感器
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    @ApiOperationSupport(order = 2)
    @ApiOperation("添加传感器")
    @CommonLog("添加传感器")
    @SaCheckPermission("/iot/sensor/add")
    @PostMapping("/iot/sensor/add")
    public CommonResult<String> add(@RequestBody @Valid SensorAddParam sensorAddParam) {
        sensorService.add(sensorAddParam);
        return CommonResult.ok();
    }

    /**
     * 编辑传感器
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    @ApiOperationSupport(order = 3)
    @ApiOperation("编辑传感器")
    @CommonLog("编辑传感器")
    @SaCheckPermission("/iot/sensor/edit")
    @PostMapping("/iot/sensor/edit")
    public CommonResult<String> edit(@RequestBody @Valid SensorEditParam sensorEditParam) {
        sensorService.edit(sensorEditParam);
        return CommonResult.ok();
    }

    /**
     * 删除传感器
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    @ApiOperationSupport(order = 4)
    @ApiOperation("删除传感器")
    @CommonLog("删除传感器")
    @SaCheckPermission("/iot/sensor/delete")
    @PostMapping("/iot/sensor/delete")
    public CommonResult<String> delete(@RequestBody @Valid @NotEmpty(message = "集合不能为空")
                                                   CommonValidList<SensorIdParam> sensorIdParamList) {
        sensorService.delete(sensorIdParamList);
        return CommonResult.ok();
    }

    /**
     * 获取传感器详情
     *
     * @author huhu
     * @date  2023/04/11 14:57
     */
    @ApiOperationSupport(order = 5)
    @ApiOperation("获取传感器详情")
    @SaCheckPermission("/iot/sensor/detail")
    @GetMapping("/iot/sensor/detail")
    public CommonResult<Sensor> detail(@Valid SensorIdParam sensorIdParam) {
        return CommonResult.data(sensorService.detail(sensorIdParam));
    }


    @ApiOperationSupport(order = 6)
    @ApiOperation("获取所有传感器")
    @SaCheckPermission("/iot/sensor/list")
    @GetMapping("/iot/sensor/list")
    public CommonResult<List<Sensor>> all() {
        return CommonResult.data(sensorService.list());
    }
}
