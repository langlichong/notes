package com.genew.iot.modular.device.control;

import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.core.util.TcpUtil;
import com.genew.iot.modular.collect.core.CollectTypes;
import com.genew.iot.modular.device.entity.DeviceAction;
import com.genew.iot.modular.device.service.impl.AbstractControl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 功能描述：TCP服务端远程控制器
 *
 * @Author： js
 * @create： 2023/9/11 16:44
 */
@Slf4j
@Component
public class TcpControl extends AbstractControl {

    @Resource
    private TcpUtil tcpUtil;

    @Override
    @ExceptionLog(value = "TCP远程控制", type = LogTypes.remoteControl)
    public void remoteControl(DeviceAction deviceAction) throws DataIntegrationException {
        String hostIp = deviceAction.getHost();
        Integer hostPort = deviceAction.getPort();
        String cmd = deviceAction.getPayload();
        // 下发操作指令
        distributeOperationCmd(cmd, hostIp, hostPort);
    }

    @Override
    public boolean support(DeviceAction deviceAction) {
        String protocol = deviceAction.getProtocol();
        if (CollectTypes.TCP_POLL.name().startsWith(protocol) || CollectTypes.TCP_SUBSCRIBE.name().startsWith(protocol)) {
            return true;
        }
        return false;
    }


    /**
     * 下发操作指令
     *
     * @param cmd
     * @param hostIp
     * @param hostPort
     * @return
     * @throws DataIntegrationException
     */
    public Map<String, String> distributeOperationCmd(String cmd, String hostIp, Integer hostPort) throws DataIntegrationException {
        Socket socket;
        Map<String, String> map = new ConcurrentHashMap<>(6);
        try {
            socket = new Socket(InetAddress.getByName(hostIp), hostPort);
            if (Objects.isNull(socket)){
                throw new DataIntegrationException("socket连接失败");
            }
            final OutputStream outputStream = socket.getOutputStream();
            final InputStream inputStream = socket.getInputStream();
            // 等待回复处理
            String data = tcpUtil.getReturnBytesByCmd(cmd, inputStream, outputStream);
            map.put(cmd, data);
        } catch (Exception e) {
            log.error("------------下发指令异常:{}------------", e.getMessage());
            throw new DataIntegrationException(e.getMessage(), e);
        }
        return map;
    }
}

