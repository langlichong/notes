/*
 * Copyright [2022] [https://www.xiaonuo.vip]
 *
 * Snowy采用APACHE LICENSE 2.0开源协议，您在使用过程中，需要注意以下几点：
 *
 * 1.请不要删除和修改根目录下的LICENSE文件。
 * 2.请不要删除和修改Snowy源码头部的版权声明。
 * 3.本项目代码可免费商业使用，商业使用请保留源码和相关描述文件的项目出处，作者声明等。
 * 4.分发源码时候，请注明软件出处 https://www.xiaonuo.vip
 * 5.不可二次分发开源参与同类竞品，如有想法可联系团队xiaonuobase@qq.com商议合作。
 * 6.若您的项目无法满足以上几点，需要更多功能代码，获取Snowy商业授权许可，请在官网购买授权，地址为 https://www.xiaonuo.vip
 */
package com.genew.iot.modular.metricdict.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollStreamUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.genew.common.enums.CommonSortOrderEnum;
import com.genew.common.exception.CommonException;
import com.genew.common.page.CommonPageRequest;
import com.genew.iot.modular.metricdict.entity.MetricDict;
import com.genew.iot.modular.metricdict.mapper.MetricDictMapper;
import com.genew.iot.modular.metricdict.param.MetricDictAddParam;
import com.genew.iot.modular.metricdict.param.MetricDictEditParam;
import com.genew.iot.modular.metricdict.param.MetricDictIdParam;
import com.genew.iot.modular.metricdict.param.MetricDictPageParam;
import com.genew.iot.modular.metricdict.service.MetricDictService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 指标字典Service接口实现类
 *
 * @author huhu
 * @date  2023/06/29 17:50
 **/
@Service
public class MetricDictServiceImpl extends ServiceImpl<MetricDictMapper, MetricDict> implements MetricDictService {

    @Override
    public Page<MetricDict> page(MetricDictPageParam metricDictPageParam) {
        QueryWrapper<MetricDict> queryWrapper = new QueryWrapper<>();
        if(ObjectUtil.isNotEmpty(metricDictPageParam.getName())) {
            queryWrapper.lambda().like(MetricDict::getName, metricDictPageParam.getName());
        }
        if(ObjectUtil.isAllNotEmpty(metricDictPageParam.getSortField(), metricDictPageParam.getSortOrder())) {
            CommonSortOrderEnum.validate(metricDictPageParam.getSortOrder());
            queryWrapper.orderBy(true, metricDictPageParam.getSortOrder().equals(CommonSortOrderEnum.ASC.getValue()),
                    StrUtil.toUnderlineCase(metricDictPageParam.getSortField()));
        } else {
            queryWrapper.lambda().orderByAsc(MetricDict::getId);
        }
        return this.page(CommonPageRequest.defaultPage(), queryWrapper);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void add(MetricDictAddParam metricDictAddParam) {
        MetricDict metricDict = BeanUtil.toBean(metricDictAddParam, MetricDict.class);
        this.save(metricDict);
    }

    /**
     * 保存所有的指标名称并返回保存后指标的 id 列表
     * @param metricNames
     */
    public Set<String> saveMetrics(String ...metricNames){

        final LambdaQueryWrapper<MetricDict> condition = Wrappers.lambdaQuery(MetricDict.class).in(MetricDict::getName, metricNames);
        final List<MetricDict> existsMetrics = this.list(condition);
        final Set<String> existNames = existsMetrics.stream().map(MetricDict::getName).collect(Collectors.toSet());
        final Set<String> existMetricIds = existsMetrics.stream().map(MetricDict::getId).collect(Collectors.toSet());

        final Set<String> allMetricNames = new HashSet<String>(Arrays.asList(metricNames));
        allMetricNames.removeAll(existNames);

        List<MetricDict> dicts = new ArrayList<>();
        for (String metricName : allMetricNames) {
            final MetricDict dict = new MetricDict();
            dict.setName(metricName);
            dicts.add(dict);
        }

        this.saveBatch(dicts);
        final Set<String> newIds = dicts.stream().map(MetricDict::getId).collect(Collectors.toSet());

        existMetricIds.addAll(newIds);

        return existMetricIds;

    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(MetricDictEditParam metricDictEditParam) {
        MetricDict metricDict = this.queryEntity(metricDictEditParam.getId());
        BeanUtil.copyProperties(metricDictEditParam, metricDict);
        this.updateById(metricDict);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(List<MetricDictIdParam> metricDictIdParamList) {
        // 执行删除
        this.removeByIds(CollStreamUtil.toList(metricDictIdParamList, MetricDictIdParam::getId));
    }

    @Override
    public MetricDict detail(MetricDictIdParam metricDictIdParam) {
        return this.queryEntity(metricDictIdParam.getId());
    }



    @Override
    public MetricDict queryEntity(String id) {
        MetricDict metricDict = this.getById(id);
        if(ObjectUtil.isEmpty(metricDict)) {
            throw new CommonException("指标字典不存在，id值为：{}", id);
        }
        return metricDict;
    }
}
