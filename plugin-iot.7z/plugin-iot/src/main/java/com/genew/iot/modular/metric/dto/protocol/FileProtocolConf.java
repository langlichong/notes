package com.genew.iot.modular.metric.dto.protocol;

import lombok.Data;

@Data
public class FileProtocolConf extends Common{

    /**
     * 协议名称
     */
    private String protocol ;

    /**
     * 完整的文件访问地址： ftp://huhu:huhu@192.168.54.3:21/files/test.txt
     */
    private String fileUrl ;

    /**
     * 文件读取协议：http、ftp、socket
     */
    private String fileReadType;

    /**
     * 是否跳过文件第一行
     */
    private boolean skipFirstRow;

    /**
     * 文件中每行内容中 列分隔符号
     */
    private String columnSplitter;

    /**
     * 指标值所在列的索引
     */
    private Integer metricValueColIndex;

    /**
     * 指标值对应的时间戳列的索引
     */
    private Integer metricValueTsColIndex;


}
