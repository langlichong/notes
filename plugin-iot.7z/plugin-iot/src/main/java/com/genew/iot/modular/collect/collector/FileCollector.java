package com.genew.iot.modular.collect.collector;

import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.genew.common.annotation.ExceptionLog;
import com.genew.common.enums.LogTypes;
import com.genew.iot.core.exception.DataIntegrationException;
import com.genew.iot.modular.collect.core.*;
import com.genew.iot.modular.metric.dto.protocol.FileProtocolConf;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 文件解析
 */
@Slf4j
@Component
public class FileCollector extends AbstractCollector<List<JSONObject>, List<String>> {

    private static final String LINE_SEPARATOR = System.getProperty("line.separator");

    @Override
    @ExceptionLog(value = "文件解析", type = LogTypes.collectData)
    protected CollectResponse<List<JSONObject>, List<String>> collectData() throws DataIntegrationException {

        final CollectRequest request = CollectContext.getRequest();
        final FileProtocolConf protocolConf = request.getFileProtocolConf();

        // todo 返回多个指标值
        final List<JSONObject> metrics = new ArrayList<>();

        //文件中所有指标值
        List<JSONObject> metricValues = new ArrayList<>();

        //读文件内容并解析指标值
        parseFile(protocolConf, metricValues);

        // todo 当一个文件中一次采集到同一个指标的多个值时候，如何处理
        final JSONObject collectResult = JSONUtil.createObj();
        if (!metricValues.isEmpty()) {
            for (JSONObject metricObj : metricValues) {

                String tagValue = metricObj.getStr("value");
                String ts = metricObj.getStr("ts");

                /*final JSONObject valuePart = JSONUtil.createObj()
                        .set("ts",ts)
                        .set("unit", request.getDataUnit())
                        .set("value", tagValue);*/

                //推送格式： {"指标名称": "指标值对象"}
                final JSONObject dataPoint = JSONUtil.createObj().set(request.getName(), tagValue);

                metrics.add(dataPoint);
            }
        }

        final CollectResponse response = CollectResponse.builder()
                .originRequest(request)
                .collectResult(JSONUtil.parseArray(metrics))
                .collectResultType(ProcessResultType.JSONARRY)
                .build();

        return response;
    }


    private static void parseFile(FileProtocolConf protocolConf, List<JSONObject> metricValues) throws DataIntegrationException {

        final String fileUrl = protocolConf.getFileUrl();
        final String fileReadType = protocolConf.getFileReadType();//http or ftp

        log.debug("文件采集,fileReadType = {}", fileReadType);
        if ("http".equalsIgnoreCase(fileReadType)) {

            final String fileContent = HttpUtil.get(fileUrl);
            final String[] lines = fileContent.split(LINE_SEPARATOR);

            parseRows(metricValues, lines, protocolConf);

        } else if ("ftp".equalsIgnoreCase(fileReadType)) {
            try {
                // e.g.  ftp://huhu:huhu@192.168.54.3:21/files/test.txt
                URL ftpUrl = new URL(fileUrl);
                InputStream inputStream = ftpUrl.openStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
                final List<String> lineList = br.lines().collect(Collectors.toList());
                br.close();

                parseRows(metricValues, lineList.toArray(new String[]{}), protocolConf);

            } catch (IOException e) {
                throw new DataIntegrationException("文件采集 - ftp异常", e);
            }

        } else {
            log.warn("不支持的文件读取类型: fileReadType = {}", fileReadType);
        }
    }

    private static void parseRows(List<JSONObject> metricValues, String[] lines, FileProtocolConf protocolConf) {

        final boolean skipFirstRow = protocolConf.isSkipFirstRow();
        final String columnSplitter = protocolConf.getColumnSplitter();
        final Integer valueIndex = protocolConf.getMetricValueColIndex();
        final Integer tsIndex = protocolConf.getMetricValueTsColIndex();

        //每行数据中包含一个指标值,指标采集时间
        int start = skipFirstRow ? 1 : 0;
        for (int i = start; i < lines.length; i++) {
            String line = lines[i];
            final String[] cols = line.split(columnSplitter);
            // 指标值
            if (valueIndex != null && cols.length >= valueIndex) {
                if (StringUtils.isNotBlank(cols[valueIndex - 1])) {

                    String value = cols[valueIndex.intValue() - 1];
                    final JSONObject metricObj = JSONUtil.createObj().set("value", value);
                    // 指标采集时间
                    if (tsIndex != null && cols.length >= tsIndex && StringUtils.isNotBlank(cols[tsIndex - 1])) {
                        String ts = cols[tsIndex - 1];
                        metricObj.set("ts", ts);
                    } else {
                        metricObj.set("ts", System.currentTimeMillis() + "");
                    }
                    metricValues.add(metricObj);
                }
            }
        }
    }


    @Override
    protected boolean support(CollectRequest request) {

        if (request.getProtocol().equalsIgnoreCase(CollectTypes.FILE_READING.name())) {
            return true;
        }
        return false;
    }


    public static void main(String[] args) throws IOException {

        //http
        String fileUrl = "http://localhost:9000/thingsboard-import-test.csv";
        final String contents = HttpUtil.get(fileUrl);

        final String[] lines = contents.split(LINE_SEPARATOR);
        System.out.println(lines[0]);

        //Ftp vsftpd
        String url = "ftp://huhu:huhu@192.168.54.3:21/files/test.txt";
        URL ftpUrl = new URL(url);
        InputStream inputStream = ftpUrl.openStream();
        InputStreamReader isr = new InputStreamReader(inputStream);
        BufferedReader br = new BufferedReader(isr);

        br.lines().forEach(line -> {
            System.out.println("---");
            System.out.println(line);
        });
        /*String line;
        while ( (line = br.readLine()) != null){
            System.out.println(line);
            System.out.println("-----");
        }*/
        br.close();

      /*  byte[] bytes = new byte[inputStream.available()];
        inputStream.read(bytes);
        String fileContents = new String(bytes,"UTF-8");
        final String[] ftpLines = fileContents.split(LINE_SEPARATOR);
        System.out.println(ftpLines.length);
        System.out.println(ftpLines[0]);
        inputStream.close();*/

    }
}
